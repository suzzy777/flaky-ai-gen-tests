#!/usr/bin/env python3
"""Build task_csvs/tests_laneN.csv, the --tests input of flaky_check_basic.py, od_confirm.py and
od_recheck.py: one row per generated test method of the rows that fully passed the replay (the main
study's rule, as nonflaky_check_package/make_tests_csv.py): status "passed" in genreplay_out/, else
"passed" in genreplay_fix_out/ (then mockito_fix = true).
Lanes: all rows of one project (project_key: every dubbo commit, every elasticjob commit, ...) go to the
same lane, so two copies of one project's suite never run at once (two dubbo suites clash on ports).
Projects are spread over the lanes by number of test methods.
--not-passed: only print the replay ids that did not pass in genreplay_out/ (for the --mockito-fix replay).
Usage: python3 make_tests_csv.py [--lanes 4] [--not-passed]
"""
import argparse
import csv
from pathlib import Path

P = Path(__file__).resolve().parent
FIELDS = ["project", "sha", "module", "generated_test", "test_file", "focal_method", "zip", "java",
          "junit", "mockito_fix", "focal_from_test", "focal_from_test_type"]


def read(name):
    p = P / name
    return list(csv.DictReader(open(p, encoding="utf-8"))) if p.is_file() else []


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--lanes", type=int, default=4)
    a.add_argument("--not-passed", action="store_true")
    args = a.parse_args()
    plain = {r["id"]: r for r in read("genreplay_out/results.csv")}
    if args.not_passed:
        print(" ".join(sorted(k for k, r in plain.items() if r["status"] != "passed")))
        return
    fix = {r["id"]: r for r in read("genreplay_fix_out/results.csv")}
    methods = {}
    for name in ("genreplay_out/methods.csv", "genreplay_fix_out/methods.csv"):
        for r in read(name):
            methods.setdefault((name.split("/")[0], r["id"]), []).append(r)
    man = {r["row_number"]: r for r in read("task_csvs/generate.csv")}
    out, key = [], {}
    for rid in sorted(set(plain) | set(fix)):
        if plain.get(rid, {}).get("status") == "passed":
            res, src, mockito_fix = plain[rid], "genreplay_out", "false"
        elif fix.get(rid, {}).get("status") == "passed":
            res, src, mockito_fix = fix[rid], "genreplay_fix_out", "true"
        else:
            continue
        m = man[res["row_number"]]
        tests_dir = P / "out" / "runs" / f"row_{int(res['row_number']):03d}" / "tests"
        for t in methods.get((src, rid), []):
            cls = t["test"].split("#")[0].rsplit(".", 1)[-1]
            f = next(tests_dir.rglob(cls + ".java"))
            out.append({"project": m["project"], "sha": m["flaky_commit"], "module": m["module"],
                        "generated_test": t["test"], "test_file": str(f.relative_to(P)),
                        "focal_method": res["focal"], "zip": res["zip"], "java": m["java"],
                        "junit": res["junit"], "mockito_fix": mockito_fix,
                        "focal_from_test": m["flaky_test"], "focal_from_test_type": m["test_type"]})
            key[len(out) - 1] = m["project_key"]
    sizes = {}
    for i in key:
        sizes[key[i]] = sizes.get(key[i], 0) + 1
    load, lane_of = [0] * args.lanes, {}
    for k in sorted(sizes, key=lambda x: (-sizes[x], x)):
        n = load.index(min(load))
        lane_of[k] = n
        load[n] += sizes[k]
    (P / "task_csvs").mkdir(exist_ok=True)
    for old in (P / "task_csvs").glob("tests_lane*.csv"):
        old.unlink()
    for n in range(args.lanes):
        rows = [r for i, r in enumerate(out) if lane_of[key[i]] == n]
        if not rows:
            continue
        dest = P / "task_csvs" / f"tests_lane{n + 1}.csv"
        with open(dest, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, FIELDS)
            w.writeheader()
            w.writerows(rows)
        print(f"{dest.name}: {len(rows)} test methods, {len({r['test_file'] for r in rows})} files "
              f"({', '.join(sorted({key[i] for i, r in enumerate(out) if lane_of[key[i]] == n}))})")
    print(f"{len(out)} test methods in {len({r['test_file'] for r in out})} files passed the replay")


if __name__ == "__main__":
    main()
