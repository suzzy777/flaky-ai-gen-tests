#!/bin/bash
# ChatUniTest with Claude on the focal methods focal_package found, then the main study's checks.
# Generation: the main study's setup (batch_reproflake_chatunitest.py generate, patched ChatUniTest 2.1.1,
# JUnit 4 prompts, test-scoped Mockito), but ChatUniTest's requests go to claude_proxy.py, which sends
# them to Claude (ChatUniTest itself is told "gpt-4o": its model list has no Claude).
# Checks: replay (mvn test; --mockito-fix for rows that did not pass), then for the fully passing files:
# iDFlakies (20 rounds) + od_confirm.py (M8 surefire) + od_recheck.py (OD), NIO (100 runs), NonDex
# (100 seeds, ID), 100 reruns alone (NOD), the summary. Lanes in parallel, one project per lane at a time.
# Usage (inside tmux, ANTHROPIC_API_KEY exported in that shell):
#   bash run.sh setup /path/to/focal_package/out   once: Python venv, ChatUniTest, manifest, a test call
#                                                  (rows 1-53 = the main study's 53; --all keeps expansion repeats)
#   bash run.sh generate --limit 1                 pilot: the first focal method only
#   bash run.sh generate --limit 53                the first N rows (resumable: generated rows are skipped)
#   bash run.sh generate                           all rows. The proxy stops at MAX_USD in total (default 30).
#   bash run.sh checks                             after generation (resumable); LANES=1 for one lane
# Results: out/ (generation), genreplay_out/, genreplay_fix_out/, out_checks/ (summary.txt, summary_all.csv).
D="$(cd "$(dirname "$0")" && pwd)"
cd "$D" || exit 1   # no pom.xml here; generate must not find one in the working directory
PY="$D/venv/bin/python"
PORT="${PROXY_PORT:-8765}"
REPO="${MAVEN_REPO:-$HOME/.m2/repository}"
step="$1"; shift

need_key() { [ -n "$ANTHROPIC_API_KEY" ] || { echo "export ANTHROPIC_API_KEY first"; exit 1; }; }

case "$step" in
setup)
  need_key
  [ -n "$1" ] || { echo "usage: bash run.sh setup /path/to/focal_package/out [--all]"; exit 1; }
  command -v mvn >/dev/null || { echo "mvn is not on the PATH"; exit 1; }
  if [ ! -x "$PY" ]; then
    python3 -m venv "$D/venv" && "$D/venv/bin/pip" install -q -r "$D/requirements.txt" || exit 1
  fi
  mkdir -p "$D/out"
  "$D/venv/bin/pip" freeze > "$D/out/pip_freeze.txt"
  bash "$D/install_chatunitest.sh" "$REPO" || exit 1
  "$PY" "$D/make_manifest.py" "$@" || exit 1
  "$PY" "$D/claude_proxy.py" --check --log-dir "$D/out" || { echo "the Claude test call failed (key? credit?)"; exit 1; }
  echo "setup done; next: bash run.sh generate --limit 1"
  ;;
generate)
  need_key
  [ -f "$D/task_csvs/generate.csv" ] || { echo "run setup first"; exit 1; }
  "$PY" "$D/claude_proxy.py" --port "$PORT" --log-dir "$D/out" --max-usd "${MAX_USD:-30}" >> "$D/out/proxy.log" 2>&1 &
  PROXY=$!
  trap 'kill $PROXY 2>/dev/null' EXIT
  for _ in $(seq 30); do
    "$PY" -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:$PORT/', timeout=2)" 2>/dev/null && break
    sleep 1
  done
  kill -0 $PROXY 2>/dev/null || { echo "the proxy did not start; see out/proxy.log"; exit 1; }
  # ChatUniTest sends this placeholder as its key; the proxy ignores it and uses ANTHROPIC_API_KEY.
  CHATUNITEST_URL="http://127.0.0.1:$PORT/v1/chat/completions" OPENAI_API_KEY="unused-claude-proxy-key" \
    "$PY" "$D/batch_reproflake_chatunitest.py" generate \
    --manifest "$D/task_csvs/generate.csv" --junit4-dir "$D/chatunitest" \
    --out "$D/out" --archives "$D/zips" --download --delete-zips --maven-repo "$REPO" \
    --model gpt-4o --resume --execute "$@" 2>&1 | tee -a "$D/generate.log"
  "$PY" -c "
import csv; r=list(csv.DictReader(open('$D/out/proxy_usage.csv')))
print(f'Claude: {len(r)} requests, \${sum(float(x[\"cost_usd\"] or 0) for x in r):.2f} so far, '
      f'{sum(1 for x in r if x[\"error\"])} errors, '
      f'{sum(1 for x in r if x[\"stop_reason\"] == \"max_tokens\")} cut off at max_tokens (out/proxy_usage.csv)')"
  ;;
checks)
  [ -f "$D/out/generation_results.csv" ] || { echo "run generate first"; exit 1; }
  PART="$D/out:$D/task_csvs/generate.csv"
  "$PY" "$D/replay_generated.py" --part "$PART" --out "$D/genreplay_out" --maven-repo "$REPO" 2>&1 | tee -a "$D/replay.log"
  IDS=$("$PY" "$D/make_tests_csv.py" --not-passed)
  if [ -n "$IDS" ]; then
    ONLY=(); for i in $IDS; do ONLY+=(--only "$i"); done
    "$PY" "$D/replay_generated.py" --part "$PART" --out "$D/genreplay_fix_out" --maven-repo "$REPO" --mockito-fix "${ONLY[@]}" 2>&1 | tee -a "$D/replay_fix.log"
  fi
  "$PY" "$D/make_tests_csv.py" --lanes "${LANES:-4}" || exit 1
  ls "$D"/task_csvs/tests_lane*.csv >/dev/null 2>&1 || { echo "no generated test passed the replay"; exit 0; }
  [ -x "$D/maven-m8/bin/mvn" ] || bash "$D/setup_m8.sh" || exit 1
  lane() {
    n=$1; T="$D/task_csvs/tests_lane$n.csv"; O="$D/out_checks/lane$n"
    mkdir -p "$O"
    (
      X=(--tests "$T" --archive-dir "$D/out/extracted" --maven-repo "$REPO")
      "$PY" flaky_check_basic.py idflakies "${X[@]}" --rounds 20 --out "$O/idflakies"
      (export PATH="$D/maven-m8/bin:$PATH"; unset M2_HOME MAVEN_HOME
       "$PY" od_confirm.py --offline "${X[@]}" --idflakies-out "$O/idflakies" --out "$O/od_confirm"
       # per-method re-check of od_confirm's rejected victims (no od_confirm.csv when iDFlakies flagged nothing)
       [ ! -f "$O/od_confirm/od_confirm.csv" ] || "$PY" od_recheck/od_recheck.py --name "lane$n" \
         --od-confirm "$O/od_confirm/od_confirm.csv" --idflakies-out "$O/idflakies" "${X[@]}" --out "$O/od_recheck")
      "$PY" flaky_check_basic.py nio "${X[@]}" --nio-runs 100 --out "$O/nio"
      "$PY" flaky_check_basic.py nondex "${X[@]}" --nondex-runs 100 --out "$O/nondex"
      "$PY" flaky_check_basic.py rerun "${X[@]}" --runs 100 --offline --out "$O/rerun"
      "$PY" flaky_check_basic.py summary "${X[@]}" --out "$O"
      echo "lane$n done"
    ) >> "$O/lane.log" 2>&1  # append: a resumed run must not wipe the earlier log
  }
  for f in "$D"/task_csvs/tests_lane*.csv; do
    n=${f##*_lane}; n=${n%.csv}
    echo "lane $n started, log: out_checks/lane$n/lane.log"
    lane "$n" &
  done
  wait
  "$PY" "$D/collect_summary.py" checks "$D/out_checks" | tee "$D/out_checks/summary.txt"
  ;;
*)
  sed -n '9,16p' "$0"; exit 1 ;;
esac
