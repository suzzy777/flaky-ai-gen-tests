# ChatUniTest with Claude, then the flakiness checks

**What:** generates unit tests with ChatUniTest for every focal method `focal_package` found (`auto_resolved`: the 144 main-study tests and the new ReproFlake tests), using Claude Opus 5.5 instead of gpt-4o, and then runs the main study's flakiness checks on the generated tests.

With the current focal results there are 182 rows, in this order:
- rows 1-53: the 53 main-study tests that ChatUniTest with gpt-4o and the agent already ran (same tests, same focal methods);
- rows 54-67: the other 14 main-set tests the new focal step found;
- rows 68-182: the expansion. Here, flaky tests that share a focal method (same archive and module) would get exactly the same prompt, so each focal method is generated once (115 instead of 155). The `same_focal_tests` column in `task_csvs/generate.csv` lists the tests a row also stands for. `bash run.sh setup <out> --all` keeps all 155.

**Generation** is set up exactly as in the main study: the same patched ChatUniTest 2.1.1 (JUnit 4 mode), the same JUnit 4 prompts, test-scoped Mockito added to the module pom, and the same driver (`batch_reproflake_chatunitest.py generate`). Only the model is different:
- ChatUniTest only accepts its own list of models, which has no Claude. So it is told "gpt-4o" and sends its requests to `claude_proxy.py`, a small server on this machine. The proxy sends the same messages to Claude and passes the answer back.
- Opus always thinks before it answers, and the thinking counts toward the answer limit. ChatUniTest asks for at most 1024 tokens (its default), which the thinking alone could use up, so the proxy asks Claude for up to 16000. Only the answer goes back to ChatUniTest; `out/proxy_usage.csv` has its length (`answer_chars`).
- Claude doesn't accept temperature, so ChatUniTest's temperature of 0.5 isn't sent.
- The proxy writes every request to `out/proxy_usage.csv`, with tokens and cost. It stops sending requests when the total reaches $30 (for example `MAX_USD=60 bash run.sh generate` to allow more). The total counts every earlier run too.

**Checks**, with the main study's tools and settings:
1. **Replay:** every generated test file runs with the module's own `mvn test`. A row whose tests don't all pass is tried once more with the Mockito fix. Only files where every test passes are checked further, as in the main study.
2. **OD:** iDFlakies, 20 rounds on the whole module's test suite. Then `od_confirm.py` confirms each order it flagged, and `od_recheck.py` re-checks the rejected cases one method at a time.
3. **NIO:** each test run twice in one JVM, 100 times.
4. **ID:** NonDex, 100 seeds.
5. **Reruns:** each test run alone 100 times.

**Needs:**
- Linux, Python 3.10 or newer (`python3 -m venv` must work), Maven 3.6 or newer;
- JDK 8, 11 and 17 in `/usr/lib/jvm` (or set `JAVA_HOME_8`, `JAVA_HOME_11`, `JAVA_HOME_17`);
- internet access to zenodo.org, pypi.org, api.anthropic.com and Maven Central;
- about 100 GB of disk. The projects are downloaded again, into `out/extracted/`, so `focal_package`'s copies aren't changed;
- `ANTHROPIC_API_KEY` (no OpenAI key);
- for the hadoop rows: protoc 2.5.0, see `HADOOP_PROTOC_FIX.txt`.

**Steps** (inside tmux, `tmux new -s gen`, with `export ANTHROPIC_API_KEY=...` in that shell):
1. `bash run.sh setup /path/to/focal_package/out`. This sets up Python, installs the patched ChatUniTest into `~/.m2`, builds `task_csvs/generate.csv` from your focal results, and makes one short test call to Claude. It should print 182 rows (main 67, of them 53 from the main study first; expansion 115).
2. **Pilot:** `bash run.sh generate --limit 1`. Then check `out/generation_results.csv`: row 1 should be `generated` with `tests_generated` above 0, and `out/proxy_usage.csv` should show requests without errors, with `stop_reason` `end_turn` and `cost_usd` around $0.05-0.15 per request.
3. **In stages**, so the spending stays small at each step:
   - the 53 main-study tests: `bash run.sh generate --limit 53` (about $15-25);
   - the other 14 main-set tests: `bash run.sh generate --limit 67` (about $5);
   - then, once we have looked at the main set, the expansion: `MAX_USD=100 bash run.sh generate` (about $30-50 more).
   
   Rows already generated are skipped, so a stopped run can be started again with the same line. Look at `out/proxy_usage.csv` after a few rows; if the `error` column fills up, stop it (Ctrl+C) and check the key and the credit.
4. **Checks:** `bash run.sh checks`. It runs 4 lanes at once; all commits of one project stay in one lane, because two copies of one project's tests can clash on ports. Each lane's log is `out_checks/laneN/lane.log`. If it stops, run it again with the same `LANES`: finished rows are skipped. If the machine is slow or a log shows "Address already in use", stop it, delete `out_checks/`, and run `LANES=1 bash run.sh checks`.

Don't run other Maven jobs on this machine while it runs.

**Estimate:**
- Generation: in the main study, gpt-4o cost $0.13 and 2.6 minutes per focal method on average. Claude Opus 5.5 costs more per token and also pays for its thinking, so roughly $0.25-0.45 per focal method: $20-30 for the main set, $50-80 and 8-12 hours for all 182. Check `out/proxy_usage.csv` after the pilot and after about 20 rows.
- Checks: several days. iDFlakies takes the longest (about 4 hours per dubbo row on our machine). No API cost.

**Bring back:**
- `out/generation_results.csv`, `out/proxy_usage.csv`, `out/runs/` (the generated tests and ChatUniTest's logs);
- `genreplay_out/` and `genreplay_fix_out/` (without `maven-noext/`);
- `out_checks/` (`summary.txt` has the counts, `summary_all.csv` one row per test method);
- `task_csvs/`, `generate.log`, `replay.log`, `replay_fix.log`.

Not needed: `out/extracted/`, `zips/`, `venv/`, `maven-m8/`.

**Changes to the main study's scripts** (only in this folder's copies): `batch_reproflake_chatunitest.py` takes the API address from `CHATUNITEST_URL`, and it finds a test file outside `src/test/java` the same way `focal_v2.py` did. Everything else is unchanged.
