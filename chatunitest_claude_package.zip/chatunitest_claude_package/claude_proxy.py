#!/usr/bin/env python3
"""Lets ChatUniTest use Claude. ChatUniTest 2.1.1 only accepts its own model names (gpt-4o, ...) and sends
OpenAI-style chat requests to -Durl. This is a small local server at that URL: it takes ChatUniTest's
request, sends the same messages to Claude (Anthropic SDK, model CLAUDE_MODEL) and answers in the
OpenAI format ChatUniTest reads (choices[0].message.content, usage).
- System messages become Claude's system prompt; consecutive messages of the same role are joined.
- temperature, frequency_penalty and presence_penalty are not sent: this Claude model does not take them.
- Opus 5.5 always thinks (it can't be turned off), at its default effort (medium), and the thinking counts
  toward max_tokens. ChatUniTest asks for 1024 (its maxResponseTokens default), which the thinking could
  use up, so the proxy asks for at least MIN_MAX_TOKENS. The thinking itself is not passed to ChatUniTest.
- Every request goes to <log dir>/proxy_usage.csv (time, tokens incl. thinking, length of the answer, cost). When the total reaches --max-usd,
  further requests are refused (ChatUniTest then records an API error), so a bug can't use up the credit.
- Listens on 127.0.0.1 only. ANTHROPIC_API_KEY comes from the environment; the key ChatUniTest sends
  is ignored.
Usage: python3 claude_proxy.py --port 8765 --log-dir out [--max-usd 150]
       python3 claude_proxy.py --check   (one short request to Claude, prints the reply)
"""
import argparse
import csv
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import sys
import threading
import time

import anthropic

CLAUDE_MODEL = "claude-opus-5-5"
PRICE_IN, PRICE_OUT = 4.0, 20.0     # USD per million tokens (Claude Opus 5.5)
MIN_MAX_TOKENS = 16000              # room for the thinking plus the answer
LOG_FIELDS = ["time", "model", "input_tokens", "output_tokens", "answer_chars", "cost_usd", "stop_reason", "seconds",
              "error", "request_id"]


def to_claude(messages):
    """(system text, Claude messages) from OpenAI-style messages."""
    system, out = [], []
    for m in messages:
        role, text = m.get("role"), m.get("content") or ""
        if role == "system":
            system.append(text)
            continue
        role = "assistant" if role == "assistant" else "user"
        if out and out[-1]["role"] == role:
            out[-1]["content"] += "\n\n" + text
        else:
            out.append({"role": role, "content": text})
    if not out or out[0]["role"] != "user":
        out.insert(0, {"role": "user", "content": "(see the system prompt)"})
    return "\n\n".join(system), out


class Proxy:
    def __init__(self, log_dir, max_usd):
        self.client = anthropic.Anthropic(max_retries=5)
        self.log = Path(log_dir) / "proxy_usage.csv"
        self.log.parent.mkdir(parents=True, exist_ok=True)
        self.max_usd = max_usd
        self.lock = threading.Lock()
        self.total = 0.0
        if self.log.is_file():
            self.total = sum(float(r["cost_usd"] or 0) for r in csv.DictReader(open(self.log, encoding="utf-8")))
        else:
            with open(self.log, "w", newline="", encoding="utf-8") as fh:
                csv.writer(fh).writerow(LOG_FIELDS)

    def record(self, **kw):
        with self.lock:
            self.total += kw.get("cost_usd", 0.0)
            with open(self.log, "a", newline="", encoding="utf-8") as fh:
                csv.DictWriter(fh, LOG_FIELDS).writerow(
                    {"time": datetime.now(timezone.utc).isoformat(timespec="seconds"), "model": CLAUDE_MODEL,
                     **{k: (f"{v:.5f}" if k == "cost_usd" else v) for k, v in kw.items()}})

    def ask(self, req):
        """(HTTP status, OpenAI-style response body)."""
        if self.total >= self.max_usd:
            msg = f"proxy cost limit reached (${self.total:.2f} of ${self.max_usd:.2f})"
            self.record(error=msg, cost_usd=0.0)
            return 402, {"error": {"message": msg, "type": "cost_limit"}}
        system, messages = to_claude(req.get("messages", []))
        kw = {"model": CLAUDE_MODEL, "max_tokens": max(int(req.get("max_tokens") or 0), MIN_MAX_TOKENS),
              "messages": messages}
        if system:
            kw["system"] = system
        t0 = time.time()
        try:
            with self.client.messages.stream(**kw) as s:
                r = s.get_final_message()
                request_id = s.request_id or ""
        except anthropic.APIStatusError as ex:
            self.record(error=f"{ex.status_code}: {str(ex)[:200]}", seconds=round(time.time() - t0, 1), cost_usd=0.0)
            return ex.status_code, {"error": {"message": str(ex)[:500], "type": type(ex).__name__}}
        except anthropic.APIConnectionError as ex:
            self.record(error=f"connection: {str(ex)[:200]}", seconds=round(time.time() - t0, 1), cost_usd=0.0)
            return 502, {"error": {"message": str(ex)[:500], "type": type(ex).__name__}}
        text = "".join(b.text for b in r.content if b.type == "text")
        cost = (r.usage.input_tokens * PRICE_IN + r.usage.output_tokens * PRICE_OUT) / 1e6
        self.record(input_tokens=r.usage.input_tokens, output_tokens=r.usage.output_tokens, answer_chars=len(text),
                    cost_usd=cost,
                    stop_reason=r.stop_reason, seconds=round(time.time() - t0, 1), request_id=request_id)
        finish = {"end_turn": "stop", "max_tokens": "length", "stop_sequence": "stop"}.get(r.stop_reason, r.stop_reason)
        return 200, {"id": r.id, "object": "chat.completion", "created": int(time.time()), "model": CLAUDE_MODEL,
                     "choices": [{"index": 0, "message": {"role": "assistant", "content": text},
                                  "finish_reason": finish}],
                     "usage": {"prompt_tokens": r.usage.input_tokens, "completion_tokens": r.usage.output_tokens,
                               "total_tokens": r.usage.input_tokens + r.usage.output_tokens}}


def serve(proxy, port):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            try:
                req = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
                status, body = proxy.ask(req)
            except Exception as ex:  # noqa: BLE001  (answer ChatUniTest instead of dropping the connection)
                status, body = 500, {"error": {"message": f"{type(ex).__name__}: {ex}"[:500], "type": "proxy_error"}}
            data = json.dumps(body).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):  # health check for run.sh
            data = json.dumps({"ok": True, "model": CLAUDE_MODEL, "cost_usd": round(proxy.total, 4)}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, fmt, *args):
            pass

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"claude_proxy: {CLAUDE_MODEL} on http://127.0.0.1:{port}/v1/chat/completions, "
          f"spent so far ${proxy.total:.2f} of ${proxy.max_usd:.2f}", flush=True)
    httpd.serve_forever()


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--port", type=int, default=8765)
    a.add_argument("--log-dir", type=Path, default=Path("out"))
    a.add_argument("--max-usd", type=float, default=150.0)
    a.add_argument("--check", action="store_true", help="One short request to Claude, then exit")
    args = a.parse_args()
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("export ANTHROPIC_API_KEY first")
    proxy = Proxy(args.log_dir, args.max_usd)
    if args.check:
        status, body = proxy.ask({"messages": [{"role": "system", "content": "Answer in one word."},
                                               {"role": "user", "content": "Say OK."}], "max_tokens": 50})
        print(status, json.dumps(body)[:400])
        sys.exit(0 if status == 200 else 1)
    serve(proxy, args.port)


if __name__ == "__main__":
    main()
