#!/usr/bin/env python3
"""Build task_csvs/generate.csv, the --manifest of batch_reproflake_chatunitest.py generate: every
auto_resolved row of focal_package's results (out/focal_manifest_v2.csv, the 144 main-study tests, and
out/expansion_manifest.csv, the new ReproFlake tests), numbered 1..N.
Added columns: focal_set (main/expansion), focal_row (its row_number there), project_key (one name per
project, as focal_package/make_expansion_input.py; used for the check lanes).
archive_root, test_file and module_dir are cleared, so generate downloads its own copy of each project
into out/extracted/ (the focal step's copies are not changed, and the checks find the projects there).
Order: the main-study rows (old_status auto_resolved: the 53 that ChatUniTest with gpt-4o and the agent
already ran), then the other main-set rows, then the expansion, so --limit 53 is exactly the old 53.
The main set keeps every row, as the main study did. In the expansion, flaky tests with the same focal
method in the same archive and module get the same ChatUniTest prompt, so only the first is kept;
same_focal_tests lists the others. --all keeps every expansion row too.
Usage: python3 make_manifest.py FOCAL_OUT [--all]   (FOCAL_OUT: focal_package's out/ folder)
"""
import collections
import csv
from pathlib import Path
import re
import sys

P = Path(__file__).resolve().parent
ISSUE = {"hdfs": "hadoop", "yarn": "hadoop", "scb": "servicecomb", "collections": "commons-collections"}
NAMES = [("shardingsphereelasticjob", "elasticjob"), ("elasticjob", "elasticjob"), ("dubbo", "dubbo"),
         ("hadoop", "hadoop"), ("jnrposix", "jnr-posix"), ("marineapi", "marineapi"), ("ormlite", "ormlite"),
         ("quickcheck", "quickcheck"), ("wikidatatoolkit", "wikidata-toolkit"), ("wildfly", "wildfly")]
ALIAS = {"junit-quickcheck": "quickcheck", "ormlite-core": "ormlite", "servicecomb-java-chassis": "servicecomb",
         "incubator-shenyu": "shenyu"}


def project_key(z):
    if "=" in z:
        k = z.split("=")[0].lower()
    elif re.fullmatch(r"([A-Z]+)-\d+", z):
        k = z.split("-")[0].lower()
        k = ISSUE.get(k, k)
    else:
        k = next((name for pre, name in NAMES if z.lower().startswith(pre)), z.lower())
    return ALIAS.get(k, k)


def main():
    src = Path(sys.argv[1]).resolve()
    keep_all = "--all" in sys.argv[2:]
    out, cols, first = [], [], {}
    for name, fset in (("focal_manifest_v2.csv", "main"), ("expansion_manifest.csv", "expansion")):
        f = src / name
        if not f.is_file():
            sys.exit(f"{f} not found")
        for r in csv.DictReader(open(f, encoding="utf-8")):
            cols += [k for k in r if k not in cols]
            if r["status"] != "auto_resolved" or not r["selected_method"].strip():
                continue
            key = (r["zip"], r["module"], r["selected_method"].strip())
            if fset == "expansion" and not keep_all and key in first:
                first[key]["same_focal_tests"] += (";" if first[key]["same_focal_tests"] else "") + r["flaky_test"]
                continue
            out.append({**r, "focal_set": fset, "focal_row": r["row_number"],
                        "project_key": r.get("project_key") or project_key(r["zip"]), "same_focal_tests": "",
                        "archive_root": "", "test_file": "", "module_dir": ""})
            first[key] = out[-1]
    old = [r for r in out if r["focal_set"] == "main" and r.get("old_status") == "auto_resolved"]
    out = old + [r for r in out if not (r["focal_set"] == "main" and r.get("old_status") == "auto_resolved")]
    for i, r in enumerate(out, 1):
        r["row_number"] = i
        r["project"] = r["project"] or r["project_key"]
    cols += [c for c in ("focal_set", "focal_row", "project_key", "same_focal_tests") if c not in cols]
    (P / "task_csvs").mkdir(exist_ok=True)
    with open(P / "task_csvs" / "generate.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, cols)
        w.writeheader()
        w.writerows(out)
    c = collections.Counter(r["test_type"] for r in out)
    s = collections.Counter(r["focal_set"] for r in out)
    rep = sum(len(r["same_focal_tests"].split(";")) for r in out if r["same_focal_tests"])
    print(f"task_csvs/generate.csv: {len(out)} rows (main {s['main']}, of them {len(old)} from the main study "
          f"first; expansion {s['expansion']}; "
          + ("repeated focal methods kept" if keep_all else f"{rep} expansion tests with a repeated focal method skipped")
          + f"), by type ({', '.join(f'{t} {c[t]}' for t in ('id', 'od', 'td', 'nio'))}), "
          f"{len({r['zip'] for r in out})} archives, {len({r['project_key'] for r in out})} projects")


if __name__ == "__main__":
    main()
