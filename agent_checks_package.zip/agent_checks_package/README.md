# Flakiness checks of the agent's tests

**What:** the main study's flakiness checks on the tests the agent wrote in `agent_main_package`. Same tools and settings as the main study:
- OD (order-dependent): iDFlakies, 20 rounds on the whole module's test suite with the new tests added. Then `od_confirm.py` runs again each order iDFlakies flagged, to confirm that a new test really breaks another one. `od_recheck.py` re-checks the cases `od_confirm` rejected, one generated method at a time;
- ID (implementation-dependent): NonDex, 100 seeds;
- NIO (non-idempotent outcome): each method run twice in one JVM, 100 times;
- NOD (plain flaky): each method run alone 100 times.

Each check copies the new test into a clean copy of the project, runs, and takes it out again. The project archives are the ones `agent_main_package` already downloaded, so nothing is downloaded again.

**Needs:**
- the same machine, with `agent_main_package` already run (this folder next to it);
- Maven on the PATH, and the same JDKs as for the agent;
- internet access the first time, so Maven can fetch the iDFlakies and NonDex plugins;
- Python 3 (no extra packages).

**Run** (inside tmux, after the agent has finished):
```
tmux new -s checks
cd agent_checks_package
bash run.sh
```
- It checks condition A. If you also ran F: `CONDITIONS="A F" bash run.sh`.
- The first time, it makes `maven-m8/`, a copy of your Maven with the surefire extension `od_confirm.py` needs. Your own Maven isn't changed.
- It runs 4 lanes at once. All commits of one project are in the same lane, because two copies of one project's tests can clash on ports. `bash run.sh` prints which projects are in which lane. Each lane's log is `out_checks_A/laneN/lane.log`.
- If it stops, run it again with the same settings: finished rows are skipped. Don't change `LANES` in between, since that moves projects to other lanes.
- If the machine is slow or a log shows "Address already in use", stop it, delete `out_checks_A/`, and run `LANES=1 bash run.sh` (one project at a time, slower).
- Don't run the agent or other Maven jobs at the same time.

**Estimate:** one to three days. iDFlakies takes the longest: about 4 hours per dubbo row on our machine. No API cost.

**Results:** `out_checks_A/summary.txt` gives the counts. `out_checks_A/summary_all.csv` has one row per generated test method, with every check's result. Rows can fail to build (graylog, for example); that is shown in each check's `rows.csv` and is fine. Just note it.

**Bring back:** the whole `out_checks_A/` folder (and `out_checks_F/` if run).

**Rebuild on machine A:** `python3 make_package.py`
