#!/usr/bin/env python3
"""Build this folder (on machine A): the main study's flakiness checks for the agent's tests from
agent_main_package (out_<cond>/), to run on the machine that ran the agent. Copies only; the sources are
not changed. Like agent_experiment/machine_b_FC, the folder mirrors only_scripts/, so the copied scripts
run unchanged:
  flaky_check_basic.py, od_confirm.py, ...   the checks and the modules they import (copies from ../)
  od_recheck/od_recheck.py   per-method re-check after od_confirm
  m8/, setup_m8.sh   surefire 3.0.0-M8-SNAPSHOT + KebabPizza extension, for od_confirm.py
  inputs/projects.csv   project and sha per zip, from ../generate_part1.csv and ../generate_part2.csv
No projects: the checks use the archives agent_main_package downloaded (agent_experiment/extracted/).
Usage: python3 make_package.py
"""
import csv
from pathlib import Path
import shutil

P = Path(__file__).resolve().parent
H = P.parent                 # only_scripts/

ROOT_SCRIPTS = ["flaky_check_basic.py", "od_confirm.py", "batch_reproflake_chatunitest.py", "collect_nonflaky.py",
                "replay_generated.py"]


def main():
    for s in ROOT_SCRIPTS:
        shutil.copy2(H / s, P / s)
    (P / "od_recheck").mkdir(exist_ok=True)
    shutil.copy2(H / "od_recheck" / "od_recheck.py", P / "od_recheck" / "od_recheck.py")
    mb = H / "prompt_experiment" / "machine_b_idflakies"
    shutil.copy2(mb / "setup_m8.sh", P / "setup_m8.sh")
    if not (P / "m8").exists():
        shutil.copytree(mb / "m8", P / "m8")
    zips = {r["zip"] for r in csv.DictReader(open(H / "agent_main_package" / "agent_experiment" / "manifest.csv",
                                                   encoding="utf-8"))}
    proj = {}
    for f in ("generate_part1.csv", "generate_part2.csv"):
        for r in csv.DictReader(open(H / f, encoding="utf-8")):
            if r["zip"] in zips:
                proj.setdefault(r["zip"], {"zip": r["zip"], "project": r["project"], "sha": r["flaky_commit"]})
    missing = zips - set(proj)
    if missing:
        raise SystemExit(f"no project/sha for {sorted(missing)}")
    (P / "inputs").mkdir(exist_ok=True)
    with open(P / "inputs" / "projects.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, ["zip", "project", "sha"])
        w.writeheader()
        w.writerows(proj[z] for z in sorted(proj))
    print(f"package ready: {len(proj)} projects")


if __name__ == "__main__":
    main()
