#!/usr/bin/env python3
"""Build task_csvs/<cond>_laneN.csv, the --tests input of flaky_check_basic.py, od_confirm.py and
od_recheck.py, for the agent's tests (<agent dir>/out_<cond>/runs/row_NNN/tests/), like
agent_experiment/make_idf_tests_csv.py. One row per @Test method. No replay filter: a method that
always fails shows up in the rerun check (always_failed).
Lanes: all rows of one project (every dubbo commit, every elasticjob commit, ...) go to the same lane, so
two copies of one project's suite never run at once (two dubbo suites clash on ports). Projects are spread
over the lanes by number of test methods.
Usage: python3 make_tests_csv.py AGENT_DIR COND LANES   (AGENT_DIR: agent_main_package/agent_experiment)
"""
import csv
import os
from pathlib import Path
import re
import sys

P = Path(__file__).resolve().parent
FIELDS = ["project", "sha", "module", "generated_test", "test_file", "focal_method", "zip", "java",
          "junit", "mockito_fix", "focal_from_test", "focal_from_test_type"]
TEST = re.compile(r"@Test\b[^{;]*?\bvoid\s+(\w+)\s*\(")
PACKAGE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.M)
FAMILIES = {"dubbo": "dubbo", "elasticjob": "elasticjob", "graylog": "graylog", "camel": "camel",
            "hadoop": "hadoop", "yarn": "hadoop"}


def family(z):
    k = re.sub(r"[^a-z]", "", z.lower())
    return next((f for key, f in FAMILIES.items() if key in k), z)


def main():
    agent, cond, lanes = Path(sys.argv[1]).resolve(), sys.argv[2], int(sys.argv[3])
    res = agent / f"out_{cond}" / "generation_results.csv"
    if not res.is_file():
        sys.exit(f"{res} not found: run the agent (condition {cond}) first")
    proj = {r["zip"]: r for r in csv.DictReader(open(P / "inputs" / "projects.csv", encoding="utf-8"))}
    man = {r["row_number"]: r for r in csv.DictReader(open(agent / "manifest.csv", encoding="utf-8"))}
    out = []
    for g in csv.DictReader(open(res, encoding="utf-8")):
        if g["status"] != "generated":
            continue
        rn = g["row_number"]
        p, m = proj[g["zip"]], man[rn]
        for f in sorted((agent / f"out_{cond}" / "runs" / f"row_{int(rn):03d}" / "tests").rglob("*.java")):
            src = f.read_text(encoding="utf-8", errors="replace")
            pkg = PACKAGE.search(src)
            fqcn = (pkg.group(1) + "." if pkg else "") + f.stem
            for name in TEST.findall(src):
                out.append({"project": p["project"], "sha": p["sha"], "module": m["module"],
                            "generated_test": f"{fqcn}#{name}", "test_file": os.path.relpath(f, P),
                            "focal_method": m["selected_method"], "zip": g["zip"], "java": m["java"],
                            "junit": m["junit"], "mockito_fix": "false", "focal_from_test": m["flaky_test"],
                            "focal_from_test_type": f"agent_{cond}"})
    sizes = {}
    for r in out:
        sizes[family(r["zip"])] = sizes.get(family(r["zip"]), 0) + 1
    load, lane_of = [0] * lanes, {}
    for fam in sorted(sizes, key=lambda x: (-sizes[x], x)):
        n = load.index(min(load))
        lane_of[fam] = n
        load[n] += sizes[fam]
    (P / "task_csvs").mkdir(exist_ok=True)
    for old in (P / "task_csvs").glob(f"{cond}_lane*.csv"):
        old.unlink()
    for n in range(lanes):
        rows = [r for r in out if lane_of[family(r["zip"])] == n]
        if not rows:
            continue
        dest = P / "task_csvs" / f"{cond}_lane{n + 1}.csv"
        with open(dest, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, FIELDS)
            w.writeheader()
            w.writerows(rows)
        fams = sorted({family(r["zip"]) for r in rows})
        print(f"{dest.name}: {len(rows)} test methods, {len({r['test_file'] for r in rows})} files ({', '.join(fams)})")
    if not out:
        sys.exit(f"no generated tests in {agent / f'out_{cond}'}")


if __name__ == "__main__":
    main()
