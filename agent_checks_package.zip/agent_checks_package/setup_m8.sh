#!/bin/bash
# ReproFlake's surefire for the order-dependence check (od_confirm.py), without touching your Maven:
#   1. copies the surefire 3.0.0-M8-SNAPSHOT artifacts (TestingResearchIllinois/maven-surefire fork,
#      not on Maven Central) from m8/repository into ~/.m2/repository; existing files are kept;
#   2. makes maven-m8/ in this folder: a copy of the Maven on your PATH plus the "KebabPizza" extension
#      (m8/ext/surefire-changing-maven-extension-1.0-SNAPSHOT.jar) in its lib/ext. That extension makes
#      Maven use surefire 3.0.0-M8-SNAPSHOT, which runs -Dtest=A#m,B#n in exactly that order with
#      -Dsurefire.runOrder=testorder.
# run_all.sh puts maven-m8/bin on the PATH only for od_confirm.py; the other checks use your own Maven.
# Usage: bash setup_m8.sh   (once)
set -e
D="$(cd "$(dirname "$0")" && pwd)"
REPO="${MAVEN_REPO:-$HOME/.m2/repository}"
mkdir -p "$REPO"
cp -rn "$D/m8/repository/." "$REPO/"
echo "surefire 3.0.0-M8-SNAPSHOT artifacts copied into $REPO (existing files kept)"

MVN=$(command -v mvn) || { echo "mvn is not on the PATH"; exit 1; }
HOME_MVN=$(dirname "$(dirname "$(readlink -f "$MVN")")")
if [ ! -x "$D/maven-m8/bin/mvn" ]; then
  rm -rf "$D/maven-m8"  # a copy left by a failed run has bin/mvn but no extension
  # -L: copy the files links point to (Ubuntu's /usr/share/maven links boot/ and lib/ jars to ../../java/)
  cp -rL "$HOME_MVN" "$D/maven-m8"
  # some Maven installs (e.g. Ubuntu's) have no lib/ext, or a symlink there to a system folder:
  # replace it by this copy's own folder, never delete jars through a link
  rm -rf "$D/maven-m8/lib/ext"
  mkdir -p "$D/maven-m8/lib/ext"
  cp "$D/m8/ext/surefire-changing-maven-extension-1.0-SNAPSHOT.jar" "$D/maven-m8/lib/ext/"
  echo "maven-m8/ made from $HOME_MVN, with the extension in lib/ext"
fi
if ls "$HOME_MVN/lib/ext/"*.jar >/dev/null 2>&1; then
  echo "note: your Maven ($HOME_MVN) has jars in lib/ext; the checks then run with a private copy without them (maven-noext)"
fi
"$D/maven-m8/bin/mvn" -v | head -1
