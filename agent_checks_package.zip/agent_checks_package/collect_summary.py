#!/usr/bin/env python3
"""Put the lanes' results together: out_checks_<cond>/summary_all.csv (every lane's summary.csv),
od_confirm_all.csv and od_recheck_all.csv, and print the counts.
Usage: python3 collect_summary.py COND [BASE]   (BASE: default out_checks_<cond>/ in this folder)
"""
import csv
from collections import Counter
from pathlib import Path
import sys

P = Path(__file__).resolve().parent


def gather(base, rel, dest):
    rows, fields = [], ["lane"]
    for f in sorted(base.glob(f"lane*/{rel}")):
        lane = f.relative_to(base).parts[0]
        for r in csv.DictReader(open(f, encoding="utf-8")):
            fields += [k for k in r if k not in fields]
            rows.append({"lane": lane, **r})
    if rows:
        with open(base / dest, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fields)
            w.writeheader()
            w.writerows(rows)
    return rows


def main():
    cond = sys.argv[1]
    base = Path(sys.argv[2]) if len(sys.argv) > 2 else P / f"out_checks_{cond}"
    s = gather(base, "summary.csv", "summary_all.csv")
    od = gather(base, "od_confirm/od_confirm.csv", "od_confirm_all.csv")
    rc = gather(base, "od_recheck/recheck.csv", "od_recheck_all.csv")
    print(f"{len(s)} generated test methods in {len({r['generated_test'].split('#')[0] for r in s})} files")
    print(f"  flagged by any check: {sum(r['any_flaky'] == 'true' for r in s)}")
    print(f"  rerun flaky: {sum(r['rerun_flaky'] == 'true' for r in s)}, "
          f"always failed: {sum(r['rerun_runs'] not in ('', '0') and r['rerun_passed'] == '0' for r in s)}")
    print(f"  NonDex flaky: {sum(r['nondex_flaky'] == 'true' for r in s)}")
    print(f"  NIO: {dict(Counter(r['nio'] or '-' for r in s))}")
    print(f"  iDFlakies: {dict(Counter(r['idflakies_type'] or '-' for r in s))}")
    print(f"  od_confirm categories: {dict(Counter(r['category'] for r in od))}")
    print(f"  od_recheck categories: {dict(Counter(r['category'] for r in rc))}")
    print(f"-> {base}/summary_all.csv, od_confirm_all.csv, od_recheck_all.csv")


if __name__ == "__main__":
    main()
