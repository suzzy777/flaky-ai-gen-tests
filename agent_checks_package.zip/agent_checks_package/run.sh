#!/bin/bash
# The main study's flakiness checks on the agent's tests from agent_main_package (out_<condition>/), with
# the main study's settings (../run_flaky_all.sh, agent_experiment/run_idflakies_F.sh):
#   iDFlakies (20 rounds, whole module suite), od_confirm.py (M8 surefire, maven-m8/) on what it flags,
#   od_recheck.py on od_confirm's rejected victims (OD); NIO (100 runs); NonDex (100 seeds, ID);
#   100 reruns of each method alone (NOD); then the summary.
# Lanes run in parallel, all rows of one project in the same lane (make_tests_csv.py).
# Results: out_checks_<condition>/laneN/, and out_checks_<condition>/summary_all.csv (collect_summary.py).
# Logs: out_checks_<condition>/laneN/lane.log. Resumable: run it again (finished rows are skipped).
# Run it only after the agent has finished (the tests list is built at the start).
# Usage (inside tmux):
#   bash run.sh                   condition A, 4 lanes
#   LANES=1 bash run.sh           one lane (one project at a time)
#   CONDITIONS="A F" bash run.sh  A, then F
#   AGENT_DIR=/path/to/agent_main_package/agent_experiment bash run.sh
D="$(cd "$(dirname "$0")" && pwd)"
AG="${AGENT_DIR:-$D/../agent_main_package/agent_experiment}"
REPO="${MAVEN_REPO:-$HOME/.m2/repository}"
[ -d "$AG/extracted" ] || { echo "$AG/extracted not found: run agent_main_package first, or set AGENT_DIR"; exit 1; }
command -v mvn >/dev/null || { echo "mvn is not on the PATH"; exit 1; }
[ -x "$D/maven-m8/bin/mvn" ] || bash "$D/setup_m8.sh" || exit 1

lane() {
  c=$1; n=$2
  T="$D/task_csvs/${c}_lane$n.csv"
  O="$D/out_checks_$c/lane$n"
  mkdir -p "$O"
  (
    cd "$D"
    X=(--tests "$T" --archive-dir "$AG/extracted" --maven-repo "$REPO")
    python3 flaky_check_basic.py idflakies "${X[@]}" --rounds 20 --out "$O/idflakies"
    (export PATH="$D/maven-m8/bin:$PATH"; unset M2_HOME MAVEN_HOME
     python3 od_confirm.py --offline "${X[@]}" --idflakies-out "$O/idflakies" --out "$O/od_confirm"
     # per-method re-check of od_confirm's rejected victims (od_confirm replays a generated class's methods together)
     # (no od_confirm.csv when iDFlakies flagged nothing)
     [ ! -f "$O/od_confirm/od_confirm.csv" ] || python3 od_recheck/od_recheck.py --name "${c}_lane$n" \
       --od-confirm "$O/od_confirm/od_confirm.csv" --idflakies-out "$O/idflakies" "${X[@]}" --out "$O/od_recheck")
    python3 flaky_check_basic.py nio "${X[@]}" --nio-runs 100 --out "$O/nio"
    python3 flaky_check_basic.py nondex "${X[@]}" --nondex-runs 100 --out "$O/nondex"
    python3 flaky_check_basic.py rerun "${X[@]}" --runs 100 --offline --out "$O/rerun"
    python3 flaky_check_basic.py summary "${X[@]}" --out "$O"
    echo "lane$n done"
  ) >> "$O/lane.log" 2>&1  # append: a resumed run must not wipe the earlier log
}

for c in ${CONDITIONS:-A}; do
  python3 "$D/make_tests_csv.py" "$AG" "$c" "${LANES:-4}" || exit 1
  for f in "$D/task_csvs/${c}_lane"*.csv; do
    n=${f##*_lane}; n=${n%.csv}
    echo "condition $c lane $n started, log: out_checks_$c/lane$n/lane.log"
    lane "$c" "$n" &
  done
  wait
  python3 "$D/collect_summary.py" "$c" | tee "$D/out_checks_$c/summary.txt"
done
echo "all done (agent_checks_package)"
