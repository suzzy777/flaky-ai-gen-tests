#!/bin/bash
# mini-swe-agent (Claude, see agent_experiment/agent_config.yaml) on the 53 flaky-side tests of the main
# study, one run per test, with ChatUniTest's prompt for that test. Condition A by default.
# Results: agent_experiment/out_<condition>/; log: agent_experiment/agent_<condition>.log.
# Resumable: run it again (finished rows are skipped; REDO=1 runs them again).
# Usage (inside tmux, with ANTHROPIC_API_KEY exported in that shell):
#   bash run.sh                   all 53 rows, condition A
#   bash run.sh 1 3               only these row numbers (e.g. a first test)
#   CONDITIONS="A F" bash run.sh  conditions A, then F
D="$(cd "$(dirname "$0")" && pwd)"
A="$D/agent_experiment"
REPO="${MAVEN_REPO:-$HOME/.m2/repository}"
[ -n "$ANTHROPIC_API_KEY" ] || { echo "export ANTHROPIC_API_KEY first"; exit 1; }
# the agent's Python packages, the versions machine A used
if [ ! -x "$A/venv/bin/python" ]; then
  python3 -m venv "$A/venv" && "$A/venv/bin/pip" install -q "mini-swe-agent==2.4.6" "litellm==1.106.4" "PyYAML==6.0.3" || exit 1
fi
python3 "$A/get_archives.py" || exit 1
mkdir -p "$REPO"
# each project's own Maven artifacts (as setup_archives.py does); existing files are kept
for a in "$A"/extracted/*/; do z=$(basename "$a"); [ -d "$a/$z/Flakym2/.m2/repository" ] && cp -rn "$a/$z/Flakym2/.m2/repository/." "$REPO/"; done
echo "Flakym2 artifacts copied into $REPO (existing files kept)"

ONLY=(); for r in "$@"; do ONLY+=(--only "$r"); done
[ -n "$REDO" ] && ONLY+=(--redo)
for c in ${CONDITIONS:-A}; do
  "$A/venv/bin/python" "$A/run_agent.py" --condition $c "${ONLY[@]}" 2>&1 | tee -a "$A/agent_$c.log"
  grep -q "authentication_error\|invalid x-api-key\|credit balance" "$A/agent_$c.log" && echo "WARNING: API key or credit errors in agent_$c.log, check it"
done
echo "all done (agent_main_package)"
