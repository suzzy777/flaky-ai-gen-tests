#!/usr/bin/env python3
"""Download and unpack the ReproFlake archives of manifest.csv from Zenodo into extracted/<zip>/ (the
layout run_agent.py copies from). Archives already unpacked are skipped; each zip is deleted after
unpacking. Usage: python3 get_archives.py
"""
import argparse
import csv
from pathlib import Path
import sys

E = Path(__file__).resolve().parent
sys.path.insert(0, str(E.parent / "prompt_experiment"))
import batch_reproflake_chatunitest as B  # noqa: E402


def main():
    args = argparse.Namespace(archives=E / "zips", out=E, download=True, delete_zips=True)
    rows = {r["zip"]: r for r in csv.DictReader(open(E / "manifest.csv", encoding="utf-8"))}
    failed = []
    for z, row in sorted(rows.items()):
        print(f"{z}", flush=True)
        try:
            B.get_archive(row, args)
        except (OSError, ValueError) as ex:
            print(f"  failed: {ex}", flush=True)
            failed.append(z)
    print(f"{len(rows) - len(failed)} of {len(rows)} archives ready in {E / 'extracted'}")
    if failed:
        sys.exit("failed: " + " ".join(failed))


if __name__ == "__main__":
    main()
