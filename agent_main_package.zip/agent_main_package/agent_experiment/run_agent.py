#!/usr/bin/env python3
"""Generate tests with mini-swe-agent (model in agent_config.yaml) using ChatUniTest's own prompt, for
the 53 flaky-side tests of the main study (manifest.csv, one row per flaky test).

Prompt: for each row, the exact system + first user message ChatUniTest sent for it in the main study
(saved in prompts/row_NNN/ by make_package.py, for the overload the flaky test calls), followed by a
short section on how to work as an agent (agent_config.yaml).
Conditions (--condition):
  A  "file only": told to run only its own test class (as ChatUniTest does);
  B  "free": also given the command for the module's whole test suite, no restriction;
  T  "tests": as A, plus told to read the project's existing test of the focal class
     (src/test/java/<pkg>/<Class>Test.java) before writing its own;
  F  "folder": as A, plus told the project's existing tests are in the module's src/test/java and to
     read the ones it needs (it picks the files itself);
  N  as F, without "Your test class will be added to the project's test suite next to them."
  FC as F, plus the cleanup prompt's rule (../prompt_experiment/prompts/junit*_cleanup/): restore any
     static field, singleton or field set by reflection that the test changes, in @After/@AfterEach;
  FCV as FC, plus: do not assume shared state is in its default state, set up what the test needs in
     @Before/@BeforeEach (so the test is not a victim of other tests).

Per row: a fresh copy of the project (extracted/<zip> -> work/<cond>_row_NNN/), the agent runs in
it (local shell, the row's JDK, Maven without lib/ext, offline, ~/.m2), then the new *_Test.java
files under src/test/java are kept in out_<cond>/runs/row_NNN/tests/ (the layout replay_generated.py
reads), any other file it changed is listed in changes.txt, and the copy is deleted.
Output: out_<cond>/generation_results.csv (status, steps, cost), runs/row_NNN/{trajectory.json,
tests/, changes.txt, agent.log}.
Usage: ANTHROPIC_API_KEY (Claude) or OPENAI_API_KEY (gpt) must be exported.
  venv/bin/python run_agent.py --condition A [--only 1]
"""
import argparse
import csv
import os
from pathlib import Path
import shutil
import sys

import yaml
from minisweagent.agents.default import DefaultAgent
from minisweagent.environments.local import LocalEnvironment
from minisweagent.models.litellm_model import LitellmModel

E = Path(__file__).resolve().parent
H = E.parent
sys.path.insert(0, str(H / "prompt_experiment"))
import batch_reproflake_chatunitest as B  # noqa: E402
import collect_nonflaky as C  # noqa: E402

FIELDS = ["row_number", "zip", "flaky_test", "selected_method", "junit", "chatunitest_mode", "status",
          "exit_status", "steps", "cost_usd", "test_classes", "other_changes", "overload_match", "test_output"]


def snapshot(root):
    """{relative path: (size, mtime_ns)} of the project, without build output."""
    out = {}
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in ("target", ".git", ".dtfixingtools", ".nondex")]
        for f in fns:
            p = Path(dp) / f
            try:
                s = p.lstat()
            except OSError:
                continue
            out[str(p.relative_to(root))] = (s.st_size, s.st_mtime_ns)
    return out


def prompt_for(row):
    """ChatUniTest's first (system, user) messages for this row, saved under prompts/ by make_package.py."""
    d = E / "prompts" / f"row_{int(row['row_number']):03d}"
    if not (d / "user.txt").is_file():
        sys.exit(f"no ChatUniTest prompt for row {row['row_number']} in {d}")
    return (d / "system.txt").read_text(encoding="utf-8"), (d / "user.txt").read_text(encoding="utf-8")


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--condition", choices=["A", "B", "T", "F", "N", "FC", "FCV"], required=True)
    a.add_argument("--only", action="append", default=[], help="Only these row numbers")
    a.add_argument("--redo", action="store_true")
    args = a.parse_args()
    cfg = yaml.safe_load((E / "agent_config.yaml").read_text())
    key = "ANTHROPIC_API_KEY" if cfg["model"]["model_name"].startswith("anthropic/") else "OPENAI_API_KEY"
    if not os.environ.get(key):
        sys.exit(f"export {key} first")
    out = E / f"out_{args.condition}"
    out.mkdir(exist_ok=True)
    (out / "extracted").exists() or (out / "extracted").symlink_to(E / "extracted")
    repo = (Path.home() / ".m2" / "repository").resolve()
    mvn_bin = C.maven_without_extensions(E)
    res_path = out / "generation_results.csv"
    done = {r["row_number"]: r for r in csv.DictReader(open(res_path))} if res_path.is_file() else {}

    rows = list(csv.DictReader(open(E / "manifest.csv", encoding="utf-8")))
    for row in rows:
        rn = row["row_number"]
        if args.only and rn not in args.only:
            continue
        if rn in done and not args.redo:
            print(f"row {rn}: done ({done[rn]['status']})")
            continue
        run_dir = out / "runs" / f"row_{int(rn):03d}"
        shutil.rmtree(run_dir, ignore_errors=True)
        (run_dir / "tests").mkdir(parents=True)
        work = E / "work" / f"{args.condition}_row_{int(rn):03d}"
        shutil.rmtree(work, ignore_errors=True)
        print(f"row {rn}: copying {row['zip']}", flush=True)
        shutil.copytree(E / "extracted" / row["zip"], work, symlinks=True)
        try:
            _, module_dir, _ = B.locate_test(work, row["module"], row["flaky_test"])
            mvn_root, pl = C.project_root(module_dir, C.norm_module(row["module"]))
            cls, method = row["selected_method"].split("#")
            pkg, simple = cls.rsplit(".", 1)
            test_class = f"{simple}_{method}_0_0_Test"
            test_path = module_dir / "src" / "test" / "java" / Path(*pkg.split(".")) / (test_class + ".java")
            existing = test_path.parent / (simple + "Test.java")
            if args.condition == "T" and not existing.is_file():
                raise FileNotFoundError(f"no existing test {existing}")
            skips = " ".join(s for s in B.BUILD_SKIPS if s != "-DskipTests")
            # No -DfailIfNoTests=false / -Dsurefire.failIfNoSpecifiedTests=false: with them an empty or
            # missing test class ran 0 tests and still gave BUILD SUCCESS (condition T, first pilot).
            # Condition A keeps them, so its later rows (1-6, 13-15) get the same prompt as rows 7-12.
            old = " -DfailIfNoTests=false -Dsurefire.failIfNoSpecifiedTests=false" if args.condition == "A" else ""
            base = f"mvn -B -o test {' '.join(pl)} {skips}{old} -Dmaven.repo.local={repo}"
            jdk = B.find_jdk(row["java"])
            env = {"JAVA_HOME": jdk, "PATH": os.pathsep.join(
                [str(Path(jdk) / "bin")] + ([str(mvn_bin)] if mvn_bin else []) + [os.environ["PATH"]])}
            env.update(cfg["environment"].get("env", {}))
            if row["module"] not in ("", "."):
                # The agent's command builds only the module (-pl, no -am), so its sibling modules come
                # from ~/.m2. Both dubbo commits install as 2.7.0 there, so install this copy's siblings
                # first (the copy's .batch_built stamp would skip it). Before this, aa9f16e rows compiled
                # against 628ad77's dubbo-common and failed (DubboCodec: isSupportResponseAttatchment).
                (module_dir / ".batch_built").unlink(missing_ok=True)
                built = B.build_module({"module": row["module"], "module_dir": str(module_dir)},
                                       {**os.environ, **env}, argparse.Namespace(repo=repo, timeout=3600),
                                       run_dir, "sibling_build.log")
                print(f"row {rn}: siblings of {row['module']}: {built}", flush=True)
                if built != "built":
                    raise RuntimeError(f"sibling build {built}, see {run_dir / 'sibling_build.log'}")
            system, user = prompt_for(row)
            junit = "JUnit 4" if row["junit"] == "4" else "JUnit 5"
            tv = dict(chatunitest_system=system, chatunitest_user=user, project_root=str(mvn_root),
                      module_dir=str(module_dir), test_path=str(test_path), test_class=test_class,
                      package=pkg, junit=junit, java=row["java"], condition=args.condition,
                      existing_test=str(existing.relative_to(mvn_root)),
                      test_dir=str((module_dir / "src" / "test" / "java").relative_to(mvn_root)),
                      test_cmd=f"cd {mvn_root} && {base} -Dtest={test_class} 2>&1 | tail -n 80",
                      suite_cmd=f"cd {mvn_root} && {base} 2>&1 | tail -n 80")
            before = snapshot(work)
            model = LitellmModel(**cfg["model"])
            envr = LocalEnvironment(cwd=str(mvn_root), env=env, timeout=cfg["environment"]["timeout"])
            agent = DefaultAgent(model, envr, output_path=run_dir / "trajectory.json", **cfg["agent"])
            agent.extra_template_vars |= tv
            print(f"row {rn}: agent ({args.condition}) on {row['selected_method']}, JDK {row['java']}", flush=True)
            try:
                info = agent.run(task=row["selected_method"])
                exit_status = info.get("exit_status", "")
            except Exception as ex:  # noqa: BLE001
                exit_status = f"error: {type(ex).__name__}: {str(ex)[:200]}"
            after = snapshot(work)
            changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
            src_test = Path("src") / "test" / "java"
            kept, other = [], []
            for p in changed:
                full = work / p
                rel_mod = full.relative_to(module_dir) if full.is_relative_to(module_dir) else None
                if (p not in before and full.is_file() and p.endswith("_Test.java") and rel_mod
                        and rel_mod.parts[:3] == src_test.parts):
                    dest = run_dir / "tests" / rel_mod.relative_to(src_test)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(full, dest)
                    kept.append(full.stem)
                else:
                    other.append(("new " if p not in before else "deleted " if p not in after else "changed ") + p)
            (run_dir / "changes.txt").write_text("".join(x + "\n" for x in other), encoding="utf-8")
            status = "generated" if kept else "no_tests"
            rec = {"steps": agent.n_calls, "cost_usd": f"{agent.cost:.4f}", "exit_status": exit_status}
        except Exception as ex:  # noqa: BLE001
            status, kept, other, rec = "setup_failed", [], [], {"exit_status": str(ex)[:300]}
        finally:
            shutil.rmtree(work, ignore_errors=True)
        done[rn] = dict(row_number=rn, zip=row["zip"], flaky_test=row["flaky_test"],
                        selected_method=row["selected_method"], junit=row["junit"],
                        chatunitest_mode=row["junit"], status=status, test_classes=";".join(kept),
                        other_changes=len(other), overload_match="agent", test_output=str(run_dir / "tests"), **rec)
        B.csv_write(res_path, sorted(done.values(), key=lambda r: int(r["row_number"])), FIELDS)
        print(f"row {rn}: {status} {kept} steps={rec.get('steps')} cost=${rec.get('cost_usd')} "
              f"exit={rec.get('exit_status')} other_changes={len(other)}", flush=True)


if __name__ == "__main__":
    main()
