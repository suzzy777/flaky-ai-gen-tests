#!/usr/bin/env python3
"""Build agent_main_package/: mini-swe-agent (Claude) on the 53 flaky-side tests of the main study.
Copies only; nothing outside this folder is changed. The folder mirrors only_scripts/, so
agent_experiment/run_agent.py imports prompt_experiment/ as on machine A.
- agent_experiment/manifest.csv: the 53 rows of generate_part1.csv + generate_part2.csv;
- agent_experiment/prompts/row_NNN/: ChatUniTest's first system and user message for the row, from the
  main study's run (out_part1/, out_part2/, graylog_rerun/), for the overload the flaky test calls
  (focal_overloads in generation_results.csv; the first prompt if there is none).
Usage: python3 make_package.py
"""
import csv
import json
import re
import shutil
from pathlib import Path

P = Path(__file__).resolve().parent
H = P.parent
A = P / "agent_experiment"
COLS = ["row_number", "test_type", "zip", "module", "flaky_test", "selected_method", "junit", "java", "url"]


def results():
    out = {}
    for f in ["out_part1/generation_results.csv", "out_part2/generation_results.csv",
              "graylog_rerun/out_row_007/generation_results.csv", "graylog_rerun/out_row_021/generation_results.csv"]:
        if (H / f).is_file():
            for r in csv.DictReader(open(H / f, encoding="utf-8")):
                out.setdefault(r["row_number"], r)
    return out


def prompt_source(part, rn, res):
    base = H / f"out_part{part}" / "runs" / f"row_{rn:03d}" / "tmp"
    src = sorted(base.rglob("attempt0/records.json"))
    if not src:
        base = H / "graylog_rerun" / f"out_row_{rn:03d}" / "runs" / f"row_{rn:03d}" / "tmp"
        src = sorted(base.rglob("attempt0/records.json"))
    if not src:
        raise SystemExit(f"no ChatUniTest prompt for row {rn}")
    m = re.match(r"\s*(\d+):", (res or {}).get("focal_overloads", ""))
    if m:
        hit = [s for s in src if s.parent.parent.name == f"method{m.group(1)}"]
        if hit:
            return hit[0], f"overload {m.group(1)}"
    return src[0], "first prompt"


def main():
    res = results()
    rows = []
    for part in ("1", "2"):
        for r in csv.DictReader(open(H / f"generate_part{part}.csv", encoding="utf-8")):
            rn = int(r["row_number"])
            src, how = prompt_source(part, rn, res.get(r["row_number"]))
            msgs = json.loads(src.read_text(encoding="utf-8"))[0]["prompt"]
            d = A / "prompts" / f"row_{rn:03d}"
            d.mkdir(parents=True, exist_ok=False)
            (d / "system.txt").write_text(msgs[0]["content"], encoding="utf-8")
            (d / "user.txt").write_text(msgs[1]["content"], encoding="utf-8")
            (d / "source.txt").write_text(f"{src.relative_to(H)} ({how})\n", encoding="utf-8")
            rows.append({c: r[c] for c in COLS})
    rows.sort(key=lambda r: int(r["row_number"]))
    with open(A / "manifest.csv", "x", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        w.writerows(rows)
    for f in ["batch_reproflake_chatunitest.py", "collect_nonflaky.py"]:
        dst = P / "prompt_experiment" / f
        dst.parent.mkdir(exist_ok=True)
        shutil.copy2(H / "prompt_experiment" / f, dst)
    shutil.copy2(H / "agent_experiment" / "machine_b_FC" / "requirements.txt", A / "requirements.txt")
    print(f"{len(rows)} rows, {len({r['zip'] for r in rows})} archives")


if __name__ == "__main__":
    main()
