# Agent on the main study (Claude)

**What:** mini-swe-agent writes a test for each of the 53 flaky-side tests of the main study, using Claude (Opus 5.5) instead of gpt-4o. One run per test, as ChatUniTest did in the main study.

- The agent gets the same prompt ChatUniTest got for that test in the main study (`agent_experiment/prompts/row_NNN/`), plus the same short "how to work" section as in the 10-focal experiment.
- If the focal method has overloads, the prompt is the one for the overload that the flaky test calls (the overload the main study checked). `source.txt` in each prompt folder says which one.
- Condition A by default (it only runs its own test class). Condition F (also told where the existing tests are) runs with `CONDITIONS="A F"`.
- Same settings as the 10-focal experiment: step limit 40, cost limit $3 per run, 1 hour per run. The only change is the model, and `temperature` is no longer set, because the Claude API does not accept it.

**Needs:**
- Linux, Python 3.10 or newer (`python3 -m venv` must work);
- Maven on the PATH;
- JDK 8 and JDK 11 in `/usr/lib/jvm` (or set `JAVA_HOME_8` and `JAVA_HOME_11`). 38 rows use JDK 8 and 15 use JDK 11;
- internet access to zenodo.org (the archives), pypi.org (once, for the agent's Python packages) and api.anthropic.com;
- about 15 GB of disk for the 32 archives, plus room in `~/.m2`;
- an Anthropic API key.

**First, test one row** (inside tmux):
```
tmux new -s agent
export ANTHROPIC_API_KEY=...
cd agent_main_package
bash run.sh 3
```
The first time, it makes `agent_experiment/venv/` (mini-swe-agent 2.4.6, litellm 1.106.4), downloads the 32 archives from Zenodo into `agent_experiment/extracted/`, and copies each project's `Flakym2` artifacts into `~/.m2` (existing files are kept). Row 3 (scimono) is small. Check that `agent_experiment/out_A/runs/row_003/tests/` has a test file and that `agent_experiment/out_A/generation_results.csv` shows a cost above 0.

**Then run all rows:**
```
bash run.sh
```
- If it stops, run it again: finished rows are skipped. `REDO=1 bash run.sh 7` runs row 7 again.
- If the log shows key or credit errors, stop it (Ctrl+C), fix the key, delete `agent_experiment/out_A/`, and run again.
- The two graylog rows (7 and 21) may fail to set up: graylog took a special build in the main study. They are then marked `setup_failed`. That is fine; just note it.
- Don't run other Maven jobs on this machine at the same time.

**Estimate:** about $10-20 for condition A (our gpt-4o runs cost $0.26 per run on average), and a day or less of machine time.

**Bring back:**
- `agent_experiment/out_A/` (and `out_F/` if run): `generation_results.csv`, and per row the trajectory, the test files and `changes.txt`;
- `agent_experiment/agent_A.log`.

The flakiness checks of these tests (pass alone, reruns, NonDex, NIO, iDFlakies, OD confirmation) come in a separate package afterwards.
