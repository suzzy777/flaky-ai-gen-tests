# Test generation for non-flaky focal methods (ChatUniTest)

Generates unit tests with ChatUniTest for **156 focal methods of non-flaky tests**, with exactly the
setup used earlier for the focal methods of ReproFlake flaky tests, so the two sides can be compared.

**The sample:** `task_csvs/nonflaky_focal_sample.csv`. Up to 15 unique focal methods per module, from
the 13 modules where the flaky side has passing generated tests, drawn with random seed `2026`
(Camel, dubbo and eco-schema have only 2 each). Focal methods that are also focal methods of a flaky
test are left out. Each focal method comes with one of its non-flaky tests.

## What is in here

| File | What |
|---|---|
| `task_csvs/nonflaky_generate_sample.csv` | **the input** for `generate` (same 156 rows, in the manifest format) |
| `task_csvs/nonflaky_focal_sample.csv` | the same sample, readable: project, sha, module, focal_method, test, ... |
| `batch_reproflake_chatunitest.py` | the driver (`generate` subcommand) |
| `chatunitest/` | the patched ChatUniTest core 2.1.1 (JUnit 4 mode) as built and used before (`chatunitest-core-2.1.1.jar`/`.pom`), its patch, the JUnit 4 prompts (`prompts-junit4/`) and notes |
| `install_chatunitest.sh` | installs the patched core into `~/.m2` (once) |
| `run_generate.sh` | runs the generation |

## Requirements

- Linux, Python 3.8+ with `javalang` (`python3 -m pip install javalang`), Maven 3.6+, internet
- **JDK 8 and JDK 11**, full JDKs with `javac`, found in `/usr/lib/jvm` (e.g. `java-8-openjdk-amd64`,
  `java-11-openjdk-amd64`); elsewhere set `JAVA_HOME_8` / `JAVA_HOME_11`
- An **OpenAI API key** with access to `gpt-4o` and about **$25** of credit (expected ~$20; see below)
- Disk: the 13 archives are downloaded automatically (a few GB with the extracted copies and builds)

## Steps

1. `python3 -m pip install javalang`
2. `bash install_chatunitest.sh`: must end with `OK: patched ChatUniTest core installed`.
   (Maven Central has a stock `chatunitest-core` 2.1.1 with the same name; this replaces it with the
   patched one. Without it, JUnit 4 mode does not exist.)
3. Inside tmux (`tmux new -s gen`), set the key in that terminal only (never write it into a file):
   `export OPENAI_API_KEY=sk-...`
4. **Pilot, first row only:** `bash run_generate.sh --limit 1`
   Check `out/generation_results.csv`: row 1 should have `status` = `generated` and
   `tests_generated` > 0, and `out/runs/row_001/tests/` should contain a `*_Test.java`.
5. **All 156:** `bash run_generate.sh`
   Leave tmux with Ctrl+B then D, come back with `tmux attach -t gen`. If it stops (or the API
   credit runs out), run the same line again: rows that already generated tests are skipped.

Each row downloads its archive from Zenodo the first time (checked for completeness, a broken
download is fetched again), extracts it into `out/extracted/`, builds the module once, adds
test-scoped Mockito 4.11.0 to the module pom (the generated tests import it), and runs ChatUniTest.

## Time and cost

From the flaky side (51 focal methods, measured from ChatUniTest's own token counts): median 1.75 min
and **$0.06**, mean 2.6 min and **$0.13** per focal method, a few up to ~25 min / $0.57. For 156:
roughly **7 hours and ~$20**. Check the usage page of the OpenAI account after the pilot.

## What to send back

`out/generation_results.csv` and the `out/runs/` folder (generated tests, logs, ChatUniTest history).
Not needed: `out/extracted/` and `zips/` (the archives; large).

## Keep these the same (comparability with the flaky side)

- model `gpt-4o`, ChatUniTest 2.1.1 with this patched core, `prompts-junit4` for JUnit 4 projects
  (JUnit 5 projects use ChatUniTest's own JUnit 5 mode), Mockito 4.11.0, this driver script.
  Do not change the model or ChatUniTest settings.
- The flaky-side generation ran on a machine whose Maven (`/opt/maven`) has the KebabPizza extension
  in `lib/ext` (it changes how Maven builds some projects). If this machine's Maven has no such
  extension, that is a small difference in the build, not in ChatUniTest itself; note it.

## Things to know

- `generated` in `generation_results.csv` only means ChatUniTest wrote test files, **not** that they
  compile or pass; that is checked afterwards with a plain `mvn test` (the replay step).
- `tests/` holds tests for the selected focal method; `other_overloads/` tests for other methods with
  the same name (ChatUniTest generates for all overloads).
