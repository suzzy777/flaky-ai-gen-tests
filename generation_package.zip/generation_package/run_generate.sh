#!/bin/bash
# Generate tests with ChatUniTest for the sampled non-flaky focal methods.
# Usage (inside tmux, OPENAI_API_KEY set):  bash run_generate.sh            all 156
#                                           bash run_generate.sh --limit 1  pilot (first row only)
# Rerunning resumes: rows that already generated tests are skipped (--resume).
D="$(cd "$(dirname "$0")" && pwd)"
cd "$D" || exit 1   # run from the package folder (no pom.xml here; the manifest has no project paths)
if [ -z "$OPENAI_API_KEY" ]; then echo "Set OPENAI_API_KEY first"; exit 1; fi
python3 "$D/batch_reproflake_chatunitest.py" generate \
  --manifest "$D/task_csvs/nonflaky_generate_sample.csv" \
  --junit4-dir "$D/chatunitest" \
  --out "$D/out" --archives "$D/zips" --download \
  --model gpt-4o --resume --execute "$@" 2>&1 | tee -a "$D/generate.log"
