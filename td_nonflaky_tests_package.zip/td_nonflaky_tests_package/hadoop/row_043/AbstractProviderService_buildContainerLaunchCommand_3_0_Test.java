package org.apache.hadoop.yarn.service.provider;

import org.apache.hadoop.yarn.service.provider.AbstractProviderService;
import org.apache.hadoop.yarn.service.containerlaunch.AbstractLauncher;
import org.apache.hadoop.yarn.service.api.records.Service;
import org.apache.hadoop.yarn.service.component.instance.ComponentInstance;
import org.apache.hadoop.yarn.service.utils.SliderFileSystem;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.yarn.api.records.Container;
import org.apache.hadoop.yarn.service.containerlaunch.ContainerLaunchService;
import org.apache.hadoop.yarn.service.exceptions.SliderException;
import org.junit.Before;
import org.junit.Test;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.yarn.api.ApplicationConstants;
import org.apache.hadoop.yarn.service.component.ComponentRestartPolicy;
import org.apache.hadoop.yarn.service.conf.YarnServiceConf;
import org.apache.hadoop.yarn.service.conf.YarnServiceConstants;
import org.apache.hadoop.yarn.service.utils.ServiceUtils;
import org.apache.hadoop.yarn.service.containerlaunch.CommandLineBuilder;
import org.apache.hadoop.yarn.service.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map.Entry;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_FAILURES_VALIDITY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_RETRY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_RETRY_MAX;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_FAILURES_VALIDITY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_RETRY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_RETRY_MAX;
import static org.apache.hadoop.yarn.service.utils.ServiceApiUtil.$;

public class AbstractProviderService_buildContainerLaunchCommand_3_0_Test {

    private AbstractProviderService providerService;

    private AbstractLauncher launcher;

    private Service service;

    private ComponentInstance instance;

    private SliderFileSystem fileSystem;

    private Configuration yarnConf;

    private Container container;

    private ContainerLaunchService.ComponentLaunchContext compLaunchContext;

    private Map<String, String> tokensForSubstitution;

    @Before
    public void setUp() {
        providerService = Mockito.mock(AbstractProviderService.class, Mockito.CALLS_REAL_METHODS);
        launcher = mock(AbstractLauncher.class);
        service = mock(Service.class);
        instance = mock(ComponentInstance.class);
        fileSystem = mock(SliderFileSystem.class);
        yarnConf = mock(Configuration.class);
        container = mock(Container.class);
        compLaunchContext = mock(ContainerLaunchService.ComponentLaunchContext.class);
        tokensForSubstitution = new HashMap<>();
    }

    @Test
    public void testBuildContainerLaunchCommandWithNonEmptyLaunchCommand() throws IOException, SliderException {
        String launchCommand = "echo Hello World";
        when(compLaunchContext.getLaunchCommand()).thenReturn(launchCommand);
        // Use reflection to access the private method substituteStrWithTokens
        try {
            java.lang.reflect.Method method = ProviderUtils.class.getDeclaredMethod("substituteStrWithTokens", String.class, Map.class);
            method.setAccessible(true);
            launchCommand = (String) method.invoke(null, launchCommand, tokensForSubstitution);
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
        providerService.buildContainerLaunchCommand(launcher, service, instance, fileSystem, yarnConf, container, compLaunchContext, tokensForSubstitution);
        verify(launcher).addCommand(anyString());
    }

    @Test
    public void testBuildContainerLaunchCommandWithEmptyLaunchCommand() throws IOException, SliderException {
        when(compLaunchContext.getLaunchCommand()).thenReturn("");
        providerService.buildContainerLaunchCommand(launcher, service, instance, fileSystem, yarnConf, container, compLaunchContext, tokensForSubstitution);
        verify(launcher, never()).addCommand(anyString());
    }
}
