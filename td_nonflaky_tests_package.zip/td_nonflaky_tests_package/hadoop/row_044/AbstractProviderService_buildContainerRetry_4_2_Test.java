package org.apache.hadoop.yarn.service.provider;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.yarn.service.containerlaunch.AbstractLauncher;
import org.apache.hadoop.yarn.service.containerlaunch.ContainerLaunchService;
import org.apache.hadoop.yarn.service.component.instance.ComponentInstance;
import org.apache.hadoop.yarn.service.component.Component;
import org.apache.hadoop.yarn.service.component.ComponentRestartPolicy;
import org.apache.hadoop.yarn.service.conf.YarnServiceConf;
import org.junit.Before;
import org.junit.Test;
import java.lang.reflect.Method;
import org.junit.After;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.yarn.api.ApplicationConstants;
import org.apache.hadoop.yarn.api.records.Container;
import org.apache.hadoop.yarn.service.api.records.Service;
import org.apache.hadoop.yarn.service.conf.YarnServiceConstants;
import org.apache.hadoop.yarn.service.utils.SliderFileSystem;
import org.apache.hadoop.yarn.service.utils.ServiceUtils;
import org.apache.hadoop.yarn.service.exceptions.SliderException;
import org.apache.hadoop.yarn.service.containerlaunch.CommandLineBuilder;
import org.apache.hadoop.yarn.service.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_FAILURES_VALIDITY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_RETRY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.CONTAINER_RETRY_MAX;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_FAILURES_VALIDITY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_RETRY_INTERVAL;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConf.DEFAULT_CONTAINER_RETRY_MAX;
import static org.apache.hadoop.yarn.service.utils.ServiceApiUtil.$;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class AbstractProviderService_buildContainerRetry_4_2_Test {

    private AbstractProviderService abstractProviderService;

    private AbstractLauncher mockLauncher;

    private Configuration mockYarnConf;

    private ContainerLaunchService.ComponentLaunchContext mockCompLaunchContext;

    private ComponentInstance mockInstance;

    private Component mockComponent;

    private ComponentRestartPolicy mockRestartPolicy;

    @Before
    public void setUp() {
        abstractProviderService = new AbstractProviderService() {

            @Override
            public void processArtifact(AbstractLauncher launcher, ComponentInstance instance, SliderFileSystem fileSystem, Service service, ContainerLaunchService.ComponentLaunchContext compLaunchContext) {
                // Method implementation for abstract method
            }
        };
        mockLauncher = mock(AbstractLauncher.class);
        mockYarnConf = mock(Configuration.class);
        mockCompLaunchContext = mock(ContainerLaunchService.ComponentLaunchContext.class);
        mockInstance = mock(ComponentInstance.class);
        mockComponent = mock(Component.class);
        mockRestartPolicy = mock(ComponentRestartPolicy.class);
        when(mockInstance.getComponent()).thenReturn(mockComponent);
        when(mockComponent.getRestartPolicyHandler()).thenReturn(mockRestartPolicy);
    }

    @Test
    public void testBuildContainerRetry_DisallowRetries() throws Exception {
        when(mockRestartPolicy.allowContainerRetriesForInstance(mockInstance)).thenReturn(false);
        Method method = AbstractProviderService.class.getDeclaredMethod("buildContainerRetry", AbstractLauncher.class, Configuration.class, ContainerLaunchService.ComponentLaunchContext.class, ComponentInstance.class);
        method.setAccessible(true);
        method.invoke(abstractProviderService, mockLauncher, mockYarnConf, mockCompLaunchContext, mockInstance);
        verify(mockLauncher, never()).setRetryContext(anyInt(), anyInt(), anyLong());
    }
}
