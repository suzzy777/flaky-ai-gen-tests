package org.apache.hadoop.yarn.service.utils;

import org.apache.hadoop.yarn.service.api.records.Component;
import org.apache.hadoop.yarn.service.api.records.Service;
import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.registry.client.api.RegistryConstants;
import org.apache.hadoop.registry.client.binding.RegistryUtils;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.yarn.exceptions.YarnException;
import org.apache.hadoop.yarn.service.api.records.ComponentContainers;
import org.apache.hadoop.yarn.service.api.records.ComponentState;
import org.apache.hadoop.yarn.service.api.records.Container;
import org.apache.hadoop.yarn.service.api.records.ContainerState;
import org.apache.hadoop.yarn.service.api.records.ServiceState;
import org.apache.hadoop.yarn.service.client.ServiceClient;
import org.apache.hadoop.yarn.service.api.records.Artifact;
import org.apache.hadoop.yarn.service.api.records.Configuration;
import org.apache.hadoop.yarn.service.api.records.KerberosPrincipal;
import org.apache.hadoop.yarn.service.api.records.PlacementConstraint;
import org.apache.hadoop.yarn.service.api.records.PlacementPolicy;
import org.apache.hadoop.yarn.service.api.records.Resource;
import org.apache.hadoop.yarn.service.exceptions.SliderException;
import org.apache.hadoop.yarn.service.conf.RestApiConstants;
import org.apache.hadoop.yarn.service.exceptions.RestApiErrorMessages;
import org.apache.hadoop.yarn.service.monitor.probe.MonitorUtils;
import org.apache.hadoop.yarn.service.provider.AbstractClientProvider;
import org.apache.hadoop.yarn.service.provider.ProviderFactory;
import org.codehaus.jackson.map.PropertyNamingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import static org.apache.hadoop.yarn.service.exceptions.RestApiErrorMessages.ERROR_COMP_DOES_NOT_NEED_UPGRADE;
import static org.apache.hadoop.yarn.service.exceptions.RestApiErrorMessages.ERROR_COMP_INSTANCE_DOES_NOT_NEED_UPGRADE;

public class ServiceApiUtil_resolveCompsDependency_29_0_Test {

    private Service service;

    private Component componentA;

    private Component componentB;

    private Component componentC;

    @Before
    public void setUp() {
        componentA = new Component();
        componentA.setName("ComponentA");
        componentA.setDependencies(Arrays.asList("ComponentB", "ComponentC"));
        componentB = new Component();
        componentB.setName("ComponentB");
        componentB.setDependencies(Arrays.asList("ComponentC"));
        componentC = new Component();
        componentC.setName("ComponentC");
        componentC.setDependencies(Arrays.asList());
        service = new Service();
        service.setComponents(Arrays.asList(componentA, componentB, componentC));
    }

    @Test
    public void testResolveCompsDependency() {
        List<String> resolvedComponents = ServiceApiUtil.resolveCompsDependency(service);
        assertEquals(3, resolvedComponents.size());
        assertEquals("ComponentC", resolvedComponents.get(0));
        assertEquals("ComponentB", resolvedComponents.get(1));
        assertEquals("ComponentA", resolvedComponents.get(2));
    }

    @Test
    public void testResolveCompsDependency_NoDependencies() {
        Component componentD = new Component();
        componentD.setName("ComponentD");
        componentD.setDependencies(Arrays.asList());
        service.setComponents(Arrays.asList(componentD));
        List<String> resolvedComponents = ServiceApiUtil.resolveCompsDependency(service);
        assertEquals(1, resolvedComponents.size());
        assertEquals("ComponentD", resolvedComponents.get(0));
    }

    @Test
    public void testResolveCompsDependency_CircularDependency() {
        componentA.setDependencies(Arrays.asList("ComponentB"));
        componentB.setDependencies(Arrays.asList("ComponentA"));
        service.setComponents(Arrays.asList(componentA, componentB));
        List<String> resolvedComponents = ServiceApiUtil.resolveCompsDependency(service);
        assertEquals(2, resolvedComponents.size());
        // The order of circular dependencies might vary
        // depending on the implementation details
        assertEquals("ComponentB", resolvedComponents.get(0));
        assertEquals("ComponentA", resolvedComponents.get(1));
    }
}
