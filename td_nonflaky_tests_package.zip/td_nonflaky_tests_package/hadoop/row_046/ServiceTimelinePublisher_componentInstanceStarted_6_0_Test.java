package org.apache.hadoop.yarn.service.timelineservice;

import org.apache.hadoop.yarn.api.records.timelineservice.TimelineEntity;
import org.apache.hadoop.yarn.api.records.timelineservice.TimelineEvent;
import org.apache.hadoop.yarn.client.api.TimelineV2Client;
import org.apache.hadoop.yarn.service.component.instance.ComponentInstance;
import org.apache.hadoop.yarn.service.timelineservice.ServiceTimelinePublisher;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.junit.After;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.apache.hadoop.metrics2.AbstractMetric;
import org.apache.hadoop.service.CompositeService;
import org.apache.hadoop.yarn.api.records.ContainerId;
import org.apache.hadoop.yarn.api.records.FinalApplicationStatus;
import org.apache.hadoop.yarn.api.records.timelineservice.TimelineMetric;
import org.apache.hadoop.yarn.service.ServiceContext;
import org.apache.hadoop.yarn.util.timeline.TimelineUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.NavigableSet;
import java.util.TreeSet;
import static org.apache.hadoop.yarn.service.api.records.ContainerState.READY;
import static org.apache.hadoop.yarn.service.timelineservice.ServiceTimelineMetricsConstants.DIAGNOSTICS_INFO;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.apache.hadoop.yarn.service.api.records.*;

public class ServiceTimelinePublisher_componentInstanceStarted_6_0_Test {

    private TimelineV2Client mockTimelineClient;

    private ServiceTimelinePublisher serviceTimelinePublisher;

    private Container mockContainer;

    private ComponentInstance mockComponentInstance;

    @Before
    public void setUp() {
        mockTimelineClient = mock(TimelineV2Client.class);
        serviceTimelinePublisher = new ServiceTimelinePublisher(mockTimelineClient);
        mockContainer = mock(Container.class);
        mockComponentInstance = mock(ComponentInstance.class);
        when(mockContainer.getId()).thenReturn("container_123");
        when(mockContainer.getLaunchTime()).thenReturn(new Date(1000L));
        when(mockContainer.getBareHost()).thenReturn("bareHost");
        when(mockContainer.getState()).thenReturn(ContainerState.READY);
        when(mockComponentInstance.getCompName()).thenReturn("componentName");
        when(mockComponentInstance.getCompInstanceName()).thenReturn("componentInstanceName");
    }

    @Test
    public void testComponentInstanceStarted() throws Exception {
        // Invoke the method
        serviceTimelinePublisher.componentInstanceStarted(mockContainer, mockComponentInstance);
        // Capture the TimelineEntity passed to putEntity method
        ArgumentCaptor<TimelineEntity> entityCaptor = ArgumentCaptor.forClass(TimelineEntity.class);
        verify(mockTimelineClient).putEntitiesAsync(entityCaptor.capture());
        TimelineEntity capturedEntity = entityCaptor.getValue();
        // Validate entity creation
        assertEquals("container_123", capturedEntity.getId());
        assertEquals(1000L, capturedEntity.getCreatedTime().longValue());
        // Validate entity info
        Map<String, Object> expectedEntityInfos = new HashMap<>();
        expectedEntityInfos.put(ServiceTimelineMetricsConstants.BARE_HOST, "bareHost");
        expectedEntityInfos.put(ServiceTimelineMetricsConstants.STATE, ContainerState.READY.toString());
        expectedEntityInfos.put(ServiceTimelineMetricsConstants.LAUNCH_TIME, 1000L);
        expectedEntityInfos.put(ServiceTimelineMetricsConstants.COMPONENT_NAME, "componentName");
        expectedEntityInfos.put(ServiceTimelineMetricsConstants.COMPONENT_INSTANCE_NAME, "componentInstanceName");
        assertEquals(expectedEntityInfos, capturedEntity.getInfo());
        // Validate event
        NavigableSet<TimelineEvent> events = capturedEntity.getEvents();
        assertFalse(events.isEmpty());
        TimelineEvent capturedEvent = events.first();
        assertEquals(ServiceTimelineEvent.COMPONENT_INSTANCE_REGISTERED.toString(), capturedEvent.getId());
        assertEquals(1000L, (long) capturedEvent.getTimestamp());
    }
}
