package org.apache.hadoop.yarn.service.provider;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.yarn.service.api.records.ConfigFile;
import org.apache.hadoop.yarn.service.provider.AbstractClientProvider;
import org.junit.Before;
import org.junit.Test;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.hadoop.fs.FileStatus;
import org.junit.Assert;
import org.junit.After;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.yarn.service.api.records.Artifact;
import org.apache.hadoop.yarn.service.utils.ServiceUtils;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.HashSet;
import java.util.Set;
import static org.apache.hadoop.yarn.service.conf.YarnServiceConstants.CONTENT;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class AbstractClientProvider_validateConfigFiles_3_0_Test {

    private AbstractClientProvider clientProvider;

    private FileSystem mockFileSystem;

    @Before
    public void setUp() {
        clientProvider = new AbstractClientProvider() {

            @Override
            protected void validateConfigFile(ConfigFile configFile, String compName, FileSystem fileSystem) throws IOException {
                // Mock implementation for testing
            }

            @Override
            public void validateArtifact(Artifact artifact, String compName, FileSystem fs) {
                // Mock implementation for testing
            }
        };
        mockFileSystem = mock(FileSystem.class);
    }

    private void invokeValidateConfigFiles(List<ConfigFile> configFiles, String compName, FileSystem fs) throws Throwable {
        try {
            Method method = AbstractClientProvider.class.getDeclaredMethod("validateConfigFiles", List.class, String.class, FileSystem.class);
            method.setAccessible(true);
            method.invoke(clientProvider, configFiles, compName, fs);
        } catch (InvocationTargetException e) {
            throw e.getCause();
        }
    }

    @Test
    public void testValidateConfigFiles_ValidConfigFiles() {
        List<ConfigFile> configFiles = new ArrayList<>();
        ConfigFile configFile = new ConfigFile();
        configFile.setType(ConfigFile.TypeEnum.TEMPLATE);
        configFile.setSrcFile("/valid/path");
        configFile.setDestFile("/valid/dest");
        Map<String, String> properties = new HashMap<>();
        properties.put("key", "value");
        configFile.setProperties(properties);
        configFiles.add(configFile);
        try {
            when(mockFileSystem.exists(any(Path.class))).thenReturn(true);
            when(mockFileSystem.getFileStatus(any(Path.class))).thenReturn(null);
            invokeValidateConfigFiles(configFiles, "componentName", mockFileSystem);
        } catch (Throwable e) {
            fail("Exception should not be thrown: " + e.getMessage());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateConfigFiles_EmptyFileType() throws Throwable {
        List<ConfigFile> configFiles = new ArrayList<>();
        ConfigFile configFile = new ConfigFile();
        configFiles.add(configFile);
        invokeValidateConfigFiles(configFiles, "componentName", mockFileSystem);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateConfigFiles_TemplateWithoutSrcFileOrContent() throws Throwable {
        List<ConfigFile> configFiles = new ArrayList<>();
        ConfigFile configFile = new ConfigFile();
        configFile.setType(ConfigFile.TypeEnum.TEMPLATE);
        configFile.setDestFile("/valid/dest");
        configFiles.add(configFile);
        invokeValidateConfigFiles(configFiles, "componentName", mockFileSystem);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateConfigFiles_StaticWithProperties() throws Throwable {
        List<ConfigFile> configFiles = new ArrayList<>();
        ConfigFile configFile = new ConfigFile();
        configFile.setType(ConfigFile.TypeEnum.STATIC);
        configFile.setSrcFile("/valid/path");
        configFile.setDestFile("/valid/dest");
        Map<String, String> properties = new HashMap<>();
        properties.put("key", "value");
        configFile.setProperties(properties);
        configFiles.add(configFile);
        invokeValidateConfigFiles(configFiles, "componentName", mockFileSystem);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateConfigFiles_SrcFileIsDirectory() throws Throwable {
        List<ConfigFile> configFiles = new ArrayList<>();
        ConfigFile configFile = new ConfigFile();
        configFile.setType(ConfigFile.TypeEnum.STATIC);
        configFile.setSrcFile("/valid/path");
        configFile.setDestFile("/valid/dest");
    }
}
