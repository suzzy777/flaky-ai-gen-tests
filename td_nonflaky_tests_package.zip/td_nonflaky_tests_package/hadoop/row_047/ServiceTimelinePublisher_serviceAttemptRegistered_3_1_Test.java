package org.apache.hadoop.yarn.service.timelineservice;

import org.apache.hadoop.yarn.api.records.timelineservice.TimelineEntity;
import org.apache.hadoop.yarn.client.api.TimelineV2Client;
import org.apache.hadoop.conf.Configuration;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.junit.After;
import org.junit.Assert;
import org.apache.hadoop.metrics2.AbstractMetric;
import org.apache.hadoop.service.CompositeService;
import org.apache.hadoop.yarn.api.records.ContainerId;
import org.apache.hadoop.yarn.api.records.FinalApplicationStatus;
import org.apache.hadoop.yarn.api.records.timelineservice.TimelineEvent;
import org.apache.hadoop.yarn.api.records.timelineservice.TimelineMetric;
import org.apache.hadoop.yarn.service.ServiceContext;
import org.apache.hadoop.yarn.service.component.instance.ComponentInstance;
import org.apache.hadoop.yarn.util.timeline.TimelineUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import static org.apache.hadoop.yarn.service.api.records.ContainerState.READY;
import static org.apache.hadoop.yarn.service.timelineservice.ServiceTimelineMetricsConstants.DIAGNOSTICS_INFO;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.apache.hadoop.yarn.service.api.records.*;

@RunWith(MockitoJUnitRunner.class)
public class ServiceTimelinePublisher_serviceAttemptRegistered_3_1_Test {

    private ServiceTimelinePublisher publisher;

    private TimelineV2Client mockTimelineClient;

    private Service mockService;

    private Configuration mockConfiguration;

    @Before
    public void setUp() {
        mockTimelineClient = mock(TimelineV2Client.class);
        publisher = new ServiceTimelinePublisher(mockTimelineClient);
        mockService = mock(Service.class);
        when(mockService.getId()).thenReturn("service-id");
        when(mockService.getName()).thenReturn("service-name");
        when(mockService.getLaunchTime()).thenReturn(new Date());
        when(mockService.getQuicklinks()).thenReturn(new HashMap<>());
        when(mockService.getConfiguration()).thenReturn(new org.apache.hadoop.yarn.service.api.records.Configuration());
        when(mockService.getComponents()).thenReturn(new ArrayList<Component>());
        mockConfiguration = mock(Configuration.class);
        when(mockConfiguration.iterator()).thenReturn(new ArrayList<Map.Entry<String, String>>().iterator());
    }

    @Test
    public void testServiceAttemptRegistered() throws Exception {
        // Use reflection to access private methods
        java.lang.reflect.Method method = ServiceTimelinePublisher.class.getDeclaredMethod("serviceAttemptRegistered", Service.class, Configuration.class);
        method.setAccessible(true);
        // Invoke the method
        method.invoke(publisher, mockService, mockConfiguration);
        // Verify interactions
        verify(mockService, atLeastOnce()).getId();
        verify(mockService, times(1)).getName();
        // Adjusted to at least once
        verify(mockService, atLeastOnce()).getLaunchTime();
        verify(mockService, times(1)).getQuicklinks();
        verify(mockService, times(1)).getConfiguration();
        verify(mockService, times(1)).getComponents();
        // Verify that the timeline client was used to publish the entity
        verify(mockTimelineClient, times(1)).putEntitiesAsync(any(TimelineEntity.class));
    }
}
