package org.apache.hadoop.yarn.service.utils;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.yarn.service.utils.CoreFileSystem;
import org.apache.hadoop.yarn.service.conf.YarnServiceConstants;
import org.junit.Before;
import org.junit.Test;
import java.io.IOException;
import java.lang.reflect.Method;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import com.google.common.base.Preconditions;
import org.apache.hadoop.fs.CommonConfigurationKeys;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.util.VersionInfo;
import org.apache.hadoop.yarn.api.records.LocalResource;
import org.apache.hadoop.yarn.api.records.LocalResourceType;
import org.apache.hadoop.yarn.api.records.LocalResourceVisibility;
import org.apache.hadoop.yarn.api.records.URL;
import org.apache.hadoop.yarn.service.conf.SliderExitCodes;
import org.apache.hadoop.yarn.service.conf.YarnServiceConf;
import org.apache.hadoop.yarn.service.exceptions.BadClusterStateException;
import org.apache.hadoop.yarn.service.exceptions.ErrorStrings;
import org.apache.hadoop.yarn.service.exceptions.SliderException;
import org.apache.hadoop.yarn.util.Records;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

public class CoreFileSystem_buildClusterUpgradeDirPath_4_0_Test {

    private FileSystem mockFileSystem;

    private Configuration mockConfiguration;

    private CoreFileSystem coreFileSystem;

    @Before
    public void setUp() throws IOException {
        mockFileSystem = mock(FileSystem.class);
        mockConfiguration = mock(Configuration.class);
        coreFileSystem = new CoreFileSystem(mockFileSystem, mockConfiguration);
    }

    @Test(expected = NullPointerException.class)
    public void testBuildClusterUpgradeDirPathWithNullClusterName() {
        coreFileSystem.buildClusterUpgradeDirPath(null, "v1.0");
    }

    @Test(expected = NullPointerException.class)
    public void testBuildClusterUpgradeDirPathWithNullVersion() {
        coreFileSystem.buildClusterUpgradeDirPath("testCluster", null);
    }
}
