#!/usr/bin/env python3
"""Build this folder: the ChatUniTest tests generated from non-flaky focal methods, for a TD
(time-dependence) check. Copies only test files and metadata, never changes the sources.

  main/    the 94 files (175 methods) of the non-flaky side that passed the replay and went through
           rerun / NonDex / NIO / iDFlakies (../nonflaky_check_package/task_csvs/nonflaky_generated_tests.csv)
  hadoop/  the 12 hadoop YARN-9405 files (Devanshi's generation, ../hadoop_check_package/runs/); not
           replayed or checked yet
  tests.csv  one row per test method of both, with where to put the file in the project

Usage: python3 make_package.py   (run from anywhere; rewrites main/, hadoop/, tests.csv)
"""
import csv
from pathlib import Path
import re
import shutil

P = Path(__file__).resolve().parent
H = P.parent
NF = H / "nonflaky_check_package"
HD = H / "hadoop_check_package"
FIELDS = ["set", "row", "project", "sha", "zip", "archive_url", "module", "java", "junit", "generated_test",
          "file_in_package", "put_at", "focal_method", "focal_from_test", "mockito_added_at_generation",
          "mockito_fix", "checked_so_far"]
TEST = re.compile(r"@Test\b[^{;]*?\bvoid\s+(\w+)\s*\(")
PACKAGE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.M)


def read(p):
    return list(csv.DictReader(open(p, encoding="utf-8")))


def put_at(module, pkg, name):
    """Where the file goes, relative to the project root (the folder with the top pom.xml)."""
    rel = Path(*pkg.split(".")) / (name + ".java")
    return str((Path() if module in (".", "") else Path(module)) / "src" / "test" / "java" / rel)


def main():
    urls = {r["zip"]: r["url"] for r in read(NF / "archives.csv")}
    out = []
    shutil.rmtree(P / "main", ignore_errors=True)
    shutil.rmtree(P / "hadoop", ignore_errors=True)

    gen = {r["row_number"]: r for r in read(NF / "generation_results.csv")}
    for r in read(NF / "task_csvs" / "nonflaky_generated_tests.csv"):
        src = NF / r["test_file"]
        row = re.search(r"row_(\d+)", r["test_file"]).group(1)
        dest = P / "main" / f"row_{row}" / src.name
        if not dest.is_file():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
        pkg, name = r["generated_test"].split("#")[0].rsplit(".", 1)
        out.append(dict(set="main", row=row, project=r["project"], sha=r["sha"], zip=r["zip"],
                        archive_url=urls.get(r["zip"], ""), module=r["module"], java=r["java"], junit=r["junit"],
                        generated_test=r["generated_test"], file_in_package=str(dest.relative_to(P)),
                        put_at=put_at(r["module"], pkg, name), focal_method=r["focal_method"],
                        focal_from_test=r["focal_from_test"],
                        mockito_added_at_generation=gen.get(str(int(row)), {}).get("pom_added", ""),
                        mockito_fix=r["mockito_fix"], checked_so_far="rerun 100, NonDex 100, NIO, iDFlakies 20: 0 flaky"))

    man = {r["row_number"]: r for r in read(HD / "task_csvs" / "nonflaky_generate_sample.csv")}
    for g in read(HD / "generation_results.csv"):
        m = man[g["row_number"]]
        for src in sorted((HD / "runs" / f"row_{int(g['row_number']):03d}" / "tests").rglob("*.java")):
            text = src.read_text(encoding="utf-8", errors="replace")
            if not TEST.search(text):  # row 040: the generation stops after @Before, no @Test method
                print(f"hadoop row {g['row_number']}: {src.name} has no @Test method, left out")
                continue
            dest = P / "hadoop" / f"row_{int(g['row_number']):03d}" / src.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            pkg = PACKAGE.search(text).group(1)
            for meth in TEST.findall(text):
                out.append(dict(set="hadoop", row=f"{int(g['row_number']):03d}", project=m["project"],
                                sha=m["flaky_commit"], zip=m["zip"], archive_url=m["url"], module=m["module"],
                                java=m["java"], junit=g["junit"], generated_test=f"{pkg}.{src.stem}#{meth}",
                                file_in_package=str(dest.relative_to(P)), put_at=put_at(m["module"], pkg, src.stem),
                                focal_method=g["selected_method"], focal_from_test=g["flaky_test"],
                                mockito_added_at_generation=g.get("pom_added", ""), mockito_fix="unknown",
                                checked_so_far="not replayed or checked yet"))

    with open(P / "tests.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, FIELDS)
        w.writeheader()
        w.writerows(out)
    for s in ("main", "hadoop"):
        rows = [r for r in out if r["set"] == s]
        print(f"{s}: {len({r['file_in_package'] for r in rows})} files, {len(rows)} test methods")


if __name__ == "__main__":
    main()
