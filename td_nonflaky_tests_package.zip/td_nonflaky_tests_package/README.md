# ChatUniTest tests from non-flaky focal methods, for a TD check

These are the tests ChatUniTest (gpt-4o) generated for **focal methods taken from non-flaky developer tests**.
Only the test files and their metadata are included. The projects come from the ReproFlake archives (`archive_url` in `tests.csv`).

## Contents

| Folder / file | What | Files | Test methods |
|---|---|---|---|
| `main/row_NNN/` | the non-flaky side of the main study: every file that compiled and passed `mvn test` | 94 | 175 |
| `hadoop/row_NNN/` | hadoop YARN-9405, `hadoop-yarn-services-core`, generated later (a separate run) | 11 | 23 |
| `tests.csv` | one row per test method, both sets | | 198 |
| `make_package.py` | rebuilds this folder from our working folders (for us; not needed to run anything) | | |

`main/`: 93 focal methods, 11 projects. One focal method has 2 files.

**JDK and JUnit** (test methods):

| | JDK 8 + JUnit 4 | JDK 8 + JUnit 5 | JDK 11 + JUnit 4 | JDK 11 + JUnit 5 |
|---|---|---|---|---|
| main | 59 (31 files) | 16 | 58 | 42 |
| hadoop | 23 (11 files) | - | - | - |

No project needs JDK 17.

## `tests.csv` columns

| Column | Meaning |
|---|---|
| `set` | `main` or `hadoop` |
| `row` | generation row (folder `row_NNN`) |
| `project`, `sha`, `zip`, `archive_url` | the project, its commit, and the ReproFlake archive |
| `module` | Maven module, relative to the project root (`.` = root) |
| `java`, `junit` | JDK to use, JUnit version of the test |
| `generated_test` | `package.Class#method` |
| `file_in_package` | the test file in this folder |
| `put_at` | where the file goes, relative to the project root (inside the archive: `<zip>/Flaky/`; for hadoop: `YARN-9405/Flaky/`) |
| `focal_method` | the method the test was generated for |
| `focal_from_test` | the non-flaky developer test the focal method was taken from |
| `mockito_added_at_generation` | Mockito dependencies we added to the module `pom.xml` (test scope, version 4.11.0) before generation; the test does not compile without them (7 rows) |
| `mockito_fix` | `true` = passes only with the Mockito fix below (21 methods, 12 files) |
| `checked_so_far` | what we already ran on it |

## Setup per file

1. Unpack the archive. Copy the file from `file_in_package` to `put_at`, under `<zip>/Flaky/`.
2. If `mockito_added_at_generation` is set, add those dependencies to the module's `pom.xml` with test scope and version 4.11.0:
   - `org.mockito:mockito-core`;
   - for JUnit 5 also `org.mockito:mockito-junit-jupiter`.
3. If `mockito_fix` is `true`, replace the pom's Mockito entry with the following, declared **first** in `<dependencies>`, all with test scope:
   - `org.mockito:mockito-core:4.11.0`
   - `org.mockito:mockito-inline:4.11.0`
   - `net.bytebuddy:byte-buddy:1.12.19`
   - `net.bytebuddy:byte-buddy-agent:1.12.19`
   - `org.objenesis:objenesis:3.3`

   For JUnit 5 add `org.mockito:mockito-junit-jupiter:4.11.0` as well. Declared first, this beats an older byte-buddy pinned by a parent pom, and a `mockito-all` 1.x jar.
4. Run with the JDK from `java`, for example `mvn test -pl <module> -Dtest=<Class>#<method>`.

## What we already checked (`main`)

- 100 reruns per method, NonDex 100 seeds, NIO, iDFlakies 20 rounds: **0 of 175 flaky**.
- No confirmed polluters.
- **TD (time dependence) was not checked.** That's what this package is for.

## `hadoop`: caveats

- **Not replayed yet.** We don't know yet whether these 11 files compile and pass. Expect some that don't.
- Building needs JDK 8 and `protoc` 2.5.0 on the PATH.
- Row 040's file was left out: its generated code stops after `@Before` and has no `@Test` method.
