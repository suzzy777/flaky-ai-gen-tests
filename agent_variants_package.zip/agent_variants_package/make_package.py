#!/usr/bin/env python3
"""Build agent_variants_package/ (student 2): mini-swe-agent with Claude Opus in conditions A, F, FC and
FCV, 3 runs per focal method, on focal methods chosen from her Opus run on the 53 (agent_main_package),
then the main study's flakiness checks. Copies only; nothing outside this folder is changed.
  agent_experiment/   run_agent.py, agent_config.yaml (Opus), get_archives.py, requirements.txt from
                      agent_main_package/agent_experiment/, plus make_runs.py (new)
  prompt_experiment/  the two modules run_agent.py imports (from agent_main_package/prompt_experiment/)
  inputs/             manifest53.csv and prompts53/ (the 53 rows and their ChatUniTest prompts),
                      focal_rows.txt (which of the 53 to run; filled in later)
  checks/             agent_checks_package's scripts, m8/, od_recheck/, inputs/projects.csv; its run.sh
                      reads ../agent_experiment and runs A F FC FCV by default
Usage: python3 make_package.py
"""
from pathlib import Path
import shutil

P = Path(__file__).resolve().parent
H = P.parent
M = H / "agent_main_package"
K = H / "agent_checks_package"


def main():
    (P / "agent_experiment").mkdir(exist_ok=True)
    for f in ["run_agent.py", "agent_config.yaml", "get_archives.py", "requirements.txt"]:
        shutil.copy2(M / "agent_experiment" / f, P / "agent_experiment" / f)
    (P / "prompt_experiment").mkdir(exist_ok=True)
    for f in ["batch_reproflake_chatunitest.py", "collect_nonflaky.py"]:
        shutil.copy2(M / "prompt_experiment" / f, P / "prompt_experiment" / f)
    (P / "inputs").mkdir(exist_ok=True)
    shutil.copy2(M / "agent_experiment" / "manifest.csv", P / "inputs" / "manifest53.csv")
    if not (P / "inputs" / "prompts53").exists():
        shutil.copytree(M / "agent_experiment" / "prompts", P / "inputs" / "prompts53")
    C = P / "checks"
    (C / "inputs").mkdir(parents=True, exist_ok=True)
    for f in ["flaky_check_basic.py", "od_confirm.py", "batch_reproflake_chatunitest.py", "collect_nonflaky.py",
              "replay_generated.py", "make_tests_csv.py", "collect_summary.py", "setup_m8.sh"]:
        shutil.copy2(K / f, C / f)
    shutil.copy2(K / "inputs" / "projects.csv", C / "inputs" / "projects.csv")
    (C / "od_recheck").mkdir(exist_ok=True)
    shutil.copy2(K / "od_recheck" / "od_recheck.py", C / "od_recheck" / "od_recheck.py")
    if not (C / "m8").exists():
        shutil.copytree(K / "m8", C / "m8")
    run = (K / "run.sh").read_text(encoding="utf-8")
    for a, b in [('AG="${AGENT_DIR:-$D/../agent_main_package/agent_experiment}"',
                  'AG="${AGENT_DIR:-$D/../agent_experiment}"'),
                 ('run agent_main_package first, or set AGENT_DIR', 'run: bash run.sh setup'),
                 ('for c in ${CONDITIONS:-A}; do', 'for c in ${CONDITIONS:-A F FC FCV}; do'),
                 ('#   bash run.sh                   condition A, 4 lanes',
                  '#   bash run.sh                   conditions A F FC FCV, 4 lanes'),
                 ("# The main study's flakiness checks on the agent's tests from agent_main_package (out_<condition>/), with",
                  "# The main study's flakiness checks on the agent's tests in ../agent_experiment/out_<condition>/, with")]:
        if run.count(a) != 1:
            raise SystemExit(f"checks/run.sh: {a!r} not found once")
        run = run.replace(a, b)
    (C / "run.sh").write_text(run, encoding="utf-8")
    n = sum(1 for _ in open(P / "inputs" / "manifest53.csv", encoding="utf-8")) - 1
    print(f"package ready: {n} rows to choose from, {len(list((P / 'inputs' / 'prompts53').iterdir()))} prompts")


if __name__ == "__main__":
    main()
