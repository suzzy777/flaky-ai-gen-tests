#!/usr/bin/env python3
"""Build manifest.csv and prompts/ for run_agent.py: every row of ../inputs/focal_rows.txt (row numbers of
the 53 in ../inputs/manifest53.csv), RUNS times (default 3), numbered 1..N. Each run gets the row's own
ChatUniTest prompt (../inputs/prompts53/row_NNN/). Added columns: main_row (the row in the 53), run.
Once a condition has results (out_*/), manifest.csv may only grow at the end (rows added at the end of
focal_rows.txt), so the row numbers of earlier results stay valid.
Usage: python3 make_runs.py
"""
import csv
import io
import os
from pathlib import Path
import shutil
import sys

E = Path(__file__).resolve().parent
I = E.parent / "inputs"


def main():
    runs = int(os.environ.get("RUNS", "3"))
    want = []
    for line in open(I / "focal_rows.txt", encoding="utf-8"):
        line = line.split("#")[0].strip()
        if line:
            want.append(line)
    if not want:
        sys.exit("inputs/focal_rows.txt has no rows yet")
    main_rows = {r["row_number"]: r for r in csv.DictReader(open(I / "manifest53.csv", encoding="utf-8"))}
    bad = [w for w in want if w not in main_rows]
    if bad:
        sys.exit(f"not rows of the 53: {' '.join(bad)}")
    cols = list(next(iter(main_rows.values()))) + ["main_row", "run"]
    out = []
    for w in want:
        for k in range(1, runs + 1):
            out.append({**main_rows[w], "row_number": str(len(out) + 1), "main_row": w, "run": str(k)})
    buf = io.StringIO()
    wr = csv.DictWriter(buf, cols, lineterminator="\n")
    wr.writeheader()
    wr.writerows(out)
    man = E / "manifest.csv"
    # rows added at the end of focal_rows.txt only add rows; any other change would renumber earlier results
    if man.is_file() and not buf.getvalue().startswith(man.read_text(encoding="utf-8")) and list(E.glob("out_*")):
        sys.exit("manifest.csv would change, but out_*/ already has results: add new rows only at the end "
                 "of focal_rows.txt, or move out_*/ away first")
    man.write_text(buf.getvalue(), encoding="utf-8")
    shutil.rmtree(E / "prompts", ignore_errors=True)
    for r in out:
        shutil.copytree(I / "prompts53" / f"row_{int(r['main_row']):03d}", E / "prompts" / f"row_{int(r['row_number']):03d}")
    print(f"manifest.csv: {len(want)} focal methods x {runs} runs = {len(out)} rows, "
          f"{len({r['zip'] for r in out})} archives")


if __name__ == "__main__":
    main()
