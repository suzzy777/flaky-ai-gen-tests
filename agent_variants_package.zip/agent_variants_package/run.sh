#!/bin/bash
# mini-swe-agent (Claude Opus, agent_experiment/agent_config.yaml) in conditions A, F, FC and FCV, 3 runs
# per focal method, on the rows of inputs/focal_rows.txt (chosen from the 53 of agent_main_package), then
# the main study's flakiness checks (checks/run.sh).
# Usage (inside tmux, ANTHROPIC_API_KEY exported in that shell):
#   bash run.sh setup          once: Python venv, manifest (make_runs.py), archives, Flakym2 artifacts
#   bash run.sh agent          conditions A F FC FCV (resumable: finished rows are skipped)
#   bash run.sh agent 1 2      only these rows (e.g. a first test)
#   bash run.sh checks         after the agent: the checks of all four conditions (resumable)
#   CONDITIONS="A F" bash run.sh agent    (same for checks) only these conditions
# Results: agent_experiment/out_<cond>/, checks/out_checks_<cond>/ (summary.txt, summary_all.csv).
D="$(cd "$(dirname "$0")" && pwd)"
A="$D/agent_experiment"
REPO="${MAVEN_REPO:-$HOME/.m2/repository}"
step="$1"; shift

case "$step" in
setup)
  command -v mvn >/dev/null || { echo "mvn is not on the PATH"; exit 1; }
  # the agent's Python packages, the versions machine A used
  if [ ! -x "$A/venv/bin/python" ]; then
    python3 -m venv "$A/venv" && "$A/venv/bin/pip" install -q "mini-swe-agent==2.4.6" "litellm==1.106.4" "PyYAML==6.0.3" || exit 1
  fi
  python3 "$A/make_runs.py" || exit 1
  python3 "$A/get_archives.py" || exit 1
  mkdir -p "$REPO"
  # each project's own Maven artifacts (as setup_archives.py does); existing files are kept
  for a in "$A"/extracted/*/; do z=$(basename "$a"); [ -d "$a/$z/Flakym2/.m2/repository" ] && cp -rn "$a/$z/Flakym2/.m2/repository/." "$REPO/"; done
  echo "setup done; next: bash run.sh agent 1   (a first test), then bash run.sh agent"
  ;;
agent)
  [ -n "$ANTHROPIC_API_KEY" ] || { echo "export ANTHROPIC_API_KEY first"; exit 1; }
  [ -f "$A/manifest.csv" ] || { echo "run setup first"; exit 1; }
  ONLY=(); for r in "$@"; do ONLY+=(--only "$r"); done
  [ -n "$REDO" ] && ONLY+=(--redo)
  for c in ${CONDITIONS:-A F FC FCV}; do
    # spending so far (all conditions); a condition is not started once it reaches MAX_USD
    spent=$("$A/venv/bin/python" -c "
import csv, glob
print(round(sum(float(x.get('cost_usd') or 0) for f in glob.glob('$A/out_*/generation_results.csv') for x in csv.DictReader(open(f))), 2))")
    "$A/venv/bin/python" -c "import sys; sys.exit(0 if $spent < ${MAX_USD:-40} else 1)" || {
      echo "spent \$$spent of MAX_USD=\$${MAX_USD:-40}: condition $c not started (MAX_USD=60 bash run.sh agent to allow more)"; break; }
    echo "condition $c (spent so far \$$spent)"
    "$A/venv/bin/python" "$A/run_agent.py" --condition $c "${ONLY[@]}" 2>&1 | tee -a "$A/agent_$c.log"
    grep -q "authentication_error\|invalid x-api-key\|credit balance" "$A/agent_$c.log" && echo "WARNING: API key or credit errors in agent_$c.log, check it"
  done
  "$A/venv/bin/python" - "$A" <<'EOF'
import csv, sys
from pathlib import Path
for d in sorted(Path(sys.argv[1]).glob("out_*")):
    r = list(csv.DictReader(open(d / "generation_results.csv"))) if (d / "generation_results.csv").is_file() else []
    print(f"{d.name}: {len(r)} rows, {sum(x['status'] == 'generated' for x in r)} generated, "
          f"${sum(float(x.get('cost_usd') or 0) for x in r):.2f}")
EOF
  ;;
checks)
  bash "$D/checks/run.sh"
  ;;
*)
  sed -n 5,11p "$0"; exit 1 ;;
esac
