# Agent conditions with Claude Opus, then the flakiness checks

**What:** mini-swe-agent with Claude Opus 5.5 writes tests in the four conditions of the 10-focal experiment (A, F, FC, FCV), 3 runs per focal method and condition, as gpt-4o did. Then the main study's flakiness checks run on all of them.

**Which focal methods:** the ones where your Opus run on the 53 (agent_main_package, condition A) gave a test that was a polluter, victim or state-setter, or that writes static or singleton state. This is the same rule we used to pick gpt-4o's 10 focal methods from gpt-4o's tests. They are listed in `inputs/focal_rows.txt` (row numbers of the 53, with the reason for each): 9 focal methods, 7 that write static or singleton state (read from your tests) and the 2 marine-api victims from your checks. The wildfly victim is still missing, because we don't know its row yet. Please upload your `out_checks_A/` (or tell us the row): we then add it at the end of `focal_rows.txt`, and `bash run.sh setup` followed by `bash run.sh agent` runs only the new rows.

The conditions (the same prompts as in the gpt-4o runs; Opus is set in `agent_experiment/agent_config.yaml`):
- A: ChatUniTest's prompt for the focal method, plus how to write and run the test;
- F: also told to read the project's existing tests first;
- FC: also told to restore any static field, singleton or field set by reflection in @After;
- FCV: also told not to assume shared state is in its default state, and to set up what the test needs in @Before.

Each run starts from a fresh copy of the project, so the 3 runs don't see each other. Your earlier run on the 53 isn't reused, because the focal methods were chosen from it.

**Needs:** the same as agent_main_package (Linux, Python 3.10 or newer, Maven, JDK 8 and 11, `ANTHROPIC_API_KEY`), plus about 10 GB of disk. The archives are downloaded again into `agent_experiment/extracted/`, so agent_main_package's copies are left alone. Run this package on its own: no other Maven jobs, and not at the same time as agent_main_package's checks.

**Steps** (inside tmux, `tmux new -s variants`, with `export ANTHROPIC_API_KEY=...` in that shell):
1. `bash run.sh setup`. It makes the Python setup, builds `agent_experiment/manifest.csv` (each focal method 3 times) and downloads the archives. It prints how many rows there are.
2. A first test: `CONDITIONS=A bash run.sh agent 1`. Then check `agent_experiment/out_A/generation_results.csv`: row 1 should be `generated` with a cost above 0.
3. All conditions: `bash run.sh agent`. It runs A, then F, FC and FCV, and prints the rows and cost per condition at the end. If it stops, run the same line again: finished rows are skipped.
   - It doesn't start a new condition once the total cost reaches $40. To allow more: `MAX_USD=60 bash run.sh agent`.
   - If you see key or credit errors (the script warns), stop it with Ctrl+C. The failed rows are recorded, so delete that condition's `agent_experiment/out_<cond>/` before running again.
4. Checks: `bash run.sh checks`. These are the same checks as agent_checks_package (iDFlakies 20 rounds with od_confirm and od_recheck, NIO 100, NonDex 100, 100 reruns), for all four conditions one after another. They can be restarted the same way. To check only some conditions: `CONDITIONS="A F" bash run.sh checks`.

**Estimate:** your Opus run on the 53 cost $0.17 per row on average. 9 focal methods x 3 runs x 4 conditions = 108 runs, so roughly $15-25, and a day or two for the agent. The checks take several days and have no API cost.

**Bring back:**
- `agent_experiment/out_A/`, `out_F/`, `out_FC/`, `out_FCV/` (without `extracted`), and `agent_experiment/agent_*.log`;
- `checks/out_checks_A/` ... `checks/out_checks_FCV/` (`summary.txt`, `summary_all.csv` and the lane folders);
- `agent_experiment/manifest.csv` and `inputs/focal_rows.txt`.
