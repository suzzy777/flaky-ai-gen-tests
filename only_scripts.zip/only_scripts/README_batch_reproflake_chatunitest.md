# Run JUnit 4 ChatUniTest on the 144 ReproFlake tests

This automation uses `result_matched (1).csv` to locate the **existing** flaky test for each row, identify its focal method using **Jaccard + LLM agreement**, build the project, and run the ChatUniTest `:method` goal in the JUnit version the flaky test uses. It does **not** run or validate generated tests automatically.

JUnit version is detected per row from the flaky test's imports and written to the manifest's `junit` column (edit it to override):

| `junit` | How the test is recognised | ChatUniTest mode |
|---|---|---|
| 5 | imports `org.junit.jupiter` | stock JUnit 5 mode (no `-Dchatunitest.junit`) |
| 4 | `@Test` with `org.junit` imports | patched JUnit 4 mode (`-Dchatunitest.junit=4`, `prompts-junit4`) |
| 3 | extends `TestCase` / imports `junit.framework`; tests are `public void test*()` | JUnit 4 mode (JUnit 4 runs JUnit 3 suites); skipped if a POM pins junit 3.x |
| blank | none of the above | skipped (`skipped_junit`) until you fill it in |

The CSV contains 144 test rows, 80 distinct ZIP archives, and 44 GitHub project URLs. The same ZIP is extracted once and can serve multiple test rows.

## 1. Install/clone prerequisites (Mac or Linux)

```bash
python3 -m pip install javalang

git clone https://github.com/devanshik19/srse-flakiness-research.git focal-repo
git clone https://github.com/QueenNana37/srse-flakiness-research.git junit4-repo

# Must already have patched core 2.1.1 installed into the SAME local Maven repo:
# https://github.com/QueenNana37/srse-flakiness-research/blob/main/chatunitest-junit4/README.md
export OPENAI_API_KEY="your-api-key"

mkdir -p reproflake-zips
```

Place **this script** and **the original CSV** in the same working directory, or supply their full paths. `--archives` should contain either extracted `<zip>/` directories or `<zip>.zip` files. `--download` can fetch missing archives from the CSV's Zenodo `url` column. Add `--delete-zips` to delete each ZIP once it is extracted; the 80 archives are about 13 GB zipped and about as much again extracted, so this roughly halves peak disk use. The files may be large; use existing downloaded ZIPs when possible.

## 2. Pilot: locate sources without spending API money

```bash
python3 batch_reproflake_chatunitest.py prepare \
  --csv 'result_matched (1).csv' \
  --archives ./reproflake-zips \
  --out ./batch_output \
  --limit 1
```

If the archive is not present, add `--download` to explicitly fetch it. Check `batch_output/focal_manifest.csv` for the status and located Java test source file. Each archive includes a module; the script searches for the exact `src/test/java/.../TestClass.java` and its sibling `pom.xml`, and will **not guess** if multiple files match.

## 3. Identify the focal method with Jaccard + LLM

Start with one row:

```bash
python3 batch_reproflake_chatunitest.py prepare \
  --csv 'result_matched (1).csv' \
  --archives ./reproflake-zips \
  --focal-scripts ./focal-repo/archive/03_focal_methods \
  --out ./batch_output \
  --download --run-llm --limit 1
```

Then prepare all 144 rows by removing `--limit 1`:

```bash
python3 batch_reproflake_chatunitest.py prepare \
  --csv 'result_matched (1).csv' \
  --archives ./reproflake-zips \
  --focal-scripts ./focal-repo/archive/03_focal_methods \
  --out ./batch_output \
  --download --run-llm
```

The Python driver imports these existing repository functions rather than reimplementing their algorithms:

- `focal_extract.py`: extracts project-method candidates from the source test.
- `focal_method_finder_batch.py`: ranks candidates by name-token Jaccard similarity.
- `llm_focal.py`: calls GPT on **only the target test** in the CSV (not every test in its file).

It compares their method-name predictions. A unique Jaccard/LLM agreement is mapped to a production `package.Class#method`. **If there are multiple production classes, method overloads, ambiguous/tied scores, disagreements, missing sources, or parser errors, the selection is left blank and flagged for manual review.** In `batch_output/focal_manifest.csv`, inspect `status`, `note`, `production_candidates`, and `selected_method`. Fill the `selected_method` field manually when you can confirm the correct production class and method. For overloads, consult the patched JUnit 4 README's `#<method number>` selection guidance.

**Parse fallback (`parse_mode` column).** `javalang` only understands Java 8 syntax, so a single unsupported construct anywhere in a test file used to fail the whole row. When the file does not parse, the driver cuts out just the target test method (same brace matching `llm_focal.py` uses for the prompt), parses it inside a dummy class, and runs the normal Jaccard + LLM steps on it (`parse_mode=method_only`; otherwise `file`). If the method itself still does not parse, annotations on classes declared inside the method are blanked for parsing only; annotation values cannot contain method calls, so the candidates are unchanged, and the LLM still gets the original body. Both focal steps only use the test's own name and body, so this gives the same result as a whole-file parse: on the pilot files that do parse, all 60 test methods gave identical tokens, candidates and LLM prompt body either way, with both PyPI javalang 0.13.0 and the git build.

Re-running `prepare` normally preserves manually or automatically filled selections; use `--force` to redo them. Cached LLM prompts are stored in `batch_output/llm_cache.json` so repeated prompts do not incur more API charges. **The LLM probability numbers are model estimates, not calibrated confidence scores.**

## 4. Preview, then generate tests

Preview one planned command (no API calls):

```bash
python3 batch_reproflake_chatunitest.py generate \
  --manifest ./batch_output/focal_manifest.csv \
  --junit4-dir ./junit4-repo/chatunitest-junit4 \
  --out ./batch_output \
  --limit 1
```

Run **one** generation as a pilot:

```bash
python3 batch_reproflake_chatunitest.py generate \
  --manifest ./batch_output/focal_manifest.csv \
  --junit4-dir ./junit4-repo/chatunitest-junit4 \
  --out ./batch_output \
  --limit 1 --execute
```

Generate for all *confirmed* focal methods:

```bash
python3 batch_reproflake_chatunitest.py generate \
  --manifest ./batch_output/focal_manifest.csv \
  --junit4-dir ./junit4-repo/chatunitest-junit4 \
  --out ./batch_output \
  --execute --resume
```

Optional JDK selection for the CSV's Java 8/11/17 values (macOS examples):

```bash
export JAVA_HOME_8=$(/usr/libexec/java_home -v 1.8)
export JAVA_HOME_11=$(/usr/libexec/java_home -v 11)
export JAVA_HOME_17=$(/usr/libexec/java_home -v 17)
```

These are optional: if `JAVA_HOME_<v>` is unset the driver looks for a matching JDK under `/usr/lib/jvm` or `/Library/Java/JavaVirtualMachines`, and only falls back to the current `java` if none is found.

Before ChatUniTest runs, `generate --execute` builds each module once per JDK with `mvn install -DskipTests` (plus skips for rat/checkstyle/enforcer/jacoco/javadoc and similar), using `-pl <module> -am` from the project root for multi-module projects. ChatUniTest fails without the module's `target/*.jar`. The build log is `runs/row_NNN/build.log`; a `.batch_built` stamp in the module avoids rebuilding. Maven uses `~/.m2/repository` by default; override with `--maven-repo /your/path` if your patched core was installed elsewhere.

## Results and necessary validation

- `batch_output/focal_manifest.csv`: one row per input test, status of identification, and focal method selection.
- `batch_output/llm_cache.json`: API result cache (no API keys).
- `batch_output/runs/row_NNN/tmp/` and `.../tests/`: separate ChatUniTest outputs per input row so generations don't overwrite one another.
- `batch_output/runs/row_NNN/maven.log`: Maven generator log.
- `batch_output/generation_results.csv`: per row `build_status`, `status`, `tests_generated`, `api_errors`. `status` is `generated` (ChatUniTest wrote at least one test file), `api_error` (no tests and OpenAI calls failed, e.g. bad key or quota; Maven still says BUILD SUCCESS in this case), `no_tests`, `maven_failed`, `build_failed`, `timeout`, `skipped_junit` or `missing_pom`. **`generated` does NOT mean tests compiled and passed.**

**Next step:** Inspect each generated test, compile/run it in the corresponding project/module, and verify Surefire reports `Tests run: N` with **N > 0** and the generated test actually executed. ReproFlake's existing tests are known flaky, so ordinary aggregate Maven test failure is not necessarily caused by the generated test. Don't use Maven `BUILD SUCCESS` alone as your validation signal. Record separately whether the generated test compiled, ran, passed, and later proved flaky.

**Limits:** The archive must actually contain the Java test and Maven POM; `javalang` cannot parse every modern Java syntax feature (rows whose target test method itself does not parse still fail with `identify_error`); the focal method may not be uniquely inferred; this script generates **one ChatUniTest run per confirmed CSV row**, which might include repeated focal methods. Do not treat 144 test rows as 144 distinct production focal methods. The generator and tests are not executed by simply downloading these files; you must run them in your own checkout/container with Java, Maven, and OpenAI API access.
