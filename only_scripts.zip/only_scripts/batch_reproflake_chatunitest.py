#!/usr/bin/env python3
"""ReproFlake (144-row CSV) -> focal-method identification -> ChatUniTest JUnit 4.

Stages:
  prepare: find existing JUnit test sources, run Jaccard + (opt-in) LLM,
           intersect predictions and resolve production class. Writes review CSV.
  generate: run patched ChatUniTest :method for reviewed selections.

No OpenAI calls or Maven executions without explicit --run-llm / --execute.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

EXTRA = ["row_number", "archive_root", "test_file", "module_dir", "junit", "parse_mode", "jaccard_method",
         "jaccard_score", "jaccard_ambiguous", "llm_method", "llm_score",
         "production_candidates", "selected_method", "status", "note"]
GEN_FIELDS = ["row_number", "zip", "flaky_test", "selected_method", "junit", "chatunitest_mode",
              "build_status", "status", "exit_code", "tests_generated", "api_errors",
              "log_file", "tmp_output", "test_output"]
PLUGIN = "io.github.zju-aces-ise:chatunitest-maven-plugin:2.1.1:method"
# Plugins that commonly fail or slow down a source-only build; none affect compiled classes.
BUILD_SKIPS = ["-DskipTests", "-Drat.skip", "-Dcheckstyle.skip", "-Denforcer.skip", "-Djacoco.skip",
               "-Dmaven.javadoc.skip", "-Danimal.sniffer.skip", "-Dspotbugs.skip", "-Dpmd.skip",
               "-Dlicense.skip", "-Dgpg.skip", "-Djapicmp.skip", "-Dspotless.check.skip",
               "-Dmaven.source.skip"]


def load_rows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        required = {"zip", "module", "flaky_test", "java", "url"}
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"Missing required CSV columns: {sorted(missing)}")
        return rows, list(reader.fieldnames)


def csv_write(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_previous(path):
    if not path.exists():
        return {}
    with path.open(newline="", encoding="utf-8-sig") as f:
        return {int(row["row_number"]): row for row in csv.DictReader(f)}


def load_module(path, filename, tag):
    source = path / filename
    if not source.is_file():
        raise FileNotFoundError(f"Required focal script not found: {source}")
    spec = importlib.util.spec_from_file_location(tag, str(source))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha256(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def save_json_atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)


def safe_extract(zippath, dest):
    dest.mkdir(parents=True, exist_ok=True)
    base = dest.resolve()
    with zipfile.ZipFile(zippath) as z:
        for zi in z.infolist():
            name = zi.filename
            target = (base / name).resolve()
            if target != base and base not in target.parents:
                raise ValueError(f"Unsafe ZIP entry: {name}")
            # Don't recreate symlinks from a ZIP.
            if ((zi.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError(f"Symlink in ZIP: {name}")
        z.extractall(base)


def get_archive(row, args):
    """Expect archives/<zip>/ extracted or archives/<zip>.zip; optional download."""
    archive_name = row["zip"]
    if archive_name in ("", ".", "..") or "/" in archive_name or "\\" in archive_name:
        raise ValueError(f"Unexpected ZIP identifier: {archive_name!r}")
    path = args.archives / archive_name
    if path.is_dir():
        return path.resolve()
    unpacked = args.out / "extracted" / archive_name
    if unpacked.is_dir() and (unpacked / ".batch_extracted").is_file():
        return unpacked.resolve()
    zpath = args.archives / (archive_name + ".zip")
    if not zpath.is_file() and args.download:
        url = row["url"].strip()
        if not url.startswith("https://zenodo.org/records/") or not url.endswith(".zip"):
            raise ValueError("Refusing unexpected archive URL (expected HTTPS Zenodo ZIP)")
        zpath.parent.mkdir(parents=True, exist_ok=True)
        print(f"  Downloading {archive_name} ...", flush=True)
        temp = zpath.with_suffix(".zip.part")
        try:
            with urllib.request.urlopen(url, timeout=180) as source, temp.open("wb") as sink:
                shutil.copyfileobj(source, sink)
            temp.replace(zpath)
        finally:
            if temp.exists():
                temp.unlink()
    if zpath.is_file():
        print(f"  Extracting {archive_name} ...", flush=True)
        safe_extract(zpath, unpacked)
        (unpacked / ".batch_extracted").touch()
        if args.delete_zips:
            # The extracted copy is all later stages use; this halves peak disk use.
            zpath.unlink()
        return unpacked.resolve()
    raise FileNotFoundError(f"Need {path}/ or {zpath}; use --download for Zenodo ZIPs")


def locate_test(root, module_name, test_id):
    """Find exact package/Class.java under src/test/java; never guess on ties."""
    fq_class, sep, method = test_id.partition("#")
    if not sep or not fq_class or not method:
        raise ValueError(f"Unexpected test ID: {test_id}")
    rel = Path(*fq_class.split("."))
    expected_tail = tuple(["src", "test", "java", *rel.with_suffix(".java").parts])
    names = []
    for f in root.rglob(rel.name + ".java"):
        if tuple(f.parts[-len(expected_tail):]) == expected_tail:
            names.append(f.resolve())
    if not names:
        raise FileNotFoundError(f"Test source {('/'.join(expected_tail))} not found")

    if module_name not in ("", ".") and len(names) > 1:
        module_parts = tuple(Path(module_name).parts)
        matches = []
        for f in names:
            ps = f.parts
            for i in range(len(ps) - len(module_parts) + 1):
                if ps[i:i + len(module_parts)] == module_parts:
                    matches.append(f)
                    break
        if matches:
            names = matches
    if len(names) != 1:
        raise ValueError("Ambiguous test file locations: " + "; ".join(map(str, names[:6])))

    f = names[0]
    parts = f.parts
    for i in range(len(parts) - 2):
        if parts[i:i + 3] == ("src", "test", "java"):
            root_dir = Path(*parts[:i])
            if not (root_dir / "pom.xml").is_file():
                raise FileNotFoundError(f"Maven pom.xml missing next to test source: {root_dir}")
            return f, root_dir.resolve(), method
    raise ValueError(f"Couldn't locate Maven module for {f}")


def detect_junit(src):
    """JUnit style of the existing flaky test file: "5", "4", "3" or "" (unknown)."""
    if re.search(r"^\s*import\s+(static\s+)?org\.junit\.jupiter\.", src, re.M):
        return "5"
    has_test_annotation = re.search(r"@(org\.junit\.)?Test\b", src)
    if has_test_annotation and re.search(r"^\s*import\s+(static\s+)?org\.junit\.(?!jupiter|platform|vintage)", src, re.M):
        return "4"
    if re.search(r"\bextends\s+[\w.]*TestCase\b", src) or re.search(r"^\s*import\s+junit\.framework\.", src, re.M):
        return "3"
    return "4" if has_test_annotation else ""


def is_junit3_test(m):
    # JUnit 3 runs every public void no-arg method whose name starts with "test".
    return (m.name.startswith("test") and not m.parameters and m.return_type is None
            and "public" in m.modifiers)


def junit3_only(module_dir, archive_root):
    """True when a POM between the module and the archive root pins junit 3.x."""
    d = module_dir
    while True:
        pom = d / "pom.xml"
        if pom.is_file():
            s = pom.read_text(encoding="utf-8", errors="replace")
            if re.search(r"<junit\.version>\s*3\.", s) or re.search(
                    r"<artifactId>junit</artifactId>\s*<version>\s*3\.", s):
                return True
        if d == archive_root or d == d.parent:
            return False
        d = d.parent


def find_jdk(version):
    """JAVA_HOME_<v> if set, otherwise a matching JDK in the usual Linux/macOS locations."""
    if not version:
        return None
    env = os.environ.get("JAVA_HOME_" + version)
    if env:
        return env
    patterns = [f"java-{version}-openjdk*", f"java-1.{version}.0-openjdk*", f"openjdk-{version}*",
                f"jdk-{version}*", f"jdk{version}*", f"temurin-{version}*", f"jdk1.{version}*"]
    for base in (Path("/usr/lib/jvm"), Path("/Library/Java/JavaVirtualMachines")):
        if not base.is_dir():
            continue
        for pat in patterns:
            for p in sorted(base.glob(pat)):
                home = p / "Contents" / "Home" if (p / "Contents" / "Home").is_dir() else p
                if (home / "bin" / "java").exists():
                    return str(home)
    return None


def method_line(m):
    # PyPI javalang 0.13.0 calls it `position`; builds from git master call it `start_position`.
    pos = getattr(m, "position", None) or getattr(m, "start_position", None)
    return pos.line if pos else None


def isolate_test_method(src, method, javalang, extract_body):
    """Parse one test method on its own, for test files javalang can't parse as a whole.

    The focal scripts only look at the test's own name and body, so the result is the same as
    a whole-file parse. Returns (MethodDeclaration, 1-based line of its `void` return type, which
    is the line javalang reports for a method, after its annotations and modifiers).
    """
    lines = src.split("\n")
    sig = re.compile(r"\bvoid\s+" + re.escape(method) + r"\s*\(")
    hits = [i for i, line in enumerate(lines) if sig.search(line)]
    if len(hits) != 1:
        raise ValueError(f"Found {len(hits)} declarations of {method} while isolating it")
    start = hits[0]
    # Keep the annotations above so the isolated method is still recognisably a test.
    while start > 0 and lines[start - 1].strip().startswith("@"):
        start -= 1
    for first in dict.fromkeys((start, hits[0])):
        text = extract_body(lines, first + 1)
        if not text:
            continue
        # javalang rejects annotations on classes declared inside a method. Annotation values
        # can't contain method calls, so blanking them leaves the candidate calls unchanged.
        for attempt in (text, LOCAL_CLASS_ANNOTATIONS.sub(lambda mo: re.sub(r"\S", " ", mo.group(0)), text)):
            try:
                cu = javalang.parse.parse("class IsolatedTest {\n" + attempt + "\n}")
            except Exception:
                continue
            ms = [m for m in cu.types[0].methods if m.name == method]
            if len(ms) == 1:
                return ms[0], hits[0] + 1
    raise ValueError(f"Could not parse {method} on its own either")


# One or more annotations directly before a (final/abstract/static) local `class` declaration.
LOCAL_CLASS_ANNOTATIONS = re.compile(
    r"(?:@[\w.]+(?:\s*\((?:[^()]|\([^()]*\))*\))?\s+)+(?=(?:(?:final|abstract|static)\s+)*class\s)")


def project_method_filter(extractor, testfile, cache):
    """Same candidate filter focal_extract.main uses: methods defined under src/main."""
    src_main = extractor.find_src_main(str(testfile))
    if not src_main:
        return lambda n: n.lower() not in extractor.LIBRARY_CALLS
    if src_main not in cache:
        cache[src_main] = extractor.project_methods(src_main)
    defined = cache[src_main]
    return lambda n: n in defined


def normalize(name):
    if not name:
        return ""
    return str(name).split("(")[0].strip().split(".")[-1]


def production_candidates(module_dir, method, parser):
    """Find top-level production classes defining a particular method.

    Intentionally conservative: incomplete parsing or multiple matches require review.
    """
    src = module_dir / "src" / "main" / "java"
    if not src.is_dir():
        return []
    candidates = set()
    matcher = re.compile(r"\b" + re.escape(method) + r"\s*\(")
    for p in src.rglob("*.java"):
        try:
            s = p.read_text(encoding="utf-8", errors="replace")
            if not matcher.search(s):
                continue
            cu = parser.parse.parse(s)
        except Exception:
            continue
        package = (cu.package.name + ".") if cu.package else ""
        for klass in cu.types:
            if method in {m.name for m in getattr(klass, "methods", [])}:
                candidates.add(package + klass.name)
    return sorted(candidates)


def run_identification(row, args, modules, cache, previous):
    """Prepare one row, retaining manually reviewed selections."""
    out = dict(row)
    for k in EXTRA:
        out[k] = previous.get(k, "")
    try:
        root = get_archive(row, args)
        testfile, module_dir, testmethod = locate_test(root, row["module"], row["flaky_test"])
        out.update(archive_root=str(root), test_file=str(testfile), module_dir=str(module_dir))
    except (OSError, ValueError, zipfile.BadZipFile) as ex:
        out.update(status="input_error", note=str(ex))
        return out
    # Keep a manually edited junit value; otherwise detect it from the flaky test's source.
    junit = previous.get("junit") or detect_junit(testfile.read_text(encoding="utf-8", errors="replace"))
    out["junit"] = junit

    if not args.run_llm:
        out.update(status=out.get("status") if out.get("selected_method") else "awaiting_llm",
                   note="Run prepare with --run-llm to identify the focal method")
        return out
    if previous.get("selected_method") and not args.force:
        out.update(status="reviewed", note="Preserved existing selected_method")
        return out

    extractor, finder, llm, javalang = modules
    # The focal scripts only recognise annotated tests; JUnit 3 tests are found by name instead.
    extractor.is_test_method = extractor.junit_annotated
    llm.is_test = llm.junit_annotated
    if junit == "3":
        extractor.is_test_method = lambda m: extractor.junit_annotated(m) or is_junit3_test(m)
        llm.is_test = lambda m: llm.junit_annotated(m) or is_junit3_test(m)
    try:
        src = testfile.read_text(encoding="utf-8", errors="replace")
        try:
            tree = javalang.parse.parse(src)
        except Exception:
            tree = None
        if tree is not None:
            out["parse_mode"] = "file"
            key = str(testfile)
            if key not in cache["extract"]:
                cache["extract"][key] = extractor.main(str(testfile))
            entries = [e for e in cache["extract"][key] if e.get("test_name") == testmethod]
            if len(entries) != 1:
                raise ValueError(f"Expected exactly one test method named {testmethod}; found {len(entries)}")
            entry = entries[0]
            ms = [m for _, m in tree.filter(javalang.tree.MethodDeclaration)
                  if m.name == testmethod and llm.is_test(m)]
            start_line = method_line(ms[0]) if len(ms) == 1 else None
        else:
            # Something elsewhere in the file is beyond javalang; parse just the target test.
            out["parse_mode"] = "method_only"
            m, start_line = isolate_test_method(src, testmethod, javalang, llm.extract_body)
            entry = extractor.process_test(m, project_method_filter(extractor, testfile, cache["src_main"]))
        ranked = finder.find_focal_method_ranked(entry["test_tokens"], entry["candidates"])
        if not ranked:
            out.update(status="no_jaccard_candidates", note="No project method calls identified")
            return out
        jaccard_name, score = ranked[0]
        ambiguous = len(ranked) > 1 and abs(score - ranked[1][1]) < 0.01
        out.update(jaccard_method=jaccard_name, jaccard_score=f"{score:.3f}",
                   jaccard_ambiguous=str(bool(ambiguous)).lower())
        if not start_line:
            raise ValueError(f"Could not isolate test method {testmethod}")
        body = llm.extract_body(src.split("\n"), start_line)
        if body is None:
            raise ValueError(f"Could not extract body for {testmethod}")
        prompt = llm.PROMPT.format(name=testmethod, body=body)
        ck = sha256(args.model + "|0|" + prompt)
        if ck not in cache["llm"]:
            reply, err = llm.call_api(prompt, args.model, os.environ["OPENAI_API_KEY"], 0.0)
            cands, err2 = llm.parse_reply(reply) if reply is not None else (None, err)
            cache["llm"][ck] = {"candidates": cands, "error": err2}
            save_json_atomic(args.out / "llm_cache.json", cache["llm"])
        info = cache["llm"][ck]
        cands = info.get("candidates") or {}
        if not cands:
            out.update(status="llm_failed", note=str(info.get("error") or "No candidates"))
            return out
        llm_name, llm_score = max(cands.items(), key=lambda pair: pair[1])
        out.update(llm_method=llm_name, llm_score=f"{llm_score:.3f}")
        if score <= 0 or ambiguous:
            out.update(status="review_jaccard", note="Jaccard score zero or tied; manual review required")
            return out
        if normalize(llm_name) != normalize(jaccard_name):
            out.update(status="disagreed", note="LLM and Jaccard did not agree")
            return out

        # Jaccard and LLM output bare names. Resolve the actual production class.
        module_key = str(module_dir) + "|" + jaccard_name
        if module_key not in cache["production"]:
            cache["production"][module_key] = production_candidates(module_dir, jaccard_name, javalang)
        pcs = cache["production"][module_key]
        out["production_candidates"] = ";".join(pcs)
        if len(pcs) > 1:
            # Prefer the class the test is named after (FooTest/FooTests/FooTestCase/TestFoo -> Foo).
            test_class = row["flaky_test"].partition("#")[0].split(".")[-1]
            base = re.sub(r"(Tests?|TestCase|IT)$", "", test_class)
            base = re.sub(r"^Test(?=[A-Z])", "", base)
            named = [c for c in pcs if c.split(".")[-1] == base]
            if len(named) == 1:
                pcs = named
        if len(pcs) != 1:
            out.update(status="review_class", note=f"Found {len(pcs)} possible production classes; manually select")
            return out
        # Multiple overloads under same name may need method number in patched ChatUniTest.
        cls = pcs[0]
        cls_source = module_dir / "src" / "main" / "java" / Path(*cls.split("."))
        cls_source = cls_source.with_suffix(".java")
        overload_count = 0
        if cls_source.exists():
            cu = javalang.parse.parse(cls_source.read_text(encoding="utf-8", errors="replace"))
            overload_count = sum(m.name == jaccard_name for t in cu.types if t.name == cls.split(".")[-1]
                                 for m in getattr(t, "methods", []))
        if overload_count > 1:
            out.update(status="review_overload", note=f"{overload_count} overloads; select specific method number")
            return out
        out.update(selected_method=cls + "#" + jaccard_name,
                   status="auto_resolved", note="Review selection before generation")
    except Exception as ex:
        out.update(status="identify_error", note=f"{type(ex).__name__}: {ex}")
    return out


def prepare(args):
    rows, input_cols = load_rows(args.csv)
    prev = read_previous(args.out / "focal_manifest.csv")
    args.archives = args.archives.resolve()
    args.out = args.out.resolve()
    if args.run_llm and not os.getenv("OPENAI_API_KEY"):
        raise ValueError("Set OPENAI_API_KEY in the environment before --run-llm")
    modules = None
    if args.run_llm:
        import javalang
        extractor = load_module(args.focal_scripts, "focal_extract.py", "repro_focal_extract")
        finder = load_module(args.focal_scripts, "focal_method_finder_batch.py", "repro_focal_jaccard")
        llm = load_module(args.focal_scripts, "llm_focal.py", "repro_focal_llm")
        # Keep the originals; run_identification swaps in a JUnit 3-aware check per row.
        extractor.junit_annotated = extractor.is_test_method
        llm.junit_annotated = llm.is_test
        modules = (extractor, finder, llm, javalang)

    llm_cache_path = args.out / "llm_cache.json"
    try:
        llm_cache = json.loads(llm_cache_path.read_text())
    except (OSError, json.JSONDecodeError):
        llm_cache = {}
    cache = {"extract": {}, "production": {}, "src_main": {}, "llm": llm_cache}
    manifest = []
    for i, row in enumerate(rows, 1):
        if args.limit and i > args.limit:
            break
        old = prev.get(i, {})
        entry = run_identification(row, args, modules, cache, old)
        entry["row_number"] = i
        manifest.append(entry)
        csv_write(args.out / "focal_manifest.csv", manifest, input_cols + EXTRA)
        print(f"[{i}/{min(len(rows), args.limit or len(rows))}] {row['flaky_test']} -> "
              f"{entry['selected_method'] or '-'} ({entry['status']})", flush=True)
    print(f"\nManifest: {args.out / 'focal_manifest.csv'}")
    print("Inspect/edit selected_method entries; blank selections are skipped by generate.")


def chatunitest_mode(r):
    """(mode, reason): "5" = stock JUnit 5 mode, "4" = patched JUnit 4 mode, None = skip."""
    junit = (r.get("junit") or "").strip()
    if junit == "5":
        return "5", ""
    if junit == "4":
        return "4", ""
    if junit == "3":
        # ChatUniTest has no JUnit 3 mode; JUnit 4 runs JUnit 3-style suites, so use it
        # unless the project is pinned to junit 3.x.
        if junit3_only(Path(r["module_dir"]), Path(r.get("archive_root") or "/")):
            return None, "project pins junit 3.x; JUnit 4 tests would not compile"
        return "4", ""
    return None, "unknown JUnit version; set the junit column to 3, 4 or 5"


def build_module(r, env, args, row_dir):
    """mvn install -DskipTests once per module and JDK; ChatUniTest needs target/*.jar."""
    module_dir = Path(r["module_dir"])
    module = (r.get("module") or "").strip()
    root, project_list = module_dir, []
    if module not in ("", "."):
        parts = Path(module).parts
        if module_dir.parts[-len(parts):] == parts:
            parent = Path(*module_dir.parts[:-len(parts)])
            if (parent / "pom.xml").is_file():
                # Build sibling modules this one depends on, too.
                root, project_list = parent, ["-pl", module, "-am"]
    stamp = module_dir / ".batch_built"
    jdk = env.get("JAVA_HOME", "")
    if stamp.is_file() and stamp.read_text().strip() == jdk:
        return "cached"
    cmd = ["mvn", "-B", "install", *project_list, *BUILD_SKIPS, "-Dmaven.repo.local=" + str(args.repo)]
    log = row_dir / "build.log"
    print("  build: (cd " + str(root) + " && " + " ".join(cmd) + ")")
    with log.open("w", encoding="utf-8") as fout:
        try:
            p = subprocess.run(cmd, cwd=root, env=env, stdout=fout, stderr=subprocess.STDOUT,
                               timeout=args.timeout)
        except subprocess.TimeoutExpired:
            fout.write("Build timed out after " + str(args.timeout) + " seconds.\n")
            return "build_timeout"
    if p.returncode != 0:
        return "build_failed"
    stamp.write_text(jdk)
    return "built"


def generate(args):
    path = args.manifest.resolve()
    with path.open(newline="", encoding="utf-8-sig") as f:
        selected = list(csv.DictReader(f))
    args.repo = args.maven_repo.expanduser().resolve()
    prompts = args.junit4_dir.resolve() / "prompts-junit4"
    if not prompts.is_dir():
        raise FileNotFoundError(f"JUnit4 prompt directory not found: {prompts}")
    if args.execute and not os.getenv("OPENAI_API_KEY"):
        raise ValueError("Set OPENAI_API_KEY before --execute")
    args.out = args.out.resolve()
    rows = []
    earlier = read_previous_runs(args.out / "generation_results.csv")
    candidates = [r for r in selected if (r.get("selected_method") or "").strip()]
    if args.limit:
        candidates = candidates[:args.limit]
    for r in candidates:
        rowid = r["row_number"]
        if (args.resume and earlier.get(rowid, {}).get("status") == "generated"
                and earlier[rowid].get("selected_method") == r["selected_method"]):
            print(f"[{rowid}] skipped (tests already generated)")
            rows.append(earlier[rowid]); continue
        row_dir = args.out / "runs" / ("row_" + str(rowid).zfill(3))
        tmp = row_dir / "tmp"
        tests = row_dir / "tests"
        row_dir.mkdir(parents=True, exist_ok=True)
        log = row_dir / "maven.log"
        target = Path(r.get("module_dir", ""))
        selected_method = r["selected_method"].strip()
        mode, reason = chatunitest_mode(r)
        record = {"row_number": rowid, "zip": r["zip"], "flaky_test": r["flaky_test"],
                  "selected_method": selected_method, "junit": r.get("junit", ""),
                  "chatunitest_mode": mode or "", "build_status": "", "status": "preview",
                  "exit_code": "", "tests_generated": "", "api_errors": "",
                  "log_file": str(log), "tmp_output": str(tmp), "test_output": str(tests)}
        if not r.get("module_dir", "").strip() or not (target / "pom.xml").is_file():
            record.update(status="missing_pom")
            print(f"[{rowid}] missing POM: {target}")
        elif mode is None:
            record.update(status="skipped_junit")
            print(f"[{rowid}] skipped: {reason}")
        else:
            cmd = ["mvn", PLUGIN, "-DselectMethod=" + selected_method]
            if mode == "4":
                cmd += ["-Dchatunitest.junit=4", "-DpromptPath=" + str(prompts)]
            cmd += ["-DtmpOutput=" + str(tmp), "-DtestOutput=" + str(tests),
                    "-Dmodel=" + args.model,
                    "-Durl=https://api.openai.com/v1/chat/completions",
                    "-DapiKeys=" + (os.getenv("OPENAI_API_KEY", "REDACTED") if args.execute else "REDACTED"),
                    "-Dmaven.repo.local=" + str(args.repo)]
            jdk = find_jdk(str(r.get("java", "")).strip())
            print(f"[{rowid}] cwd={target} selected={selected_method} junit={r.get('junit') or '?'} "
                  f"mode=JUnit{mode} JDK={r.get('java','?')} ({jdk or 'not found, using current java'})")
            print("  " + " ".join(x if not x.startswith("-DapiKeys=") else "-DapiKeys=[hidden]" for x in cmd))
            if args.execute:
                tmp.mkdir(parents=True, exist_ok=True)
                tests.mkdir(parents=True, exist_ok=True)
                env = os.environ.copy()
                if jdk:
                    env["JAVA_HOME"] = jdk
                    env["PATH"] = str(Path(jdk) / "bin") + os.pathsep + env.get("PATH", "")
                build = build_module(r, env, args, row_dir)
                record["build_status"] = build
                if build not in ("built", "cached"):
                    record.update(status=build)
                    print(f"  => {build}; log: {row_dir / 'build.log'}")
                else:
                    with log.open("w", encoding="utf-8") as fout:
                        try:
                            p = subprocess.run(cmd, cwd=target, env=env, stdout=subprocess.PIPE,
                                               stderr=subprocess.STDOUT, timeout=args.timeout, text=True,
                                               errors="replace")
                            output = p.stdout.replace(os.environ["OPENAI_API_KEY"], "[redacted]")
                            fout.write(output)
                            # Maven reports BUILD SUCCESS even when every API call failed,
                            # so judge the run by the test files it actually wrote.
                            n_tests = sum(1 for _ in tests.rglob("*.java"))
                            n_api = output.count("In AskGPT.askChatGPT")
                            if p.returncode != 0:
                                status = "maven_failed"
                            elif n_tests:
                                status = "generated"
                            elif n_api:
                                status = "api_error"
                            else:
                                status = "no_tests"
                            record.update(status=status, exit_code=p.returncode,
                                          tests_generated=n_tests, api_errors=n_api)
                        except subprocess.TimeoutExpired:
                            fout.write("Maven timed out after " + str(args.timeout) + " seconds.\n")
                            record.update(status="timeout", exit_code="")
                    print(f"  => {record['status']} (tests={record['tests_generated']}, "
                          f"api_errors={record['api_errors']}); log: {log}")
        rows.append(record)
        # Preserve results for other rows when piloting / resuming.
        all_records = dict(earlier)
        all_records.update({x["row_number"]: x for x in rows})
        csv_write(args.out / "generation_results.csv",
                  [all_records[k] for k in sorted(all_records, key=lambda x: int(x))], GEN_FIELDS)
    if not candidates:
        print("No selected_method entries found; prepare and review focal_manifest.csv first.")
    print("NOTE: \"generated\" means ChatUniTest wrote test files, not that they pass. Verify with Surefire: Tests run > 0.")


def read_previous_runs(path):
    if not path.exists():
        return {}
    with path.open(newline="", encoding="utf-8") as f:
        return {r["row_number"]: r for r in csv.DictReader(f)}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="action", required=True)
    a = sub.add_parser("prepare", help="Create focal-method manifest from ReproFlake CSV")
    a.add_argument("--csv", type=Path, required=True)
    a.add_argument("--archives", type=Path, required=True,
                   help="Folder with extracted <zip>/ directories or <zip>.zip files")
    a.add_argument("--focal-scripts", type=Path,
                   help="Path to archive/03_focal_methods directory (required with --run-llm)")
    a.add_argument("--out", type=Path, default=Path("batch_output"))
    a.add_argument("--run-llm", action="store_true", help="Make OpenAI API calls for focal identification")
    a.add_argument("--download", action="store_true", help="Download missing ZIP files from CSV's Zenodo URLs")
    a.add_argument("--delete-zips", action="store_true",
                   help="Delete each ZIP once it is extracted (saves ~13 GB for the full CSV)")
    a.add_argument("--model", default="gpt-4o")
    a.add_argument("--limit", type=int, default=0, help="First N rows (pilot run)")
    a.add_argument("--force", action="store_true", help="Overwrite previously reviewed focal selections")

    b = sub.add_parser("generate", help="Run ChatUniTest JUnit 4 for reviewed focal methods")
    b.add_argument("--manifest", type=Path, required=True)
    b.add_argument("--junit4-dir", type=Path, required=True,
                   help="Folder containing the patched prompts-junit4 directory")
    b.add_argument("--out", type=Path, default=Path("batch_output"))
    b.add_argument("--maven-repo", type=Path, default=Path.home() / ".m2" / "repository")
    b.add_argument("--model", default="gpt-4o")
    b.add_argument("--limit", type=int, default=0, help="First N selected methods (pilot run)")
    b.add_argument("--timeout", type=int, default=1800)
    b.add_argument("--resume", action="store_true", help="Skip rows that already generated tests")
    b.add_argument("--execute", action="store_true", help="Actually run Maven/API (otherwise preview only)")
    args = parser.parse_args()
    try:
        if args.action == "prepare":
            if args.run_llm and not args.focal_scripts:
                parser.error("--focal-scripts required with --run-llm")
            prepare(args)
        else:
            generate(args)
    except (OSError, ValueError, ImportError) as ex:
        parser.exit(2, f"ERROR: {ex}\n")


if __name__ == "__main__":
    main()
