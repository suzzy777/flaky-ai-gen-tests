#!/usr/bin/env python3
"""Get the 15 ReproFlake archives the generated tests run in, and prepare them like the original run.

For every archive in archives.csv:
  1. download zips/<zip>.zip from Zenodo (kept; a broken or incomplete download is fetched again),
  2. extract it to extracted/<zip>/ (the layout flaky_check_basic.py expects),
  3. copy its bundled Maven repository (Flakym2/.m2/repository) into --maven-repo without
     overwriting anything already there (ReproFlake runs with that repository as its .m2),
and for every module in modules.csv:
  4. add test-scoped Mockito 4.11.0 (plus mockito-junit-jupiter for JUnit 5) to the module pom, as
     the generation step did (the generated tests import Mockito); the original pom is kept as
     pom.xml.batch_orig.
Safe to rerun: finished steps are skipped.
"""
import argparse
import csv
import os
from pathlib import Path
import shutil
import sys
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import batch_reproflake_chatunitest as B  # noqa: E402


def download(url, dest, tries=3):
    """dest, downloaded completely: the size must match Content-Length and the zip must test OK."""
    if dest.is_file():
        try:
            with zipfile.ZipFile(dest) as z:
                if z.testzip() is None:
                    return
        except zipfile.BadZipFile:
            pass
        print(f"  {dest.name} is broken, downloading again")
        dest.unlink()
    if not url.startswith("https://zenodo.org/records/") or not url.endswith(".zip"):
        sys.exit(f"Refusing unexpected archive URL: {url}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(".zip.part")
    for attempt in range(1, tries + 1):
        print(f"  downloading {dest.name} (try {attempt}) ...", flush=True)
        try:
            with urllib.request.urlopen(url, timeout=300) as src, part.open("wb") as out:
                expected = int(src.headers.get("Content-Length") or 0)
                shutil.copyfileobj(src, out, 1 << 20)
            if expected and part.stat().st_size != expected:
                raise IOError(f"incomplete: {part.stat().st_size} of {expected} bytes")
            with zipfile.ZipFile(part) as z:
                if z.testzip() is not None:
                    raise IOError("zip test failed")
            part.replace(dest)
            return
        except (OSError, zipfile.BadZipFile) as ex:
            print(f"  failed: {ex}")
            part.unlink(missing_ok=True)
    sys.exit(f"Could not download {url}")


def seed_m2(root, repo):
    """Copy root's Flakym2/.m2/repository into repo, never overwriting. Returns files copied."""
    m2 = next((p for p in [root / "Flakym2" / ".m2" / "repository", *root.glob("*/Flakym2/.m2/repository")]
               if p.is_dir()), None)
    if m2 is None:
        return 0
    copied = 0
    for f in m2.rglob("*"):
        dest = repo / f.relative_to(m2)
        if f.is_file() and not dest.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dest)
            copied += 1
    return copied


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--maven-repo", type=Path, default=Path.home() / ".m2" / "repository")
    a.add_argument("--no-seed-m2", action="store_true", help="Skip step 3 (copying Flakym2 into --maven-repo)")
    args = a.parse_args()
    repo = args.maven_repo.resolve()

    for r in csv.DictReader(open(HERE / "archives.csv", encoding="utf-8")):
        z = r["zip"]
        print(f"[{z}]", flush=True)
        root = HERE / "extracted" / z
        if not (root / ".batch_extracted").is_file():
            zpath = HERE / "zips" / (z + ".zip")
            download(r["url"], zpath)
            print("  extracting ...", flush=True)
            shutil.rmtree(root, ignore_errors=True)
            B.safe_extract(zpath, root)
            (root / ".batch_extracted").touch()
        if not args.no_seed_m2 and not (root / ".batch_m2_seeded").is_file():
            print(f"  {seed_m2(root, repo)} files copied from Flakym2 into {repo}", flush=True)
            (root / ".batch_m2_seeded").touch()

    for r in csv.DictReader(open(HERE / "modules.csv", encoding="utf-8")):
        root = HERE / "extracted" / r["zip"]
        _, module_dir, _ = B.locate_test(root, r["module"], r["a_test_in_module"])
        added = B.ensure_mockito(module_dir, r["junit"])
        print(f"[{r['zip']} {r['module']}] Mockito " + (", ".join(added) + " added" if added else "already there"))
    print("\nDone. Next: the pilot in README.md.")


if __name__ == "__main__":
    main()
