# Flakiness check of LLM-generated tests

ChatUniTest generated unit tests for the focal methods of ReproFlake flaky tests. This folder checks
whether those **generated tests** are flaky themselves: **48 test methods in 23 test files** from 13
modules (15 ReproFlake archives), all of which passed in a plain `mvn test`.

| Check | Finds | How |
|---|---|---|
| `nio` | NIO (fails when run twice in one JVM) | ReproFlake's own method: its testrunner 1.4-SNAPSHOT + iDFlakies 1.2.0-SNAPSHOT, the test run twice in a row in one JVM, 100 iterations. JUnit 5 tests: testrunner cannot repeat them, so a small own runner does the same (`nio_method = own_junit5_runner`) |
| `nondex` | ID (depends on HashMap order etc.) | NonDex 2.1.7, 100 seeds |
| `idflakies` | OD (depends on test order) | iDFlakies 2.0.0 on the whole module test suite with the generated test added, 20 shuffled rounds |
| `rerun` | NOD (randomly fails) | `mvn test -Dtest=Class#method`, 100 times per method, each in a fresh JVM |

## What is in here

| File | What |
|---|---|
| `task_csvs/flaky_generated_tests.csv` | **the input**: one row per generated test method (project, sha, module, generated_test, test_file, focal_method, zip, java, junit, mockito_fix, focal_from_test, focal_from_test_type) |
| `out_part1/`, `out_part2/` | the 23 generated test files (`test_file` in the CSV points here) |
| `archives.csv`, `modules.csv` | the 15 archives (Zenodo URLs) and their modules |
| `setup_archives.py` | downloads and prepares the archives (step 1 below) |
| `flaky_check_basic.py` | the checks; `batch_reproflake_chatunitest.py`, `collect_nonflaky.py`, `replay_generated.py` are its helpers |
| `run_flaky_all.sh` | runs all checks one after another |

## Requirements

- Linux, Python 3.8+ (standard library only), Maven 3.6+, internet (Zenodo and Maven Central)
- **JDK 8 and JDK 11, both full JDKs with `javac`**. They are found in `/usr/lib/jvm`
  (e.g. `java-8-openjdk-amd64`, `java-11-openjdk-amd64`); elsewhere, set `JAVA_HOME_8` / `JAVA_HOME_11`.
- Disk: about 2.2 GB for the zips, plus the extracted archives and their Maven repositories
  (several GB more in `extracted/` and `~/.m2`).

## 1. Set up the archives (once)

```
python3 setup_archives.py
```

Downloads the 15 archives (2.2 GB) into `zips/`, checks each download is complete (a broken one is
downloaded again), extracts them into `extracted/`, copies each archive's bundled Maven repository
(`Flakym2/.m2/repository`) into `~/.m2/repository` without overwriting anything, and adds Mockito
4.11.0 to the module poms (the generated tests import it; the original pom is kept as
`pom.xml.batch_orig`). Safe to run again.

## 2. Pilot (one small file, a few minutes)

Run inside the folder. Checks the setup on one file (marineapi, Java 8, JUnit 4):

```
python3 flaky_check_basic.py nio --tests task_csvs/flaky_generated_tests.csv --archive-dir extracted --nio-runs 2 --only out_part2_row_045 --out flaky_check_out/pilot/nio
python3 flaky_check_basic.py nondex --tests task_csvs/flaky_generated_tests.csv --archive-dir extracted --nondex-runs 2 --only out_part2_row_045 --out flaky_check_out/pilot/nondex
python3 flaky_check_basic.py idflakies --tests task_csvs/flaky_generated_tests.csv --archive-dir extracted --rounds 1 --only out_part2_row_045 --out flaky_check_out/pilot/idflakies
python3 flaky_check_basic.py rerun --tests task_csvs/flaky_generated_tests.csv --archive-dir extracted --runs 3 --offline --only out_part2_row_045 --out flaky_check_out/pilot/rerun
python3 flaky_check_basic.py summary --tests task_csvs/flaky_generated_tests.csv --archive-dir extracted --out flaky_check_out/pilot
```

Every step should end with `=> no_flaky_found` or similar, not with an error status such as
`build_failed`, `compile_failed`, `nondex_did_not_run`, `idflakies_did_not_run`, `nio_setup_failed`.
(`idflakies` may say `polluter_found` here: this generated test is a known polluter, see below.)
Delete `flaky_check_out/pilot` afterwards.

## 3. Full run

Inside tmux (`tmux new -s flaky`; leave with Ctrl+B then D, come back with `tmux attach -t flaky`):

```
bash run_flaky_all.sh
```

Runs NIO, NonDex, iDFlakies, the reruns and the summary, one after another. Roughly: NIO a few hours,
NonDex under 1 hour, iDFlakies a few hours (whole module suites), reruns about 3-8 hours.
**Run only one check at a time** (they use the same project folders). Every step is resumable: if
it stops, run the same line again; finished work is skipped. Logs: `flaky_<step>.log`.

## Results (in `flaky_check_out/`)

| File | What |
|---|---|
| `summary.csv` | **main table**, one row per generated test method: `rerun_runs/passed/failed/errors`, `rerun_flaky`, `nondex_flaky`, `idflakies_type` (`-` = not flagged), `idflakies_polluter_of`, `nio`, `nio_method`, `any_flaky` |
| `<step>/rows.csv` | one row per generated test file: `status`, `flaky_generated` (generated tests flagged), `flaky_other` (project's own tests flagged), `note` |
| `rerun/runs.csv` | every rerun of every method |
| `nio/rows/<id>/nio.csv` | per method: iterations, pass, failure (NIO), error, not_twice, nio_method |
| `idflakies/rows/<id>/idflakies_flaky.csv` | every test iDFlakies flagged in that module, whether it is generated, suspected generated polluters |
| `idflakies/orders/` | `<Class#method>.passing.txt` / `.failing.txt`: the order a flagged test passed / failed in |

Status values in `rows.csv`: `flaky_found` = a generated test is flaky; `polluter_found` = a project
test failed only in an order where a generated test ran before it (**a suspicion only**);
`no_flaky_found`; anything else is a setup problem, not a result.

## Things to know

- **`polluter_found` / `idflakies_polluter_of` are suspicions.** Confirm one in fresh JVMs with only
  the two classes: victim alone (should pass), victim then generated test (passes), generated test
  then victim (fails = confirmed). Confirmed example: in marineapi, `AISMessageFactory_create_0_3_Test`
  empties the `AISMessageFactory` parser map with reflection, after which
  `AISMessageFactoryTest#testCreate` and `#testCreateWithTwo` fail.
- `any_flaky` is also `true` when a test is only a *suspected* polluter; check which column caused it.
- iDFlakies cannot run modules with both JUnit 4 and JUnit 5 tests: servicecomb `foundation-vertx`
  (`out_part2_row_016`) will not get an iDFlakies result.
- NIO for the 14 JUnit 5 methods uses our own runner (no surefire config such as `argLine`); report
  them separately from the testrunner (ReproFlake) results.
- `--only <text>` limits any step to runs whose id, zip or generated test contains the text, e.g.
  `--only ormlite`.
