# Focal methods with two LLMs

**What:** finds the focal method of each of the 144 flaky tests of the main study again, with gpt-4o and Claude (Opus 5.5) instead of Jaccard and gpt-4o. In the main study, only 53 of the 144 got a focal method. This shows how many more we get, and of which type (OD, ID, TD, NIO).

A test is kept (`auto_resolved`) when:
- gpt-4o and Claude name the same method,
- the method is declared in the project's own sources (not a library method with the same name),
- and it maps to one production class.

Both LLMs get the same prompt as in the main study (`focal_scripts/llm_focal.py`). gpt-4o's old answers are reused from `inputs/llm_cache_gpt4o.json`, so gpt-4o is only asked about prompts it hasn't seen. Jaccard is still computed and written to the output, but no longer used to decide.

`focal_v2.py` also fixes the cases where the old script failed for technical reasons:
- test methods inherited from a superclass in the project (dubbo `testGetInvoker`, ratis, curator);
- JUnit 3 style test methods in files that also have `@Test` methods (oozie);
- test files outside `src/test/java` (OpenRefine);
- production classes javalang can't parse;
- several classes with the method: it now also uses the type of the variable the test calls it on (blade `RouteMatcher`, hadoop `TimelineV2ClientImpl`);
- constructors (`<init>`) and methods of nested classes are reported instead of being mapped to a wrong method.

Tested here without API keys: with Claude simulated as agreeing with gpt-4o, all 53 old focal methods come out the same, and the new rules gave the expected result on the 21 old failures we had archives for.

**Needs:**
- Linux, Python 3.10 or newer (`python3 -m venv` must work);
- internet access to zenodo.org, pypi.org, api.anthropic.com and api.openai.com;
- about 30 GB of disk for the 80 archives (downloaded into `archives/`);
- `ANTHROPIC_API_KEY` and `OPENAI_API_KEY`.

**Order:** first the 144 main-study tests, then the new ReproFlake tests (below).

**First, test two rows:**
```
export ANTHROPIC_API_KEY=...
export OPENAI_API_KEY=...
cd focal_package
bash run.sh --rows 1 3
```
Check `out/focal_manifest_v2.csv`: both rows should be `auto_resolved`, with something in `gpt_method` and `claude_method`. If a row says `llm_missing`, the `note` column says why (usually a key problem).

**Then run all rows:** `bash run.sh`. Most of the time goes into downloading the archives. The Claude calls cost a few dollars in total, and gpt-4o a few cents. The new ReproFlake tests add roughly $5 for Claude and $1-2 for gpt-4o, since none of them were asked before.

**Then the new ReproFlake tests:** `bash run.sh --set expansion --delete-archives`. This runs the same step on 323 ReproFlake tests that are not in the main study (`inputs/expansion_v1.csv`):
- ID: 2 random tests from each of the 90 projects that are not in the main study (145 tests; some projects have only 1);
- OD: all 89 that are left (ormlite and wildfly);
- NIO: all 89 that are left (quickcheck).

There are no TD tests left. They come from 114 archives; `--delete-archives` deletes each one when its tests are done, so it needs only a few GB at a time. Its results go to `out/expansion_manifest.csv`, `out/expansion_summary.txt` and `out/expansion_review_sample.csv` (check these 20 the same way). The list was made with `make_expansion_input.py` (seed 2026); don't rebuild it.

**Results** in `out/`:
- `summary.txt`: counts by status and type, for the old and the new run; whether the 53 old focal methods are still the same; and how many tests were recovered, by type.
- `focal_manifest_v2.csv`: one row per test. It has the same columns as the old `focal_manifest.csv`, so the generation scripts can read it, plus `old_status`, `old_selected_method`, `gpt_method` and `claude_method`.
- `review_sample.csv`: 20 random recovered tests (seed 2026) to check by hand. Open each test file, decide whether `selected_method` really is the method under test, and fill in `correct (yes/no)` and `comment`.
- `llm_cache_gpt4o.json` and `llm_cache_claude.json`: all LLM answers.

**What the statuses mean:**
- `auto_resolved`: kept.
- `disagreed`: the two LLMs named different methods.
- `not_project_method`: the method isn't declared in the project, e.g. Gson's `toJson` or a test helper.
- `constructor`: the LLMs named a constructor. ChatUniTest generates for methods only.
- `review_class`: no single production class, e.g. the method is only in a nested class.
- `no_llm_candidate`: an LLM found no candidate.
- `input_error` / `identify_error`: the test couldn't be found or read. The `note` says why; for example, the okta test is Groovy and wildfly's `testSubsystem` comes from a library class.
- `llm_missing`: an API call failed. Fix the cause and run again; answers already received are kept.

**Also read** before we write this up, so the paper can say how others find focal methods:
- Ghafari, Ghezzi and Rubinov, "Automatically identifying focal methods under test in unit test cases", SCAM 2015;
- Tufano et al., "Methods2Test", MSR 2022 (focal methods by name matching);
- White, Krinke and Tan, TCTracer (test-to-code traceability);
- Qusef et al., SCOTCH (test-to-code traceability).
Check the exact titles and venues; these are from memory.

**Bring back:** the whole `out/` folder (not `archives/` or `venv/`).
