#!/usr/bin/env python3
"""Focal methods of the 144 flaky tests of the main study, with two LLMs (gpt-4o and Claude) instead of
Jaccard + gpt-4o. A row is kept when both LLMs name the same method, the method is defined in the
project (not a library method with the same name), and it maps to one production class.

Same steps as batch_reproflake_chatunitest.py prepare (imported, not changed), with these fixes:
- test methods inherited from a superclass in the project are found in that superclass
  (before: "Expected exactly one test method named X; found 0");
- test files outside src/test/java are found anywhere in the archive (before: input_error);
- production classes whose source javalang can't parse are found by a plain-text match;
- several production classes: after the old rules (class named after the test, same package),
  the class of the variable the test calls the method on.
Both LLMs get the same prompt as before (focal_scripts/llm_focal.py), so gpt-4o's earlier answers
are reused from inputs/llm_cache_gpt4o.json; only new prompts call OpenAI. Jaccard is still computed
and reported, but not used to decide.

Inputs: inputs/focal_manifest_v1.csv (the 144 rows and the old result), inputs/llm_cache_gpt4o.json. Archives are downloaded from Zenodo into archives/.
Output (out/): focal_manifest_v2.csv (same columns as focal_manifest.csv, plus old_status,
old_selected_method, gpt_method, claude_method), summary.txt, review_sample.csv, the two LLM caches.
--set expansion: the new ReproFlake tests instead (inputs/expansion_v1.csv, from make_expansion_input.py;
no old result). Output out/expansion_manifest.csv, expansion_summary.txt, expansion_review_sample.csv;
the same LLM caches.
--delete-archives: delete each downloaded archive once its rows are done (rows are sorted by archive).
Usage: python3 focal_v2.py [--set main|expansion] [--rows 1 5 9] [--dry-run] [--delete-archives]
  ANTHROPIC_API_KEY is needed for Claude; OPENAI_API_KEY only for prompts not in the gpt-4o cache.
  --dry-run makes no API calls (gpt-4o from the cache only, no Claude).
"""
import argparse
import collections
import csv
import json
import os
from pathlib import Path
import random
import re
import shutil
import sys

P = Path(__file__).resolve().parent
sys.path.insert(0, str(P))
import batch_reproflake_chatunitest as B  # noqa: E402

GPT_MODEL = "gpt-4o"                 # the name the old cache keys use
GPT_SNAPSHOT = "gpt-4o-2024-08-06"   # the snapshot "gpt-4o" pointed to in the main study
CLAUDE_MODEL = "claude-opus-5-5"
NEW_COLS = ["old_status", "old_selected_method", "gpt_method", "claude_method"]


def read_java(f):
    return f.read_text(encoding="utf-8", errors="replace")


def parse(src, javalang):
    try:
        return javalang.parse.parse(src)
    except Exception:
        return None


def module_root(f, root):
    """Nearest folder above f with a pom.xml, not above the archive root."""
    d = f.parent
    while d != root and d != d.parent:
        if (d / "pom.xml").is_file():
            return d
        d = d.parent
    raise ValueError(f"no pom.xml above {f}")


def locate_test(root, module, test_id):
    """B.locate_test, then the same class path anywhere in the archive (non-standard test folders)."""
    try:
        return B.locate_test(root, module, test_id)
    except FileNotFoundError:
        fq, _, method = test_id.partition("#")
        tail = Path(*fq.split(".")).with_suffix(".java").parts
        hits = [f.resolve() for f in root.rglob(tail[-1])
                if f.parts[-len(tail):] == tail and "target" not in f.parts]
        if module not in ("", ".") and len(hits) > 1:
            hits = [f for f in hits if module in str(f)] or hits
        if len(hits) == 1:
            return hits[0], module_root(hits[0], root).resolve(), method
        groovy = [f for f in root.rglob(Path(tail[-1]).stem + ".groovy") if "target" not in f.parts]
        if groovy:
            raise ValueError(f"test is written in Groovy ({groovy[0].name}); javalang can't parse it")
        raise


def prod_dirs(module_dir):
    """Production source folders of a module: src/main/java and the pom's <sourceDirectory>."""
    dirs = [module_dir / "src" / "main" / "java"]
    pom = module_dir / "pom.xml"
    if pom.is_file():
        m = re.search(r"<sourceDirectory>\s*([^<]+?)\s*</sourceDirectory>", read_java(pom))
        if m:
            d = re.sub(r"^\$\{(project\.)?basedir\}/", "", m.group(1))
            if "$" not in d:
                dirs.append(module_dir / d)
    return [d for d in dirs if d.is_dir()]


def project_methods(module_dirs, javalang, cache):
    """Method names declared in the modules' production sources (as focal_extract.project_methods)."""
    out = set()
    for md in module_dirs:
        for d in prod_dirs(md):
            if d not in cache:
                names = set()
                for f in d.rglob("*.java"):
                    src = read_java(f)
                    tree = parse(src, javalang)
                    if tree is not None:
                        names.update(m.name for _, m in tree.filter(javalang.tree.MethodDeclaration))
                    else:
                        names.update(re.findall(r"[\w>\]]\s+(\w+)\s*\([^;{)]*\)\s*(?:throws[^{;]*)?[{;]", src))
                cache[d] = names
            out |= cache[d]
    return out


def production_candidates(module_dirs, method, javalang):
    """(top-level classes declaring `method`, nested classes declaring it as Outer.Inner); plain-text
    match for files javalang can't parse."""
    found, nested = set(), set()
    decl = re.compile(r"[\w>\]]\s+" + re.escape(method) + r"\s*\([^;{)]*\)\s*(?:throws[^{;]*)?[{;]")
    for md in module_dirs:
        for d in prod_dirs(md):
            for f in d.rglob("*.java"):
                src = read_java(f)
                if not re.search(r"\b" + re.escape(method) + r"\s*\(", src):
                    continue
                tree = parse(src, javalang)
                if tree is not None:
                    pkg = (tree.package.name + ".") if tree.package else ""
                    for k in tree.types:
                        if method in {m.name for m in getattr(k, "methods", [])}:
                            found.add(pkg + k.name)
                    for path, k in tree.filter(javalang.tree.ClassDeclaration):
                        outer = [n.name for n in path if isinstance(n, javalang.tree.ClassDeclaration)]
                        if outer and method in {m.name for m in k.methods}:
                            nested.add(pkg + ".".join(outer + [k.name]))
                elif decl.search(src):
                    m = re.search(r"^\s*package\s+([\w.]+)\s*;", src, re.M)
                    found.add((m.group(1) + "." if m else "") + f.stem)
    return sorted(found), sorted(nested)


def is_test(m, llm):
    # The name comes from the test runner, so a JUnit 3 style method counts even in a file that also
    # has @Test methods (e.g. oozie: extends TestCase, some methods annotated).
    return llm.junit_annotated(m) or B.is_junit3_test(m)


def superclass_file(tree, testfile, root, javalang):
    """Source of the test class's superclass when it is in the archive, else None."""
    name = testfile.stem
    cls = next((t for t in tree.types if t.name == name), None)
    if cls is None or not getattr(cls, "extends", None):
        return None
    ext = cls.extends.name
    if "." in ext:
        fq = ext
    else:
        imp = [i.path for i in tree.imports if not i.static and not i.wildcard and i.path.endswith("." + ext)]
        fq = imp[0] if imp else ((tree.package.name + ".") if tree.package else "") + ext
    tail = Path(*fq.split(".")).with_suffix(".java").parts
    hits = [f.resolve() for f in root.rglob(tail[-1]) if f.parts[-len(tail):] == tail and "target" not in f.parts]
    return hits[0] if len(hits) == 1 else None


def find_test_method(testfile, method, row, root, javalang, llm, depth=0):
    """(file, src, tree or None, MethodDeclaration, start line) of the test method, following superclasses."""
    src = read_java(testfile)
    tree = parse(src, javalang)
    if tree is None:
        m, line = B.isolate_test_method(src, method, javalang, llm.extract_body)
        return testfile, src, None, m, line
    found = [(p, m) for p, m in tree.filter(javalang.tree.MethodDeclaration)
             if m.name == method and is_test(m, llm)]
    nested = (row.get("test") or "").partition("#")[0].rpartition(".")[2].split("$")
    if len(found) > 1 and len(nested) > 1:
        found = [(p, m) for p, m in found
                 if [n.name for n in p if isinstance(n, javalang.tree.ClassDeclaration)] == nested]
    if len(found) == 1:
        return testfile, src, tree, found[0][1], B.method_line(found[0][1])
    if not found and depth < 5:
        sup = superclass_file(tree, testfile, root, javalang)
        if sup is not None:
            return find_test_method(sup, method, row, root, javalang, llm, depth + 1)
        raise ValueError(f"test method {method} is not in {testfile.name} or a superclass in the project "
                         "(probably inherited from a library class)")
    raise ValueError(f"Expected exactly one test method named {method}; found {len(found)}")


def var_types(node, tree, javalang):
    """{variable name: declared type} for the test method's locals and the test class's fields."""
    decls = [d for _, d in tree.filter(javalang.tree.FieldDeclaration)] if tree is not None else []
    decls += [d for _, d in node.filter(javalang.tree.LocalVariableDeclaration)]
    return {v.name: d.type.name.split(".")[-1] for d in decls for v in d.declarators}


def receiver_classes(node, tree, method, module_dirs, javalang):
    """Simple names of the types the test calls `method` on: x.method() with x a local or field,
    Cls.method(), or Cls.FIELD.method() with FIELD's declared type."""
    types = var_types(node, tree, javalang)
    # A helper class declared in the test file stands for the project class it extends.
    local = {k.name: k.extends.name.split(".")[-1] for _, k in (tree.filter(javalang.tree.ClassDeclaration)
             if tree is not None else []) if getattr(k, "extends", None)}
    for v, t in list(types.items()):
        for _ in range(5):
            if t not in local:
                break
            t = local[t]
        types[v] = t
    out = set()
    for _, c in node.filter(javalang.tree.MethodInvocation):
        if c.member != method or not c.qualifier:
            continue
        q = re.sub(r"^this\.", "", c.qualifier).split(".")
        if q[0] in types:
            out.add(types[q[0]])
        elif q[0][:1].isupper() and len(q) == 1:
            out.add(q[0])
        elif q[0][:1].isupper() and len(q) == 2:
            for md in module_dirs:
                for d in prod_dirs(md):
                    for f in d.rglob(q[0] + ".java"):
                        m = re.search(r"([\w.<>]+)\s+" + re.escape(q[1]) + r"\s*=", read_java(f))
                        if m:
                            out.add(m.group(1).split("<")[0].split(".")[-1])
    return out


def top(cands):
    return max(cands.items(), key=lambda kv: kv[1])[0] if cands else ""


class Judges:
    def __init__(self, out, dry_run):
        self.dry_run = dry_run
        self.gpt_path, self.claude_path = out / "llm_cache_gpt4o.json", out / "llm_cache_claude.json"
        if not self.gpt_path.is_file():
            self.gpt_path.write_text((P / "inputs" / "llm_cache_gpt4o.json").read_text())
        self.gpt = json.loads(self.gpt_path.read_text())
        self.claude = json.loads(self.claude_path.read_text()) if self.claude_path.is_file() else {}
        self.client = None

    def ask_gpt(self, prompt, llm):
        k = B.sha256(GPT_MODEL + "|0|" + prompt)
        if k not in self.gpt:
            if self.dry_run or not os.environ.get("OPENAI_API_KEY"):
                return None, "not in the gpt-4o cache" + ("" if self.dry_run else " and OPENAI_API_KEY not set")
            reply, err = llm.call_api(prompt, GPT_SNAPSHOT, os.environ["OPENAI_API_KEY"], 0.0)
            if reply is None:
                return None, err
            cands, err = llm.parse_reply(reply)
            self.gpt[k] = {"candidates": cands, "error": err, "model": GPT_SNAPSHOT}
            B.save_json_atomic(self.gpt_path, self.gpt)
        return self.gpt[k].get("candidates") or {}, self.gpt[k].get("error")

    def ask_claude(self, prompt, llm):
        k = B.sha256(CLAUDE_MODEL + "|" + prompt)
        if k not in self.claude:
            if self.dry_run:
                return None, "dry run"
            import anthropic
            if self.client is None:
                self.client = anthropic.Anthropic(max_retries=5)
            try:
                r = self.client.messages.create(model=CLAUDE_MODEL, max_tokens=16000,
                                                output_config={"effort": "medium"},
                                                messages=[{"role": "user", "content": prompt}])
            except (anthropic.APIStatusError, anthropic.APIConnectionError) as ex:
                return None, f"{type(ex).__name__}: {str(ex)[:200]}"
            if r.stop_reason == "refusal":
                self.claude[k] = {"candidates": None, "error": "refusal"}
            else:
                text = "".join(b.text for b in r.content if b.type == "text")
                cands, err = llm.parse_reply(text)
                self.claude[k] = {"candidates": cands, "error": err, "request_id": r._request_id}
            B.save_json_atomic(self.claude_path, self.claude)
        return self.claude[k].get("candidates") or {}, self.claude[k].get("error")


def identify(row, args, mods, judges, cache):
    extractor, finder, llm, javalang = mods
    out = {k: "" for k in B.EXTRA + NEW_COLS}
    out.update(row)
    try:
        root = B.get_archive(row, args)
        testfile, module_dir, method = locate_test(root, row["module"], row["flaky_test"])
        out.update(archive_root=str(root), test_file=str(testfile), module_dir=str(module_dir),
                   junit=B.detect_junit(read_java(testfile)))
    except (OSError, ValueError) as ex:
        out.update(status="input_error", note=str(ex))
        return out
    try:
        f, src, tree, node, line = find_test_method(testfile, method, row, root, javalang, llm)
        out["parse_mode"] = "file" if tree is not None else "method_only"
        module_dirs = list(dict.fromkeys([module_dir] + ([module_root(f, root)] if f != testfile else [])))
        if f != testfile:
            out["note"] = f"test method inherited from {f.name}"
        defined = project_methods(module_dirs, javalang, cache)
        entry = extractor.process_test(node, lambda n: n in defined)
        ranked = finder.find_focal_method_ranked(entry["test_tokens"], entry["candidates"])
        if ranked:
            out.update(jaccard_method=ranked[0][0], jaccard_score=f"{ranked[0][1]:.3f}",
                       jaccard_ambiguous=str(len(ranked) > 1 and abs(ranked[0][1] - ranked[1][1]) < 0.01).lower())
        body = llm.extract_body(src.split("\n"), line) if line else None
        if body is None:
            raise ValueError(f"Could not extract body for {method}")
        prompt = llm.PROMPT.format(name=method, body=body)
        g, gerr = judges.ask_gpt(prompt, llm)
        c, cerr = judges.ask_claude(prompt, llm)
        out.update(gpt_method=top(g or {}), claude_method=top(c or {}),
                   llm_method=top(g or {}), llm_score=f"{max((g or {}).values(), default=0):.3f}")
        if g is None or c is None:
            return {**out, "status": "llm_missing", "note": f"gpt-4o: {gerr or 'ok'}; claude: {cerr or 'ok'}"}
        if not g or not c:
            return {**out, "status": "no_llm_candidate",
                    "note": "no candidate from " + " and ".join(n for n, x in (("gpt-4o", g), ("claude", c)) if not x)}
        name = B.normalize(top(g))
        if name != B.normalize(top(c)):
            return {**out, "status": "disagreed", "note": "gpt-4o and Claude named different methods"}
        if any("<init>" in p or re.match(r"\s*new\s+[\w.<>]+\s*(\(\))?\s*$", p) for p in (top(g), top(c))):
            return {**out, "status": "constructor", "note": "the LLMs named a constructor, not a method"}
        pcs, nested = production_candidates(module_dirs, name, javalang)
        made = re.search(r"new\s+([\w.]+)\s*\(", top(g))
        if made and any(k.endswith("." + made.group(1).split(".")[-1]) for k in nested):
            return {**out, "production_candidates": ";".join(nested), "status": "review_class",
                    "note": f"the test calls {name} on nested class {made.group(1)}"}
        if not pcs and nested:
            return {**out, "production_candidates": ";".join(nested), "status": "review_class",
                    "note": f"{name} is declared only in nested class(es): {', '.join(nested)}"}
        if not pcs:
            return {**out, "status": "not_project_method", "note": f"{name} is not declared in the project's sources"}
        arg_counts = B.call_arg_counts(node, name, javalang)
        if arg_counts:
            fits = [k for k in pcs if B.arity_fits(B.declared_param_counts(module_dir, k, name, javalang), arg_counts)]
            if not fits:
                return {**out, "production_candidates": ";".join(pcs), "status": "not_project_method",
                        "note": f"test calls {name} with {sorted(arg_counts)} argument(s) but no project declaration "
                                "takes that many; a library method with the same name"}
            pcs = fits
        out["production_candidates"] = ";".join(pcs)
        how = [out["note"]] if out["note"] else []
        if len(pcs) > 1:
            test_fq = row["flaky_test"].partition("#")[0]
            base = re.sub(r"^Test(?=[A-Z])", "", re.sub(r"(Tests?|TestCase|IT)$", "", test_fq.split(".")[-1]))
            named = [k for k in pcs if k.split(".")[-1] == base]
            same = [k for k in (named or pcs) if k.rpartition(".")[0] == test_fq.rpartition(".")[0]]
            recv = receiver_classes(node, tree, name, module_dirs, javalang)
            by_recv = [k for k in pcs if k.split(".")[-1] in recv]
            for rule, ks in (("class: named after test", named), ("class: same package as test", same),
                             ("class: type the test calls it on", by_recv)):
                if len(ks) == 1:
                    pcs = ks
                    how.append(rule)
                    break
        if len(pcs) != 1:
            return {**out, "status": "review_class", "note": f"Found {len(pcs)} possible production classes"}
        decl = B.declared_param_counts(module_dir, pcs[0], name, javalang)
        if decl and len(decl) > 1:
            how.append(f"overload: all {len(decl)}")
        return {**out, "selected_method": pcs[0] + "#" + name, "status": "auto_resolved", "note": "; ".join(how)}
    except Exception as ex:  # noqa: BLE001
        return {**out, "status": "identify_error", "note": f"{type(ex).__name__}: {ex}"}


def summarize(rows, out, prefix="", has_old=True):
    lines = []
    def table(title, key):
        c = collections.defaultdict(collections.Counter)
        for r in rows:
            c[key(r)][r["test_type"]] += 1
        lines.append(f"{title}\n" + "".join(
            f"  {k:22} {sum(v.values()):4}   " + "  ".join(f"{t}:{v[t]}" for t in ("od", "id", "td", "nio")) + "\n"
            for k, v in sorted(c.items(), key=lambda kv: -sum(kv[1].values()))))
    table("v2 status (count, then by type)", lambda r: r["status"])
    new = [r for r in rows if r["status"] == "auto_resolved" and r["old_status"] != "auto_resolved"]
    if has_old:
        table("v1 status (old run)", lambda r: r["old_status"])
        old_ok = [r for r in rows if r["old_status"] == "auto_resolved"]
        same = sum(r["selected_method"] == r["old_selected_method"] for r in old_ok)
        changed = [r for r in old_ok if r["status"] == "auto_resolved" and r["selected_method"] != r["old_selected_method"]]
        lost = [r for r in old_ok if r["status"] != "auto_resolved"]
        lines.append(f"The {len(old_ok)} kept before: same focal method {same}, other focal method {len(changed)}, "
                     f"dropped now {len(lost)}\n")
        lines += [f"  other: row {r['row_number']} {r['old_selected_method']} -> {r['selected_method']}\n" for r in changed]
        lines += [f"  dropped: row {r['row_number']} {r['old_selected_method']} ({r['status']}: {r['note'][:100]})\n" for r in lost]
        lines.append(f"\nRecovered (kept now, not before): {len(new)}  "
                     + "  ".join(f"{t}:{sum(r['test_type'] == t for r in new)}" for t in ("od", "id", "td", "nio")) + "\n")
    else:
        for t in ("id", "od", "nio"):
            all_p = {r["project_key"] for r in rows if r["test_type"] == t}
            kept_p = {r["project_key"] for r in new if r["test_type"] == t}
            lines.append(f"{t}: kept in {len(kept_p)} of {len(all_p)} projects\n")
    lines.append(f"Kept in total: {sum(r['status'] == 'auto_resolved' for r in rows)} of {len(rows)}\n")
    (out / f"{prefix}summary.txt").write_text("".join(lines), encoding="utf-8")
    random.seed(2026)
    sample = random.sample(new, min(20, len(new)))
    cols = ["row_number", "test_type", "flaky_test", "selected_method", "gpt_method", "claude_method",
            "jaccard_method", "old_status", "note", "test_file", "correct (yes/no)", "comment"]
    with open(out / f"{prefix}review_sample.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(sorted(sample, key=lambda r: int(r["row_number"])))
    print("".join(lines))


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--rows", type=int, nargs="*", help="Only these row numbers")
    a.add_argument("--dry-run", action="store_true", help="No API calls")
    a.add_argument("--out", type=Path, default=P / "out")
    a.add_argument("--archives", type=Path, default=P / "archives")
    a.add_argument("--set", choices=["main", "expansion"], default="main",
                   help="main: the 144 main-study tests; expansion: inputs/expansion_v1.csv")
    a.add_argument("--delete-archives", action="store_true", help="Delete each downloaded archive when its rows are done")
    args = a.parse_args()
    if not args.dry_run and not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("export ANTHROPIC_API_KEY first (or use --dry-run)")
    args.out.mkdir(exist_ok=True)
    archive_args = argparse.Namespace(archives=args.archives.resolve(), out=args.archives.resolve(),
                                      download=True, delete_zips=True)
    import javalang
    fs = P / "focal_scripts"
    extractor = B.load_module(fs, "focal_extract.py", "repro_focal_extract")
    finder = B.load_module(fs, "focal_method_finder_batch.py", "repro_focal_jaccard")
    llm = B.load_module(fs, "llm_focal.py", "repro_focal_llm")
    llm.junit_annotated = llm.is_test
    mods = (extractor, finder, llm, javalang)
    judges = Judges(args.out, args.dry_run)
    main_set = args.set == "main"
    v1 = list(csv.DictReader(open(P / "inputs" / ("focal_manifest_v1.csv" if main_set else "expansion_v1.csv"),
                                  encoding="utf-8")))
    old = {int(r["row_number"]): r for r in v1} if main_set else {}
    rows = [{k: v for k, v in r.items() if k not in B.EXTRA} for r in v1]
    res_path = args.out / ("focal_manifest_v2.csv" if main_set else "expansion_manifest.csv")
    done = {int(r["row_number"]): r for r in csv.DictReader(open(res_path, encoding="utf-8"))} if res_path.is_file() else {}
    cols = list(rows[0].keys()) + [c for c in B.EXTRA if c not in rows[0]] + NEW_COLS
    cache = {}
    todo = [i for i in range(1, len(rows) + 1) if not args.rows or i in args.rows]
    for n, i in enumerate(todo):
        row = rows[i - 1]
        r = identify(row, archive_args, mods, judges, cache)
        o = old.get(i, {})
        r.update(row_number=i, old_status=o.get("status", ""), old_selected_method=o.get("selected_method", ""))
        done[i] = r
        B.csv_write(res_path, [done[k] for k in sorted(done)], cols)
        print(f"[{i}/{len(rows)}] {row['flaky_test']} -> {r['selected_method'] or '-'} ({r['status']}) "
              f"gpt={r['gpt_method']} claude={r['claude_method']}", flush=True)
        if args.delete_archives and (n + 1 == len(todo) or rows[todo[n + 1] - 1]["zip"] != row["zip"]):
            unpacked = archive_args.out / "extracted" / row["zip"]
            if unpacked.is_dir():
                shutil.rmtree(unpacked)
                cache.clear()
    summarize([done[k] for k in sorted(done)], args.out, "" if main_set else "expansion_", main_set)


if __name__ == "__main__":
    main()
