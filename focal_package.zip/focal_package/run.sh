#!/bin/bash
# Focal methods of the 144 main-study flaky tests with gpt-4o + Claude (focal_v2.py).
# Results: out/focal_manifest_v2.csv, out/summary.txt, out/review_sample.csv. Log: out/run.log.
# Resumable: rows are redone, but LLM answers are cached in out/, so nothing is asked twice.
# Usage (with ANTHROPIC_API_KEY and OPENAI_API_KEY exported in this shell):
#   bash run.sh             all 144 rows
#   bash run.sh --rows 1 3  only these rows (a first test)
D="$(cd "$(dirname "$0")" && pwd)"
[ -n "$ANTHROPIC_API_KEY" ] || { echo "export ANTHROPIC_API_KEY first"; exit 1; }
[ -n "$OPENAI_API_KEY" ] || echo "note: OPENAI_API_KEY not set; rows whose prompt is not in the gpt-4o cache stay llm_missing"
if [ ! -x "$D/venv/bin/python" ]; then
  python3 -m venv "$D/venv" && "$D/venv/bin/pip" install -q -r "$D/requirements.txt" || exit 1
fi
mkdir -p "$D/out"
"$D/venv/bin/pip" freeze > "$D/out/pip_freeze.txt"
"$D/venv/bin/python" "$D/focal_v2.py" "$@" 2>&1 | tee -a "$D/out/run.log"
