#!/usr/bin/env python3
"""Build inputs/expansion_v1.csv: the ReproFlake tests outside the main study's 144 for focal_v2.py --set
expansion, in the columns of inputs/focal_manifest_v1.csv (without the result columns).
  ID:  2 random tests (seed 2026) from each project that is not in the main study;
  OD:  all of them (ormlite, wildfly);
  NIO: all of them (quickcheck);
  TD:  none left; unclassified/brittle tests are left out.
A project is the archive name before the first "=" (hutool=hutool-core=33121a4 -> hutool), or for the
other archive names the issue-key prefix (HDFS-10281 -> hadoop) or a known name (elasticjobf0d -> elasticjob).
Rows are sorted by archive, so focal_v2.py --delete-archives can delete each archive when its rows are done.
project and flaky_commit are empty (not in test_config.csv); project_key is added.
Usage: python3 make_expansion_input.py
"""
import collections
import csv
from pathlib import Path
import random
import re

P = Path(__file__).resolve().parent
ISSUE = {"hdfs": "hadoop", "yarn": "hadoop", "scb": "servicecomb", "collections": "commons-collections"}
NAMES = [("shardingsphereelasticjob", "elasticjob"), ("elasticjob", "elasticjob"), ("dubbo", "dubbo"),
         ("hadoop", "hadoop"), ("jnrposix", "jnr-posix"), ("marineapi", "marineapi"), ("ormlite", "ormlite"),
         ("quickcheck", "quickcheck"), ("wikidatatoolkit", "wikidata-toolkit"), ("wildfly", "wildfly")]
# the same project under another archive name
ALIAS = {"junit-quickcheck": "quickcheck", "ormlite-core": "ormlite", "servicecomb-java-chassis": "servicecomb",
         "incubator-shenyu": "shenyu"}
PER_PROJECT = 2


def project_key(z):
    k = raw_key(z)
    return ALIAS.get(k, k)


def raw_key(z):
    if "=" in z:
        return z.split("=")[0].lower()
    m = re.fullmatch(r"([A-Z]+)-\d+", z)
    if m:
        return ISSUE.get(m.group(1).lower(), m.group(1).lower())
    return next((name for pre, name in NAMES if z.lower().startswith(pre)), z.lower())


def main():
    v1 = list(csv.DictReader(open(P / "inputs" / "focal_manifest_v1.csv", encoding="utf-8")))
    cols = [c for c in v1[0] if c not in ("row_number", "archive_root", "test_file", "module_dir", "junit",
                                          "parse_mode", "jaccard_method", "jaccard_score", "jaccard_ambiguous",
                                          "llm_method", "llm_score", "production_candidates", "selected_method",
                                          "status", "note")]
    used = {r["flaky_test"] for r in v1}
    main_projects = {project_key(r["zip"]) for r in v1}
    rest = [r for r in csv.DictReader(open(P / "inputs" / "reproflake_test_config.csv", encoding="utf-8"))
            if r["flaky_test"] not in used]
    by_type = collections.defaultdict(list)
    for r in rest:
        by_type[r["test_type"].strip().lower()].append(r)
    groups = collections.defaultdict(list)
    for r in by_type["id"]:
        if project_key(r["zip"]) not in main_projects:
            groups[project_key(r["zip"])].append(r)
    rng = random.Random(2026)
    chosen = []
    for k in sorted(groups):
        rows = sorted(groups[k], key=lambda r: (r["zip"], r["module"], r["flaky_test"]))
        chosen += rng.sample(rows, min(PER_PROJECT, len(rows)))
    chosen += by_type["od"] + by_type["nio"]
    chosen.sort(key=lambda r: (r["zip"], r["module"], r["flaky_test"]))
    out = []
    for i, r in enumerate(chosen, 1):
        t = r["test_type"].strip().lower()
        out.append({**{c: r.get(c, "") for c in cols}, "sheet_test_type": t, "test_type": t, "project": "",
                    "flaky_commit": "", "row_number": i, "project_key": project_key(r["zip"])})
    with open(P / "inputs" / "expansion_v1.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, cols + ["row_number", "project_key"])
        w.writeheader()
        w.writerows(out)
    c = collections.Counter(r["test_type"] for r in out)
    print(f"inputs/expansion_v1.csv: {len(out)} tests ({dict(c)}), {len({r['zip'] for r in out})} archives; "
          f"ID from {len(groups)} projects not in the main study")


if __name__ == "__main__":
    main()
