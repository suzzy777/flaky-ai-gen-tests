# Non-flaky tests and their focal methods: group 2 (22 modules)

This run covers **22 (project, commit, module) units** from ReproFlake's `result_matched.csv` (group 2 of 2; the other group has the remaining 23). They are listed in `modules.csv`. For each one:

1. **Step 1:** download the project archive from Zenodo, run the module's own `mvn test`, and list every test that is **not known to be flaky** (`nonflaky.csv`).
2. **Step 2:** for a sample of those non-flaky tests, find the **focal method** (the method under test). This uses exactly the method used for the flaky tests: Jaccard name matching plus an LLM, and both must agree.

Step 1 needs no API key. Step 2 needs an OpenAI API key.

## What's in this folder

| File | What it is |
|---|---|
| `collect_nonflaky.py` | Step 1 script |
| `nonflaky_focal.py` | Step 2 script |
| `batch_reproflake_chatunitest.py` | Helper code both scripts import: archive download/extraction, JDK choice, module build, and `run_identification()` with all the focal-method rules. Keep it in the same folder. |
| `focal_scripts/` | `focal_extract.py`, `focal_method_finder_batch.py`, `llm_focal.py`: test parsing, Jaccard ranking, LLM prompt and call (from devanshik19/srse-flakiness-research `archive/03_focal_methods`) |
| `result_matched_modules.csv` | The input: all 52 flaky-test rows of `result_matched.csv` for these 22 modules (23 archives) |
| `modules.csv` | Readable list of the 22 modules: project, commit, module, archive(s), JDK, Zenodo URL, number of listed flaky tests |
| `idoft_pr_data.csv` | IDoFT's list of known flaky tests (copy taken 2026-10-22), so everyone excludes against the same version |
| `README.md` | This file |

## Requirements

- Linux or macOS, `python3` 3.8 or newer
- `pip install javalang` (Step 2 only; Step 1 uses the standard library only)
- Maven 3.6 or newer on `PATH`
- JDK 8, 11 and 17 (43 of the rows need 8, 7 of the rows need 11, 2 of the rows need 17). They're found under `/usr/lib/jvm` or `/Library/Java/JavaVirtualMachines`, or set them explicitly:
  ```
  export JAVA_HOME_8=/path/to/jdk8
  export JAVA_HOME_11=/path/to/jdk11
  export JAVA_HOME_17=/path/to/jdk17
  ```
  On Ubuntu: `sudo apt install openjdk-8-jdk openjdk-11-jdk openjdk-17-jdk maven`
- Internet access to zenodo.org, Maven Central and (Step 2) api.openai.com
- Disk: plan for about 150 GB free. Some modules are large (camel, hadoop, hbase, oozie).
- Time: a day or more for Step 1. Small modules take minutes; Hadoop/HBase modules can take hours each.

If your Maven install has extension jars in `<maven home>/lib/ext` (some flaky-test research setups install one that rewrites surefire), Step 1 automatically runs a copy of Maven without them (`nonflaky_out/maven-noext`). Your Maven install is not changed.

## How to run

Use tmux or screen so the run survives closing the terminal:

```
tmux new -s nonflaky
cd <this folder>
```

Detach with Ctrl+B then D, and reattach with `tmux attach -t nonflaky`. Ctrl+C stops a run. **Rerunning the same command resumes** where it stopped, and finished work is skipped.

### Step 1: non-flaky test list

Pilot on one small module first (a few minutes):

```
python3 collect_nonflaky.py --csv result_matched_modules.csv --idoft idoft_pr_data.csv \
  --out ./nonflaky_out --archives ./zips --download --delete-zips \
  --only edn-java 2>&1 | tee pilot.log
```

It should end with a line like `=> ok: N ran, ... non-flaky`.

Then all 22:

```
python3 collect_nonflaky.py --csv result_matched_modules.csv --idoft idoft_pr_data.csv \
  --out ./nonflaky_out --archives ./zips --download --delete-zips \
  2>&1 | tee step1.log
```

`--download` fetches each archive from Zenodo, and `--delete-zips` deletes the zip once it's extracted (into `nonflaky_out/extracted/`).

What it does, per module:
1. Downloads and extracts the archive. Its `Flaky/` folder is the project at the flaky commit.
2. Builds the modules this one depends on (`mvn install -DskipTests`), then runs the module's own `mvn test` and reads every `Class#method` that ran from `target/surefire-reports`.
3. Removes a test if it is listed as flaky for the same project + module in `result_matched_modules.csv` or `idoft_pr_data.csv`, or if it didn't pass cleanly (failed, errored, skipped, or passed only on a rerun).
4. Writes what's left to `nonflaky_out/nonflaky.csv`.

"Non-flaky" means "not known to be flaky", not "proven stable".

If a build fails, the script merges the archive's own bundled Maven repo (`Flakym2/`) into the local Maven repo (adding files only, never overwriting) and retries once.

Useful options:

| Option | Meaning |
|---|---|
| `--only TEXT` | only modules whose project URL, zip or module contains TEXT (repeatable), e.g. `--only hadoop`. Handy for splitting work across machines |
| `--limit N` | first N modules only |
| `--redo` | rerun modules that already finished |
| `--timeout SEC` | per Maven run (default 14400 = 4 h) |
| `--maven-repo DIR` | local Maven repo (default `~/.m2/repository`) |

### Step 2: focal methods of the non-flaky tests

Needs Step 1's output and its extracted archives.

First a dry run, which makes no API calls. It shows how many tests are sampled and checks that each one's test file is found:

```
python3 nonflaky_focal.py --nonflaky nonflaky_out/nonflaky.csv \
  --archive-dir nonflaky_out/extracted --focal-scripts ./focal_scripts
```

Every row should say `awaiting_llm`. `input_error` means the test file or archive wasn't found.

Then the real run:

```
export OPENAI_API_KEY=sk-...
python3 nonflaky_focal.py --nonflaky nonflaky_out/nonflaky.csv \
  --archive-dir nonflaky_out/extracted --focal-scripts ./focal_scripts \
  --run-llm 2>&1 | tee step2.log
```

Add `--limit 5` to the first real run as a pilot.

By default it takes **up to 20 random non-flaky tests per module**, which is at most 440 tests and 440 OpenAI calls (gpt-4o, temperature 0). The same `--seed` always gives the same sample.

What it does, per test (the same as for the flaky tests, via `run_identification()` in `batch_reproflake_chatunitest.py`):
1. Finds the test's `.java` file and parses the test method.
2. **Jaccard:** ranks the project methods the test calls by name similarity to the test name.
3. **LLM:** asks the model which call in the test body is the method under test.
4. **Both must agree** on the method name; otherwise the row is flagged and no method is chosen.
5. Finds the production class: it drops classes whose method can't take the number of arguments the test passes, then prefers the class named after the test (`FooTest` → `Foo`), then the same package. Overloads are kept together.

Useful options:

| Option | Meaning |
|---|---|
| `--per-module N` | tests sampled per module (default 20) |
| `--all` | every non-flaky test instead of a sample (one API call each) |
| `--seed S` | sampling seed (default 1) |
| `--model M` | OpenAI model (default gpt-4o) |
| `--limit N` | first N sampled tests only |
| `--force` | redo tests that already have a result |
| `--out DIR` | output folder (default `nonflaky_focal_out`) |

LLM replies are cached in `nonflaky_focal_out/llm_cache.json`, so reruns don't pay twice.

## Output

**Step 1 (`nonflaky_out/`)**

| File | Contents |
|---|---|
| `nonflaky.csv` | **The list**: one non-flaky test method per row (`project, commit, module, zip, java, url, test`), where `test` is `package.Class#method` |
| `all_tests.csv` | every test that ran, its outcome, and why it was excluded (`result_matched` / `idoft` / `not_passed`) |
| `units.csv` | one row per module with its status and counts |
| `units/<module>/` | `build.log`, `test.log`, `result.json` |

`units.csv` status values:

| Status | Meaning |
|---|---|
| `ok` | done |
| `build_failed` / `build_timeout` | the modules it depends on didn't build; see `units/<module>/build*.log` |
| `no_tests_ran` | `mvn test` wrote no surefire reports; see `units/<module>/test*.log` |
| `test_timeout` | `mvn test` hit `--timeout` |
| `archive_or_module_not_found` | archive missing (did you pass `--download`?) or test file not found |

**Step 2 (`nonflaky_focal_out/`)**

`nonflaky_focal_manifest.csv` has one row per sampled test, in the same format as the flaky tests' `focal_manifest.csv` (with `test_kind=nonflaky`; `test` is the test as surefire reported it, `flaky_test` the same without any nested-class `$...` part, which is what finds the file). The key columns:

- `selected_method`: the focal method as `package.Class#method` (blank if none was chosen)
- `status` is one of:
  - `auto_resolved`: a focal method was chosen
  - `disagreed`: Jaccard and LLM named different methods
  - `review_jaccard`: Jaccard scored 0 or tied and the LLM picked another method
  - `review_class`: several possible production classes, or the argument count doesn't fit
  - `no_jaccard_candidates`: the test calls no project method
  - `llm_failed`: the API call failed
  - `identify_error`: the test couldn't be parsed
- `jaccard_method`, `jaccard_score`, `llm_method`, `llm_score`, `production_candidates`, `note`: how the decision was made

Expect only part of the sample to get a focal method. On the flaky tests, 53 of 144 did.

## What to send back

- `nonflaky_out/nonflaky.csv`, `all_tests.csv`, `units.csv` (and `units/<module>/` for any module that isn't `ok`)
- `nonflaky_focal_out/nonflaky_focal_manifest.csv` and `llm_cache.json`
- `step1.log`, `step2.log`
