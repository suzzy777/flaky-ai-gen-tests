#!/usr/bin/env python3
"""Focal methods for the non-flaky tests in nonflaky.csv (from collect_nonflaky.py).

Takes the non-flaky tests from one or more nonflaky.csv files, picks a sample per module (or
all of them), and finds each test's focal method with exactly the method used for the flaky
tests: batch_reproflake_chatunitest.run_identification (Jaccard + LLM, both must agree, then
the production class and overload rules), using the helper scripts in --focal-scripts
(focal_extract.py, focal_method_finder_batch.py, llm_focal.py). Without --run-llm it only lists
and locates the sample (status awaiting_llm), with no API calls.

Output (--out): nonflaky_focal_manifest.csv in the same format as prepare's focal_manifest.csv
(the test is in the flaky_test column, so `generate` can use it as is), with
test_kind=nonflaky. LLM replies are cached in llm_cache.json; rerunning skips finished rows.

A module that shows up in several nonflaky.csv files (collected from two archive copies) only
keeps the tests that are non-flaky in all of them.
"""
import argparse
import csv
import json
import os
from pathlib import Path
import random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import batch_reproflake_chatunitest as B  # noqa: E402

INPUT_COLS = ["test_kind", "project", "flaky_commit", "module", "zip", "java", "url", "flaky_test"]


def load_nonflaky(paths):
    """{(project, commit, module): {"tests": set, "rows": {test: row}}} over all files."""
    units = {}
    for p in paths:
        per_file = {}
        for r in csv.DictReader(open(p, encoding="utf-8")):
            per_file.setdefault((r["project"], r["commit"], r["module"]), []).append(r)
        for key, rows in per_file.items():
            tests = {r["test"] for r in rows}
            if key in units:
                units[key]["tests"] &= tests
            else:
                units[key] = {"tests": tests, "rows": {r["test"]: r for r in rows}}
    return units


def pick(units, per_module, seed):
    """Rows (in prepare's input format) for the sample: up to per_module tests per module."""
    out = []
    for key in sorted(units):
        tests = sorted(units[key]["tests"])
        if per_module:
            tests = sorted(random.Random(f"{seed}|{'|'.join(key)}").sample(tests, min(per_module, len(tests))))
        for t in tests:
            r = units[key]["rows"][t]
            out.append({"test_kind": "nonflaky", "project": r["project"], "flaky_commit": r["commit"],
                        "module": r["module"], "zip": r["zip"], "java": r["java"], "url": r["url"],
                        "flaky_test": t})
    return out


def load_helpers(focal_scripts):
    import javalang
    extractor = B.load_module(focal_scripts, "focal_extract.py", "repro_focal_extract")
    finder = B.load_module(focal_scripts, "focal_method_finder_batch.py", "repro_focal_jaccard")
    llm = B.load_module(focal_scripts, "llm_focal.py", "repro_focal_llm")
    # Same as prepare(): keep the originals; run_identification swaps in a JUnit 3-aware check.
    extractor.junit_annotated = extractor.is_test_method
    llm.junit_annotated = llm.is_test
    return extractor, finder, llm, javalang


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--nonflaky", type=Path, action="append", required=True,
                   help="nonflaky.csv to take tests from (repeatable)")
    a.add_argument("--archive-dir", type=Path, action="append", required=True,
                   help="Folder with extracted <zip>/ archives (repeatable), e.g. out_part1/extracted")
    a.add_argument("--focal-scripts", type=Path, default=Path.home() / "focal_scripts")
    a.add_argument("--out", type=Path, default=Path("nonflaky_focal_out"))
    a.add_argument("--per-module", type=int, default=20, help="Tests sampled per module (default 20)")
    a.add_argument("--all", action="store_true", help="Every non-flaky test instead of a sample")
    a.add_argument("--seed", default="1", help="Sampling seed (same seed, same sample)")
    a.add_argument("--run-llm", action="store_true", help="Make the OpenAI calls (needs OPENAI_API_KEY)")
    a.add_argument("--model", default="gpt-4o")
    a.add_argument("--force", action="store_true", help="Redo rows that already have a result")
    a.add_argument("--limit", type=int, default=0, help="First N sampled tests only (pilot)")
    args = a.parse_args()
    args.archive_dir = [d.resolve() for d in args.archive_dir]
    args.out = args.out.resolve()
    args.out.mkdir(parents=True, exist_ok=True)

    units = load_nonflaky(args.nonflaky)
    rows = pick(units, 0 if args.all else args.per_module, args.seed)
    if args.limit:
        rows = rows[:args.limit]
    print(f"{sum(len(u['tests']) for u in units.values())} non-flaky tests in {len(units)} modules; "
          f"{len(rows)} selected", flush=True)

    if args.run_llm and not os.getenv("OPENAI_API_KEY"):
        sys.exit("Set OPENAI_API_KEY before --run-llm")
    modules = load_helpers(args.focal_scripts) if args.run_llm else None

    manifest_path = args.out / "nonflaky_focal_manifest.csv"
    key = lambda r: (r["project"], r["flaky_commit"], r["module"], r["flaky_test"])
    previous = {}
    if manifest_path.is_file():
        previous = {key(r): r for r in csv.DictReader(open(manifest_path, encoding="utf-8"))}
    try:
        llm_cache = json.loads((args.out / "llm_cache.json").read_text())
    except (OSError, ValueError):
        llm_cache = {}
    cache = {"extract": {}, "production": {}, "src_main": {}, "llm": llm_cache}
    # run_identification reads these off its args.
    ident = argparse.Namespace(run_llm=args.run_llm, force=args.force, model=args.model,
                               out=args.out, download=False, archives=None)

    manifest = []
    for i, row in enumerate(rows, 1):
        old = previous.get(key(row), {})
        if old and not args.force and old.get("status") not in ("", "awaiting_llm", "input_error"):
            entry = old
        else:
            # get_archive looks in args.archives; point it at the folder holding this archive.
            ident.archives = next((d for d in args.archive_dir if (d / row["zip"]).is_dir()), args.archive_dir[0])
            entry = B.run_identification(row, ident, modules, cache, old)
        entry["row_number"] = i
        manifest.append(entry)
        B.csv_write(manifest_path, manifest, INPUT_COLS + [c for c in B.EXTRA if c not in INPUT_COLS])
        print(f"[{i}/{len(rows)}] {row['flaky_test']} -> {entry.get('selected_method') or '-'} "
              f"({entry.get('status')})", flush=True)

    counts = {}
    for e in manifest:
        counts[e.get("status")] = counts.get(e.get("status"), 0) + 1
    print(f"\n{len(manifest)} tests: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items(), key=str))
          + f"\nManifest: {manifest_path}")


if __name__ == "__main__":
    main()
